class Assistant {
  String firstName;
  String lastName;
  String phone;
  String email;
  String password;
  String gender;
  String id;
  bool mr;
  String nationalId;
  Assistant({
    required this.email,
    required this.firstName,
    required this.gender,
    required this.lastName,
    required this.password,
    required this.phone,
    required this.id,
    required this.mr,
    required this.nationalId,
  });
}