class Branch {
  final String name;
  final String firsttime;
  final String secondtime;
  final String thirdtime;
  final String isFirst;
  final String isSecond;
  final String isThird;
  final String capacity;
  Branch({
    required this.name,
    required this.firsttime,
    required this.secondtime,
    required this.thirdtime,
    required this.isFirst,
    required this.isSecond,
    required this.isThird,
    required this.capacity,
  });
}