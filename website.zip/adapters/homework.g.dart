// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'homework.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class HomeworkAdapter extends TypeAdapter<Homework> {
  @override
  final int typeId = 5;

  @override
  Homework read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return Homework(
      sessionName: fields[0] as String,
      questions: (fields[2] as List).cast<dynamic>(),
      stage: fields[1] as String,
      successMark: fields[3] as String,
      fullMark: fields[4] as String,
      mark: fields[5] as String,
    );
  }

  @override
  void write(BinaryWriter writer, Homework obj) {
    writer
      ..writeByte(6)
      ..writeByte(0)
      ..write(obj.sessionName)
      ..writeByte(1)
      ..write(obj.stage)
      ..writeByte(2)
      ..write(obj.questions)
      ..writeByte(3)
      ..write(obj.successMark)
      ..writeByte(4)
      ..write(obj.fullMark)
      ..writeByte(5)
      ..write(obj.mark);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is HomeworkAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
