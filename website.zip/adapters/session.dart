import 'package:hive_flutter/hive_flutter.dart';
import 'package:quadroedu/adapters/homework.dart';
import 'package:quadroedu/adapters/quiz.dart';

part 'session.g.dart';

@HiveType(typeId: 2)
class Session {
  @HiveField(0)
  String stage;
  @HiveField(1)
  String isBuyable;
  @HiveField(2)
  String name;
  @HiveField(3)
  List videos; //////////////////////////
  @HiveField(4)
  List docs;  //////////////////////////
  @HiveField(5)
  String mark; ////////////////////
  @HiveField(6)
  Quiz quiz; ///////////////////
  @HiveField(7)
  String url; 
  @HiveField(8)
  Homework homework; ////////////////
  @HiveField(9)
  String price;
  Session({
    required this.stage,
    required this.isBuyable,
    required this.name,
    required this.videos,
    required this.docs,
    required this.mark,
    required this.quiz,
    required this.url,
    required this.homework,
    required this.price
  });
}
