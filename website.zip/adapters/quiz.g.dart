// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'quiz.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class QuizAdapter extends TypeAdapter<Quiz> {
  @override
  final int typeId = 3;

  @override
  Quiz read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return Quiz(
      onSession: fields[2] as String,
      sessionName: fields[0] as String,
      questions: (fields[3] as List).cast<dynamic>(),
      stage: fields[1] as String,
      successMark: fields[4] as String,
      fullMark: fields[5] as String,
      quizTimer: fields[6] as String,
    );
  }

  @override
  void write(BinaryWriter writer, Quiz obj) {
    writer
      ..writeByte(7)
      ..writeByte(0)
      ..write(obj.sessionName)
      ..writeByte(1)
      ..write(obj.stage)
      ..writeByte(2)
      ..write(obj.onSession)
      ..writeByte(3)
      ..write(obj.questions)
      ..writeByte(4)
      ..write(obj.successMark)
      ..writeByte(5)
      ..write(obj.fullMark)
      ..writeByte(6)
      ..write(obj.quizTimer);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is QuizAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
