import 'package:hive_flutter/hive_flutter.dart';

part 'question.g.dart';

@HiveType(typeId: 4)
class Question {
  @HiveField(0)
  String mark;
  @HiveField(1)
  String question;
  @HiveField(2)
  String imageUrl;
  @HiveField(3)
  String rightLetter;
  @HiveField(4)
  String wrong1;
  @HiveField(5)
  String wrong2;
  @HiveField(6)
  String wrong3;
  @HiveField(7)
  String chpname;
  @HiveField(8)
  String sessionname;
  @HiveField(9)
  String sessionstage;
  @HiveField(10)
  bool isMCQ;
  @HiveField(11)
  String id;
  Question({
    required this.imageUrl,
    required this.mark,
    required this.isMCQ,
    required this.question,
    required this.rightLetter,
    required this.wrong1,
    required this.wrong2,
    required this.wrong3,
    required this.chpname,
    required this.sessionname,
    required this.sessionstage,
    required this.id,
  });
}
