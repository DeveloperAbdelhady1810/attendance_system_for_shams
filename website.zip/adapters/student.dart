import 'package:hive_flutter/hive_flutter.dart';

part 'student.g.dart';
@HiveType(typeId: 1)
class Student {
  @HiveField(0)
  String cardId;
  @HiveField(1)
  String name;
  @HiveField(2)
  String phone;
  @HiveField(3)
  String password;
  @HiveField(4)
  String parrentPhone;
  @HiveField(5)
  String stage;
  @HiveField(6)
  String center;
  @HiveField(7)
  String state;
  @HiveField(8)
  String balance;
  @HiveField(9)
  String active;
  @HiveField(10)
  String school;
  @HiveField(11)
  List? sessions = [];
  Student({
    required this.name,
    required this.balance,
    required this.cardId,
    required this.password,
    required this.phone,
    required this.parrentPhone,
    required this.stage,
    required this.center,
    required this.state,
    required this.active,
    required this.school,
    required this.sessions,
  });
}