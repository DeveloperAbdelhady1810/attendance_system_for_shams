// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'question.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class QuestionAdapter extends TypeAdapter<Question> {
  @override
  final int typeId = 4;

  @override
  Question read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return Question(
      imageUrl: fields[2] as String,
      mark: fields[0] as String,
      isMCQ: fields[10] as bool,
      question: fields[1] as String,
      rightLetter: fields[3] as String,
      wrong1: fields[4] as String,
      wrong2: fields[5] as String,
      wrong3: fields[6] as String,
      chpname: fields[7] as String,
      sessionname: fields[8] as String,
      sessionstage: fields[9] as String,
      id: fields[11] as String,
    );
  }

  @override
  void write(BinaryWriter writer, Question obj) {
    writer
      ..writeByte(12)
      ..writeByte(0)
      ..write(obj.mark)
      ..writeByte(1)
      ..write(obj.question)
      ..writeByte(2)
      ..write(obj.imageUrl)
      ..writeByte(3)
      ..write(obj.rightLetter)
      ..writeByte(4)
      ..write(obj.wrong1)
      ..writeByte(5)
      ..write(obj.wrong2)
      ..writeByte(6)
      ..write(obj.wrong3)
      ..writeByte(7)
      ..write(obj.chpname)
      ..writeByte(8)
      ..write(obj.sessionname)
      ..writeByte(9)
      ..write(obj.sessionstage)
      ..writeByte(10)
      ..write(obj.isMCQ)
      ..writeByte(11)
      ..write(obj.id);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is QuestionAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
