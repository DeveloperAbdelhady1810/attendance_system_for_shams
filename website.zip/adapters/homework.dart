import 'package:hive_flutter/hive_flutter.dart';

part 'homework.g.dart';

@HiveType(typeId: 5)
class Homework {
  @HiveField(0)
  String sessionName;
  @HiveField(1)
  String stage;
  @HiveField(2)
  List questions;
  @HiveField(3)
  String successMark;
  @HiveField(4)
  String fullMark;
  @HiveField(5)
  String mark;
  Homework({
    required this.sessionName,
    required this.questions,
    required this.stage,
    required this.successMark,
    required this.fullMark,
    required this.mark,
  });
}
