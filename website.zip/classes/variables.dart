import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:intl/intl.dart';
import 'package:quadroedu/adapters/session.dart';
import 'package:quadroedu/adapters/student.dart';
import 'package:http/http.dart' as http;
import 'dart:js' as js;
class Variables {
  Box settings = Hive.box("settings");
  String url="https://balance-academy.com/php/";
  // Color mainColor= Color.fromRGBO(139,97,48,1);
  // Color secondColor= Color.fromRGBO(26, 34, 44,1);
  Color secondColor= Colors.black;
  Color mainColor= Color.fromRGBO(255, 189, 89,1);
  Color thirdColor= Color.fromRGBO(241, 196, 15,1);
  Future<String> getUserAgent() async {
    return js.context.callMethod("getUserAgent");
  }
  Future<Map> charge_code(String code)async{
    DateTime now = DateTime.now();
    var formatter = DateFormat("dd-MM-yyyy");
    var formatter2 = DateFormat("h:m:s");
    String formattedDate = formatter.format(now);
    String formattedTime = formatter2.format(now);
    http.Response response = await http.post(
      Uri.parse(
        "${Variables().url}charge_code.php"
      ),
      body:{
        "code":code,
        "phone":getStudent().phone,
        "date":formattedDate,
        "time":formattedTime
      }
    );
    String price = response.body.toString();
    if (response.statusCode==202) {
      // found , not bought before
      Student student = getStudent();
      student.balance = (double.parse(student.balance)+double.parse(price)).toString();
      int response = await updateBalance(student);
      if (response==202) {
        await Variables().settings.put("Credits", student);
        return {"status":202,"message":"Code Charged"};
      }else{
        return {"status":404,"message":"Error updating balance"};
      }
    } else if(response.statusCode==303){
      // found but bought before
      return {"status":303,"message":"Code Charged before"};
    } else{
      // not found
      return {"status":404,"message":"Code not found"};
    }
  }
  Future<int> buySession(Student student,Map session)async{
    http.Response response = await http.post(
      Uri.parse("${url}buy_session.php"),
      body: {
        "phone":student.phone,
        "chpname":session['chpname'],
        "chpstage":session['chpstage'],
        "sessionname":session['sessionname'],
        "center":student.center,
        "date":session['date'],
        "time":session['time']
      }
    );
    return response.statusCode;
  }
  Future<int>updateBalance(Student student) async {
    http.Response response = await http.post(
      Uri.parse(
        "${url}update_balance.php",
      ),
      body: {
        "id": student.cardId,
        "balance": student.balance,
      }
    );
    return response.statusCode;
  }
  loginStudent(Map studentData) async {
    Student student = Student(
      name: studentData['name'],
      balance: studentData['balance'],
      cardId: studentData['id'],
      parrentPhone: studentData['parentphone'],
      password: studentData['password'],
      phone: studentData['phone'],
      stage: studentData['stage'],
      center: studentData['center'],
      state: studentData['state'],
      active: studentData['active'],
      school: studentData['school'],
      sessions: studentData['sessions'],
    );
    // print(student.sessions);
    await settings.put("Credits", student);
    await settings.put("Admin", false);
  }
  loginAssistant(Map assistantData) async {
    await settings.put("Assistant", assistantData);
    await settings.put("Admin", true);
  }
  bool isbought(Session session,String chpname){
    String value = session.name+chpname;
    if (getStudent().sessions!.contains(value)) {
      return true;
    } else {
      return false;
    }
  }
  Student getStudent(){
    return settings.get("Credits");
  }
  Future<int> updateChapter(chapter_id,field,value)async{
    http.Response response= await http.post(
      Uri.parse(
        "${url}changeChapter.php"
      ),
      body: {
        "chapter_id":chapter_id,
        "field":field,
        "value":value,
      }
    );
    return response.statusCode;
  }
}