import 'package:flutter/material.dart';
import 'package:quadroedu/adapters/homework.dart';
import 'package:quadroedu/adapters/question.dart';
import 'package:quadroedu/adapters/quiz.dart';
import 'package:quadroedu/adapters/session.dart';
import 'package:quadroedu/classes/variables.dart';
import 'package:quadroedu/widgtes/session_card.dart';

class MySessionsScreen extends StatefulWidget {
  const MySessionsScreen({super.key});

  @override
  State<MySessionsScreen> createState() => _MySessionsScreenState();
}

List sessions = [];

class _MySessionsScreenState extends State<MySessionsScreen> {
  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width - 205;
    final crossAxisCount = screenWidth ~/ 300;
    return Expanded(
      child: GridView.builder(
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: crossAxisCount > 0 ? crossAxisCount : 1,
        childAspectRatio: 1,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
      ),
      itemCount: Variables().getStudent().sessions!.length,
      itemBuilder: (context, index) {
        Map session = Variables().getStudent().sessions!.elementAt(index);
        return SessionCard(
          isbought: true,
          chpname: session['chpname'],
          session: Session(
            price: "",
            stage: session['chpstage'],
            isBuyable: "true",
            name: session['sessionname'],
            videos: [],
            docs: [],
            mark: "",
            quiz: Quiz(
              quizTimer: "",
              onSession: "",
              sessionName: session['sessionname'],
              questions: [],
              stage: session['chpstage'],
              successMark: "",
              fullMark: ""
            ),
            url: "images/3.jpg",
            homework: Homework(
              sessionName: session['sessionname'],
              questions: [],
              stage: session['chpstage'],
              successMark: "",
              fullMark: "",
              mark: ""
            )
          ),
        );
      }
    ),
  );
}
}
