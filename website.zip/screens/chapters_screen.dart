import 'dart:convert';
import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:quadroedu/adapters/student.dart';
import 'package:quadroedu/classes/styles.dart';
import 'package:quadroedu/classes/variables.dart';
import 'package:quadroedu/screens/marks_screen.dart';
import 'package:quadroedu/screens/mysession_screen.dart';
import 'package:quadroedu/screens/wallet_screen.dart';
import 'package:quadroedu/screens/account_screen.dart';
import 'package:quadroedu/screens/callus_screen.dart';
import 'package:quadroedu/widgtes/chapter_card.dart';
import 'package:http/http.dart' as http;
class ChaptersScreen extends StatefulWidget {
  const ChaptersScreen({super.key});
  @override
  State<ChaptersScreen> createState() => _ChaptersScreenState();
}
int screenIndex = 0;
List chapters = [];
Student getStudent(){
  return Variables().settings.get("Credits");
}
class _ChaptersScreenState extends State<ChaptersScreen> {
  async()async{
    http.Response chaptersResponse = await http.post(
      Uri.parse(
        "${Variables().url}get_chapters.php",
      ),
      body: {
        "stage":getStudent().stage,
      }
    );
    Map chaptersResponseMap = json.decode(chaptersResponse.body);
    chaptersResponseMap.forEach((key,value){
      setState(() {
        chapters.insert(chaptersResponseMap.keys.toList().indexOf(key),value);
      });
    });
  }
  @override
  void initState() {
    async();
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width - 205;
    final crossAxisCount = screenWidth ~/ 300;
    List<Widget> screens = [
      HomeIndex(crossAxisCount: crossAxisCount),
      WalletScreen(),
      MySessionsScreen(),
      MarksScreen(),
      AccountScreen(),
      CallusScreen(),
    ];
    return Scaffold(
      backgroundColor: Variables().secondColor,
      body: ConstrainedBox(
        constraints: BoxConstraints(
          minWidth: 800, // Minimum width
          minHeight: 600, // Minimum height
        ),
        child: Row(
          children: [
            // Left side GridView.builder
            screens[0],
            // Right side navigation bar
            Container(
              width: 150,
              decoration: BoxDecoration(
                color: Variables().mainColor,
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(20),
                  bottomLeft: Radius.circular(20),
                ),
              ),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    // CircularAvatar logo
                    // const SizedBox(height: 20),
                    Container(
                      width: 50,
                      decoration: BoxDecoration(
                        color: Variables().mainColor,
                        borderRadius: BorderRadius.circular(18)
                      ),
                      // backgroundColor: Colors.white,
                      // backgroundImage: AssetImage("images/logo.jpg"),
                      child: Image.asset("images/facebooklogo.jpg"),
                    ),
                    // const SizedBox(height: 20),
                    // Wallet button
                    SizedBox(
                      height: 80,
                      child: ElevatedButton.icon(
                        style: Styles().buttonStyle(Colors.white,
                            const Color.fromARGB(134, 158, 158, 158), 0,
                            bordersidecolor: Variables().mainColor),
                        onPressed: () async {
                          // await Variables().updateChapter(field, value)
                          setState(() {
                            screenIndex = 0;
                          });
                        },
                        icon: Icon(
                          Icons.home,
                          size: 30,
                          color: Colors.black,
                        ),
                        label: AutoSizeText(
                          'Home',
                          style: Styles().style(20, Colors.black, false),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 80,
                      child: ElevatedButton.icon(
                        style: Styles().buttonStyle(Colors.white,
                            const Color.fromARGB(134, 158, 158, 158), 0,
                            bordersidecolor: Variables().mainColor),
                        onPressed: () {
                          // setState(() {
                          //   screenIndex = 1;
                          // });
                          Navigator.push(context, MaterialPageRoute(builder: (context)=>WalletScreen()));
                        },
                        icon: Icon(
                          Icons.wallet,
                          size: 30,
                          color: Colors.black,
                        ),
                        label: AutoSizeText(
                          'Wallet',
                          style: Styles().style(20, Colors.black, false),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 80,
                      child: ElevatedButton.icon(
                        style: Styles().buttonStyle(Colors.white,
                            const Color.fromARGB(134, 158, 158, 158), 0,
                            bordersidecolor: Variables().mainColor),
                        onPressed: () {
                          // setState(() {
                          //   screenIndex = 4;
                          // });
                          Navigator.push(context, MaterialPageRoute(builder: (context)=>AccountScreen()));
                        },
                        icon: Icon(
                          Icons.person,
                          size: 30,
                          color: Colors.black,
                        ),
                        label: AutoSizeText(
                          'Account',
                          style: Styles().style(17, Colors.black, false),
                        ),
                      ),
                    ),
                    // // const SizedBox(height: 20),
                    // SizedBox(
                    //   height: 80,
                    //   child: ElevatedButton.icon(
                    //     style: Styles().buttonStyle(Colors.white,
                    //         const Color.fromARGB(134, 158, 158, 158), 0,
                    //         bordersidecolor: Variables().mainColor),
                    //     onPressed: () {
                    //       // setState(() {
                    //       //   screenIndex = 5;
                    //       // });
                    //       Navigator.push(context, MaterialPageRoute(builder: (context)=>CallusScreen()));
                    //     },
                    //     icon: Icon(
                    //       Icons.call_sharp,
                    //       size: 30,
                    //       color: Colors.black,
                    //     ),
                    //     label: AutoSizeText(
                    //       'Call us',
                    //       style: Styles().style(20, Colors.black, false),
                    //     ),
                    //   ),
                    // ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
 
class HomeIndex extends StatelessWidget {
  const HomeIndex({super.key,required this.crossAxisCount});
  final int crossAxisCount;
  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GridView.builder(
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: crossAxisCount > 0 ? crossAxisCount : 1,
          childAspectRatio: 1,
          crossAxisSpacing: 10,
          mainAxisSpacing: 10,
        ),
        itemCount: chapters.length,
        itemBuilder: (context, index) {
          return ChapterCard(
            chpName: chapters.elementAt(index)['name'],
            stage: getStudent().stage,
            chpurl: chapters.elementAt(index)['image'],
          );
        },
      ),
    );
  }
}