import 'dart:convert';
import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:quadroedu/adapters/homework.dart';
import 'package:quadroedu/adapters/quiz.dart';
import 'package:quadroedu/adapters/session.dart';
import 'package:quadroedu/classes/variables.dart';
import 'package:quadroedu/widgtes/session_card.dart';
import 'package:http/http.dart' as http;
class ChapterScreen extends StatefulWidget {
  const ChapterScreen({super.key, required this.chapterName, required this.chapterStage});
  final String chapterName;
  final String chapterStage;
  @override
  State<ChapterScreen> createState() => _ChapterScreenState();
}
List sessions = [];
class _ChapterScreenState extends State<ChapterScreen> {
  async()async{
    http.Response sessionsResponse = await http.post(
      Uri.parse(
        "${Variables().url}get_sessions.php",
      ),
      body:{
        "chpname": widget.chapterName,
        "chpstage": widget.chapterStage,
        "state":Variables().getStudent().state
      }
    );
    Map sessionsResponseMap = json.decode(sessionsResponse.body);
    sessionsResponseMap.forEach( (key,value) {
      setState(() {
        sessions.insert(sessionsResponseMap.keys.toList().indexOf(key),value);
      });
    });
  }
  @override
  void initState() {
    sessions.clear();
    async();
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width - 205;
    final crossAxisCount = screenWidth ~/ 300;
    return Scaffold(
      backgroundColor: Variables().secondColor,
      appBar: AppBar(
        title: AutoSizeText(widget.chapterName),
        elevation: 20,
        bottomOpacity: 0.7,
      ),
      body: GridView.builder(
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: crossAxisCount > 0 ? crossAxisCount : 1,
          childAspectRatio: 1,
          crossAxisSpacing: 10,
          mainAxisSpacing: 10,
        ),
        itemCount: sessions.length,
        itemBuilder: (context, index) {
          Session sessionnow = Session(
            price: sessions.elementAt(index)['price'],
            stage: widget.chapterStage,
            isBuyable: "true",
            name: sessions.elementAt(index)['name'],
            videos: [],
            docs: [],
            mark: "",
            quiz: Quiz(
              quizTimer: sessions.elementAt(index)['quiztimer'],
              onSession: sessions.elementAt(index)['onSession'],
              sessionName: sessions.elementAt(index)['name'],
              questions: [],
              stage: widget.chapterStage,
              successMark: sessions.elementAt(index)['quizSuccessMark'],
              fullMark: sessions.elementAt(index)['quizFullMark']
            ),
            url: sessions.elementAt(index)['image'],
            homework: Homework(
              sessionName: sessions.elementAt(index)['name'],
              questions: [
                // Question(
                //   imageUrl: "images/school.jpg",
                //   mark: "2",
                //   isMCQ: true,
                //   question: "1+1",
                //   rightLetter: "a",
                //   wrong1: "b",
                //   wrong2: "c",
                //   wrong3: "d",
                //   quizid: "12",
                //   sessionname: "session",
                //   sessionstage: "",
                //   id:"1"
                // ),
              ],
              stage: widget.chapterStage,
              successMark: sessions.elementAt(index)['hwSuccessMark'],
              fullMark: sessions.elementAt(index)['hwFullMark'],
              mark: ""
            )
          );
          return SessionCard(
            isbought: Variables().isbought(sessionnow,widget.chapterName),
            chpname: widget.chapterName,
            session: Session(
              price: sessions.elementAt(index)['price'],
              stage: widget.chapterStage,
              isBuyable: "true",
              name: sessions.elementAt(index)['name'],
              videos: [],
              docs: [
                // {
                //   "doctitle":"Pdf 1",
                //   "doclink":"https://balanceacademyfiles.b-cdn.net/(1)%20%D8%A7%D8%AC%D8%A7%D8%A8%D8%A9%20%D8%A7%D9%84%D9%85%D8%B1%D8%A7%D8%AC%D8%B9%D8%A9%20%D8%A7%D8%A7%D9%84%D8%A7%D9%88%D9%84%D9%89.pdf"
                // }
              ],
              mark: "",
              quiz: Quiz(
                quizTimer: sessions.elementAt(index)['quiztimer'],
                onSession: sessions.elementAt(index)['onSession'],
                sessionName: sessions.elementAt(index)['name'],
                questions: [
                  // Question(
                  //   imageUrl: "images/school.jpg",
                  //   mark: "1",
                  //   isMCQ: false,
                  //   question: "1+1",
                  //   rightLetter: "c",
                  //   wrong1: "b",
                  //   wrong2: "a",
                  //   wrong3: "d",
                  //   quizid: "12",
                  //   sessionname: "session",
                  //   sessionstage: "",
                  //   id: "3"
                  // ),
                ],
                stage: widget.chapterStage,
                successMark: sessions.elementAt(index)['quizSuccessMark'],
                fullMark: sessions.elementAt(index)['quizFullMark']
              ),
              url: sessions.elementAt(index)['image'],
              homework: Homework(
                sessionName: sessions.elementAt(index)['name'],
                questions: [
                  // Question(
                  //   imageUrl: "images/school.jpg",
                  //   mark: "2",
                  //   isMCQ: true,
                  //   question: "1+1",
                  //   rightLetter: "a",
                  //   wrong1: "b",
                  //   wrong2: "c",
                  //   wrong3: "d",
                  //   quizid: "12",
                  //   sessionname: "session",
                  //   sessionstage: "",
                  //   id:"1"
                  // ),
                ],
                stage: widget.chapterStage,
                successMark: sessions.elementAt(index)['hwSuccessMark'],
                fullMark: sessions.elementAt(index)['hwFullMark'],
                mark: ""
              )
            ),
          );
        }
      ),
    );
  }
}