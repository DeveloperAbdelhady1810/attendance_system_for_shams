import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:quadroedu/classes/styles.dart';
import 'package:quadroedu/classes/variables.dart';
import 'package:quadroedu/screens/landing_screen.dart';
import 'package:auto_size_text/auto_size_text.dart';
import 'package:quadroedu/screens/new/landing_page.dart';
// import 'package:quadroedu/classes/variables.dart';
// import 'package:google_fonts/google_fonts.dart';
class AccountScreen extends StatefulWidget {
  const AccountScreen({super.key});
  @override
  State<AccountScreen> createState() => _AccountScreenState();
}
class _AccountScreenState extends State<AccountScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Account'),
      ),
      body: SingleChildScrollView(
        child: Card(
          shadowColor: Variables().mainColor,
          elevation: 20,
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                Icon(
                  Icons.person,
                  size: 100,
                  color: Variables().mainColor,
                ),
                const SizedBox(height: 20,),
                AutoSizeText(
                  Variables().getStudent().name,
                  style: Styles().style(30, Variables().mainColor, true),
                ),
                SizedBox(
                  width: 500,
                  child: Card(
                    child: AutoSizeText(
                      "Phone: ${Variables().getStudent().phone}",
                      style: Styles().style(20, Colors.black, true),
                    ),
                  ),
                ),
                SizedBox(
                  width: 500,
                  child: Card(
                    child: AutoSizeText(
                      "Parent: ${Variables().getStudent().parrentPhone}",
                      style: Styles().style(20, Colors.black, true),
                    ),
                  ),
                ),
                SizedBox(
                  width: 500,
                  child: Card(
                    child: AutoSizeText(
                      "Stage: ${Variables().getStudent().stage}",
                      style: Styles().style(20, Colors.black, true),
                    ),
                  ),
                ),
                SizedBox(
                  width: 500,
                  child: Card(
                    child: AutoSizeText(
                      "ID: ${Variables().getStudent().cardId}",
                      style: Styles().style(20, Colors.black, true),
                    ),
                  ),
                ),
                Align(
                  alignment: Alignment.centerLeft,
                  child: AutoSizeText("QR: ",style: Styles().style(15, Colors.black, true)),
                ),
                Align(
                  alignment: Alignment.topRight,
                  child: SizedBox(
                    width: 250,
                    height: 250,
                    child: Align(
                      alignment: Alignment.center,
                      child: QrImageView(
                        data: Variables().getStudent().cardId,
                        size: 200,
                        version: 1,
                        // embeddedImage: const AssetImage("images/logo.jpg")
                      ),
                    ),
                  ),
                ),
                // Spacer(),
                TextButton(
                  style: Styles().buttonStyle(Colors.red, Colors.red.shade900, 20),
                  onPressed: ()async{
                    await Variables().settings.delete("Credits");
                    Navigator.pop(context);
                    Navigator.push(context, MaterialPageRoute(builder: (context)=>LandingPage()));
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: AutoSizeText(
                      "Logout",
                      style: Styles().style(25, Colors.white, true),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}