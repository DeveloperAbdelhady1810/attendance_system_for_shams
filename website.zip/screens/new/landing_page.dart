import 'dart:convert';
import 'dart:ui_web' as ui;
import 'dart:html';
import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:quadroedu/classes/styles.dart';
import 'package:quadroedu/classes/variables.dart';
import 'package:http/http.dart' as http;
import 'package:quadroedu/screens/chapters_screen.dart';
import 'package:video_player/video_player.dart';
import 'dart:js' as js;
import 'package:flutter_widget_from_html/flutter_widget_from_html.dart';
class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}
class _LandingPageState extends State<LandingPage> {
  late VideoPlayerController _controller;
  // late YoutubePlayerController _controller;
  // final controller = YoutubePlayerController.fromVideoId(
  //   videoId: "Kn8mwOZ-Cwc",
  //   autoPlay: false,
  //   params: const YoutubePlayerParams(
  //     showFullscreenButton: true
  //   )
  // );
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController nameController = TextEditingController();
  TextEditingController phoneController = TextEditingController();
  TextEditingController parentPhoneController = TextEditingController();
  TextEditingController schoolController = TextEditingController();
  bool loadingLogin = false;
  bool createAccount = false;
  bool isSignedIn = Variables().settings.get("Credits") != null ? true : false;
  String selectedState = "Center";
  String selectedStage = "First Secondry";
  String selectedScientific = "true";
  String selectedCenter = "The First El Haram";
  @override
  void initState() {
    super.initState();
    _controller = VideoPlayerController.asset('images/intro.mp4')
      ..initialize().then((_) {
        setState(() {}); // Ensure the first frame is shown
      });
    // final IFrameElement _iframeElement = IFrameElement();
    // _iframeElement.src = 'https://www.youtube.com/embed/Kn8mwOZ-Cwc?si=0iXgGC_18hmjQsG3';
    // _iframeElement.style.border = 'none';
    // _iframeElement.width = '100%';
    // _iframeElement.height = '500px';

    // ui.platformViewRegistry.registerViewFactory(
    //   'myIframe',
    //   (int viewId) => _iframeElement,
    // );
    // _controller = YoutubePlayerController(
    //   params: YoutubePlayerParams(
    //     showControls: true,
    //     mute: false,
    //     showFullscreenButton: true,
    //     loop: false,
    //     enableJavaScript: true,
    //   ),
    // )..loadVideoById(videoId: 'Kn8mwOZ-Cwc');
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Variables().secondColor,
        elevation: 20,
        title: Text(
          "Balance Academy",
          style: Styles().style(25, Colors.white, true)
        ),
        actions: [
          !isSignedIn?
          TextButton(
            onPressed: (){
              showDialog(context: context, builder: (context)=>Dialog(
                child: StatefulBuilder(
                  builder: (context,setState2) => SizedBox(
                    width: 300,
                    child: Card(
                      elevation: 20,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                        side: BorderSide(
                          color: Colors.black,
                          width: 2,
                        ),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(20),
                        child: 
                          SingleChildScrollView(
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                AutoSizeText(
                                  "Login",
                                  style:Styles().style(20, Color.fromRGBO(139,97,48,1), true),
                                ),
                                const SizedBox(
                                  height: 10,
                                ),
                                TextField(
                                  decoration: InputDecoration(
                                    labelText: "Phone / ID",
                                    border: OutlineInputBorder(),
                                    prefixIcon: Icon(Icons.email),
                                  ),
                                  controller: emailController,
                                ),
                                const SizedBox(
                                  height: 10,
                                ),
                                TextField(
                                  decoration: InputDecoration(
                                    labelText: "Password",
                                    border: OutlineInputBorder(),
                                    prefixIcon: Icon(Icons.password),
                                  ),
                                  controller: passwordController,
                                ),
                                const SizedBox(
                                  height: 10,
                                ),
                                TextButton(
                                  style: Styles().buttonStyle(Variables().mainColor,Variables().secondColor, 18,bordersidecolor: Variables().secondColor),
                                  onPressed: () async {
                                    if(loadingLogin == true){}else{
                                      setState2(() {
                                        loadingLogin = true;
                                      });
                                      http.Response loginResponse = await http.post(
                                        Uri.parse("${Variables().url}login.php"),
                                        body: {
                                          "token": emailController.text,
                                          "password":passwordController.text,
                                          "mac":await Variables().getUserAgent()
                                        }
                                      );
                                      if (loginResponse.statusCode == 202) {
                                        String responseText = loginResponse.body.toString();
                                        Map responseData = jsonDecode(responseText);
                                        await Variables().loginStudent(responseData);
                                        Navigator.pop(context);
                                        ScaffoldMessenger.of(context).showSnackBar(
                                          SnackBar(
                                            backgroundColor: Colors.green,
                                            content: Row(
                                              mainAxisAlignment:MainAxisAlignment.spaceBetween,
                                              children: [
                                                Icon(
                                                  Icons.check,
                                                  color: Colors.white,
                                                  size: 30
                                                ),
                                                AutoSizeText(
                                                  "Welcome Back ${responseData['name']}",
                                                  style: Styles().style(25,Colors.white,true),
                                                ),
                                                const SizedBox()
                                              ]
                                            )
                                          )
                                        );
                                        setState(() {
                                          isSignedIn = true;
                                        });
                                        if(passwordController.text==""){
                                          showDialog(context: context, builder: (context)=>Dialog(
                                            child: Padding(
                                              padding: const EdgeInsets.all(18),
                                              child:Column(
                                                children:[
                                                  AutoSizeText(
                                                    "Create Password",
                                                    style:Styles().style(25,Variables().mainColor,true)
                                                  ),
                                                  const SizedBox(height: 15,),
                                                  TextField(
                                                    decoration: InputDecoration(
                                                      labelText: "Password",
                                                      border: OutlineInputBorder(),
                                                      prefixIcon: Icon(Icons.password),
                                                    ),
                                                    controller: passwordController,
                                                  ),
                                                  const SizedBox(height: 15),
                                                  TextButton(
                                                    style: Styles().buttonStyle(Variables().mainColor, Variables().secondColor, 18),
                                                    onPressed: ()async{
                                                      http.Response response = await http.post(
                                                        Uri.parse(
                                                          "${Variables().url}set_password.php"
                                                        ),
                                                        body:{
                                                          "phone":Variables().getStudent().phone,
                                                          "password":passwordController.text
                                                        }
                                                      );
                                                      if(response.statusCode==202){
                                                        Navigator.pop(context);
                                                        Navigator.pop(context);
                                                        // Navigator.push(context,MaterialPageRoute(builder: (context)=>ChaptersScreen()));
                                                      }else{
                                                        Navigator.pop(context);
                                                        Navigator.pop(context);
                                                        // Navigator.push(context,MaterialPageRoute(builder: (context)=>ChaptersScreen()));
                                                      }
                                                    },
                                                    child: AutoSizeText(
                                                      "Save Password",
                                                      style: Styles().style(25, Colors.white, true),
                                                    ),
                                                  )
                                                ]
                                              )
                                            )
                                          ));
                                        }
                                      } else if(loginResponse.statusCode == 303){
                                        Navigator.pop(context);
                                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                          backgroundColor: Colors.red,
                                          content: Row(
                                            mainAxisAlignment:MainAxisAlignment.spaceBetween,
                                            children: [
                                              Icon(Icons.clear,color: Colors.white,size: 30),
                                              AutoSizeText(
                                                "Wrong Device",
                                                style: Styles().style(25,Colors.white,true),
                                              ),
                                              const SizedBox(),
                                            ]
                                          )
                                        )
                                      );
                                      }else{
                                        Navigator.pop(context);
                                        ScaffoldMessenger.of(context).showSnackBar(
                                          SnackBar(
                                            backgroundColor: Colors.red,
                                            content: Row(
                                              mainAxisAlignment:MainAxisAlignment.spaceBetween,
                                              children: [
                                                Icon(Icons.clear,color: Colors.white,size: 30),
                                                AutoSizeText(
                                                  "Invalid Login",
                                                  style: Styles().style(25,Colors.white,true),
                                                ),
                                                const SizedBox(),
                                              ]
                                            )
                                          )
                                        );
                                      }
                                      setState2(() {
                                        loadingLogin = false;
                                      });
                                    }
                                  },
                                  child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: !loadingLogin
                                    ? AutoSizeText(
                                        "Login",
                                        style: Styles().style(25, Colors.white, false),
                                      )
                                    : CircularProgressIndicator(color: Colors.white,),
                                  )
                                ),
                                const SizedBox(height: 10,),
                              ],
                            ),
                          )
                        )
                      ),
                  ),
                ),
              ));
            },
            style: Styles().buttonStyle(Colors.white, Colors.grey, 18,bordersidecolor: Colors.black),
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(
                "Login",
                style: Styles().style(20,Colors.black,false),
              ),
            ),
          )
          :
          const SizedBox(),
          !isSignedIn?
          TextButton(
            onPressed: (){
              showDialog(context:context,builder: (context) => StatefulBuilder(
                builder: (context, setState2) {
                  return Dialog(
                    child: Padding(
                      padding: const EdgeInsets.all(18.0),
                      child: SingleChildScrollView(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            AutoSizeText(
                              "Create Account",
                              style:Styles().style(20, Variables().mainColor, true),
                            ),
                            const SizedBox(
                              height: 10,
                            ),
                            TextField(
                              decoration: InputDecoration(
                                labelText: "Name",
                                border: OutlineInputBorder(),
                                prefixIcon: Icon(Icons.person),
                              ),
                              controller: nameController,
                            ),
                            const SizedBox(
                              height: 10,
                            ),
                            TextField(
                              decoration: InputDecoration(
                                labelText: "Phone",
                                border: OutlineInputBorder(),
                                prefixIcon: Icon(Icons.phone),
                              ),
                              controller: phoneController,
                            ),
                            const SizedBox(
                              height: 10,
                            ),
                            TextField(
                              decoration: InputDecoration(
                                labelText: "Parent Phone",
                                border: OutlineInputBorder(),
                                prefixIcon: Icon(Icons.phone),
                              ),
                              controller: parentPhoneController,
                            ),
                            const SizedBox(
                              height: 10,
                            ),
                            TextField(
                              decoration: InputDecoration(
                                labelText: "School",
                                border: OutlineInputBorder(),
                                prefixIcon: Icon(Icons.school),
                              ),
                              controller: schoolController,
                            ),
                            const SizedBox(
                              height: 10,
                            ),
                            DropdownButton(
                              value: selectedStage,
                              items: [
                                DropdownMenuItem(
                                  value: null,
                                  child: AutoSizeText("Select Stage"),
                                ),
                                DropdownMenuItem(
                                  value: "First Secondry",
                                  child: AutoSizeText("First Secondry"),
                                ),
                                DropdownMenuItem(
                                  value: "Second Secondry",
                                  child: AutoSizeText("Second Secondry"),
                                ),
                                DropdownMenuItem(
                                  value: "Third Secondry",
                                  child: AutoSizeText("Third Secondry"),
                                ),
                              ],
                              onChanged: (value)async{
                                
                                setState2(() {
                                  selectedStage = value as String;
                                }
                              );
                              }
                            ),
                            const SizedBox(height: 10,),
                            DropdownButton(
                              value: selectedState,
                              items: [
                                DropdownMenuItem(
                                  value: null,
                                  child: AutoSizeText("Select State"),
                                ),
                                DropdownMenuItem(
                                  value: "Online",
                                  child: AutoSizeText("Online"),
                                ),
                                DropdownMenuItem(
                                  value: "Center",
                                  child: AutoSizeText("Center"),
                                )
                              ],
                              onChanged: (value){
                                setState2(() {
                                  selectedState = value as String;
                                });
                              }
                            ),
                            const SizedBox(height: 10,),
                            selectedState == "Center"?
                            DropdownButton(
                              value: selectedCenter,
                              items: [
                                DropdownMenuItem(
                                  value: null,
                                  child: AutoSizeText("Select Center"),
                                ),
                                DropdownMenuItem(
                                  value: "The First El Haram",
                                  child: AutoSizeText("The First El Haram"),
                                ),
                                DropdownMenuItem(
                                  value: "The Frist El Fardoos",
                                  child: AutoSizeText("The Frist El Fardoos"),
                                ),
                                DropdownMenuItem(
                                  value: "A-One El Haram",
                                  child: AutoSizeText("A-One El Haram"),
                                ),
                                DropdownMenuItem(
                                  value: "A-One Hadaye` El Ahram",
                                  child: AutoSizeText("A-One Hadaye` El Ahram"),
                                ),
                                DropdownMenuItem(
                                  value: "Trust El Haram",
                                  child: AutoSizeText("Trust El Haram"),
                                ),
                                DropdownMenuItem(
                                  value: "Teachers Hadaye` El Ahram",
                                  child: AutoSizeText("Teachers Hadaye` El Ahram"),
                                ),
                              ],
                              onChanged: (value){
                                setState2(() {
                                  selectedCenter = value as String ;
                                });
                              }
                            ):const SizedBox(),
                            const SizedBox(height: 10,),
                            TextField(
                              decoration: InputDecoration(
                                labelText: "Password",
                                border: OutlineInputBorder(),
                                prefixIcon: Icon(Icons.password),
                              ),
                              controller: passwordController,
                            ),
                            const SizedBox(
                              height: 10,
                            ),
                            TextButton(
                              style: Styles().buttonStyle(Variables().mainColor,Variables().secondColor, 18,bordersidecolor: Variables().secondColor),
                              onPressed: () async {
                                String? mac_address = await Variables().getUserAgent();
                                // print("${ip}register.php?firstname=${firstName.text}&lastname=${lastName.text}&email=${email.text}&phone=${phone.text}&stage=${stage.toString().replaceAll(' ','Ahmed')}&gender=$gender&parrentemail=${parrentEmail.text}&parrentphone=${parrentPhone.text}&mode=1&mac=${(mac_address).toString().replaceAll(" ", "Ahmed")}");
                                http.Response response = await http.post(
                                  Uri.parse("${Variables().url}register.php"),
                                  body: {
                                    "name":nameController.text,
                                    "phone": phoneController.text,
                                    "parentphone":parentPhoneController.text,
                                    "stage":selectedStage,
                                    "mac":mac_address,
                                    "password":passwordController.text,
                                    "center":selectedState=="Center"? selectedCenter:"Online",
                                    "state":selectedState,
                                    "school":schoolController.text,
                                  }
                                );
                                if (response.statusCode == 202) {
                                  // print('Request was successful. Response body: ${response.body}');
                                  Navigator.pop(context);
                                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: Colors.green,content: AutoSizeText("Success",style: Styles().style(25, Colors.white, true),)));
                                } else if(response.statusCode==303){
                                  // print('Request was failed. Response body: ${response.body}');
                                  Navigator.pop(context);
                                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: Colors.red,content: AutoSizeText("Failed, you have an account with id:${response.body}",style: Styles().style(25, Colors.white, true),)));
                                }else{
                                  // print('Request failed with status code: ${response.statusCode}, reason phrase: ${response.reasonPhrase}');
                                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: Colors.red,content: AutoSizeText("Failed With code: ${response.statusCode}",style: Styles().style(25, Colors.white, true),)));
                                }
                              },
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: !loadingLogin
                                ? AutoSizeText(
                                    "Create Account",
                                    style: Styles().style(25,Colors.white,false),
                                  )
                                : CircularProgressIndicator(color: Colors.white,),
                              )
                            ),
                            const SizedBox(height: 10,),
                            
                          ],
                        ),
                      ),
                    ),
                  );
                }
              ));
            
            },
            style: Styles().buttonStyle(Colors.white, Colors.grey, 18,bordersidecolor: Colors.black),
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(
                "Create Account",
                style: Styles().style(20,Colors.black,false),
              ),
            ),
          )
          :
          TextButton(
            style: Styles().buttonStyle(Colors.white,Colors.grey, 18,bordersidecolor: Variables().mainColor),
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: AutoSizeText(
                "Continue Learning",
                style: Styles().style(25, Variables().secondColor, false),
              ),
            ),
            onPressed: () async {
              Navigator.of(context).pop();
              Navigator.push(context,MaterialPageRoute(builder: (context) =>ChaptersScreen()));
            }
          )
        ],
      ),
      extendBodyBehindAppBar: false,
      extendBody: false,
      body: SingleChildScrollView(
        child: Column(
          children: [
            // Header
            Container(
              child: Image.asset(
                "images/header.png"
              )
              // decoration: BoxDecoration(
              //   image: DecorationImage(
              //     fit: BoxFit.cover,
              //     image: AssetImage(
              //       "images/header.png",
              //     )
              //   )
              // ),
              // child: SizedBox(
              //   height: MediaQuery.of(context).size.height,
              //   child: Column(
              //     mainAxisSize: MainAxisSize.min,
              //     children: [
              //       Align(
              //         alignment: Alignment.topRight,
              //         child: Padding(
              //           padding: const EdgeInsets.only(
              //             left: 15.0,
              //             top: 100.0
              //           ),
              //           child: Text(
              //             "Welcome to Balance Academy",
              //             style: Styles().style(40, Colors.white, true,style: FontStyle.italic),
              //           ),
              //         ),
              //       ),
              //       Align(
              //         alignment: Alignment.topRight,
              //         child: SizedBox(
              //           width: 400,
              //           child: Padding(
              //             padding: const EdgeInsets.only(
              //               left: 30.0,
              //               top: 15.0
              //             ),
              //             child: Text(
              //               "Mr. Balance, with years of teaching experience and a passion for simplifying the language, is here to help you succeed in your exams and truly understand English.",
              //               overflow: TextOverflow.clip,
              //               style: Styles().style(15, Colors.white, true,style: FontStyle.italic),
              //             ),
              //           ),
              //         ),
              //       ),
              //     ],
              //   ),
              // ),
            ),
            ////////
            const SizedBox(height: 20,),
            
            Container(
              decoration: BoxDecoration(
                border: Border(
                  bottom: BorderSide(color: Colors.black,width: 2),
                  top: BorderSide(color: Colors.black,width: 2),
                  left: BorderSide(color: Colors.black,width: 2),
                  right: BorderSide(color: Colors.black,width: 2),
                ),
                borderRadius: BorderRadius.circular(20)
              ),
              padding: const EdgeInsets.all(15),
              child: SizedBox(
                width: MediaQuery.of(context).size.width,
                child: Center(
                  child: _controller.value.isInitialized
                    ? Column(
                      children: [
                        AspectRatio(
                          aspectRatio: _controller.value.aspectRatio,
                          child: _controller.value.isPlaying?VideoPlayer(_controller):Image.network("https://student.balance-academy.com/image.png"),
                        ),
                        TextButton(
                          onPressed: () {
                            setState(() {
                              _controller.value.isPlaying ? _controller.pause() : _controller.play();
                            });
                          },
                          child: Icon(
                            _controller.value.isPlaying ? Icons.pause : Icons.play_arrow,
                          ),
                        )
                      ],
                    )
                    : CircularProgressIndicator(),
                ),
              ),
            ),
            // Container(
              
            //   child: YoutubePlayerScaffold(
            //     builder: (context,player){
            //       return player;
            //     },
            //     controller: _controller
            //   )

            // ),
            // Expanded(
            //   child: YoutubePlayer(
            //     controller: _controller,
            //     aspectRatio: 16 / 9,
            //   ),
            // ),
            // Center(
            //   child: HtmlWidget(
            //     '''
            //     <iframe 
            //       height="315" 
            //       src="https://www.youtube.com/embed/Kn8mwOZ-Cwc" 
            //       frameborder="0" 
            //       allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
            //       allowfullscreen>
            //     </iframe>
            //     ''',
            //   ),
            // ),
    
            const SizedBox(height: 20,),
            // Social media cards
            Wrap(
              spacing: 20,
              children: [
                Container(
                  // height: 400,
                  width: 350,
                  decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.5),
                        spreadRadius: 5,
                      ),
                      BoxShadow(
                        color: Color.fromRGBO(139, 97, 48, 1).withOpacity(0.5),
                        spreadRadius: 5,
                      ),
                    ],
                    color: Colors.white.withOpacity(0.5),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(20.0),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Image.asset(
                          "images/facebooklogo.jpg"
                        ),
                        const SizedBox(height: 20,),
                        Align(
                          alignment: Alignment.topLeft,
                          child: Text(
                            "Mr Balance/ Mohamed Kamal",
                            style: TextStyle(fontSize: 20, color: Colors.black.withOpacity(0.8)),
                          ),
                        ),
                        const SizedBox(height: 15,),
                        Align(
                          alignment: Alignment.center,
                          child: Text(
                            "ESL (English) Teacher, IELTS Tutor, TEFL certified",
                            style: TextStyle(fontSize: 15, color: Colors.black.withOpacity(0.8)),
                          ),
                        ),
                        const SizedBox(height: 15,),
                        TextButton(
                          onPressed: ()async{
                            await js.context.callMethod("urlLauncher",["https://facebook.com/MrMohammedKamalB"]);
                          },
                          style: Styles().buttonStyle(Variables().mainColor, Variables().secondColor, 18),
                          child: Padding(
                            padding: const EdgeInsets.all(10),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Image.asset(
                                  "images/facebook.png",
                                  width: 20,
                                ),
                                const SizedBox(width: 5,),
                                Text(
                                  "Follow us on Facebook",
                                  style: Styles().style(20, Colors.white, false),
                                ),
                              ],
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                ),
                Container(
                  height: 520,
                  width: 350,
                  decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.5),
                        spreadRadius: 5,
                      ),
                      BoxShadow(
                        color: Color.fromRGBO(139, 97, 48, 1).withOpacity(0.5),
                        spreadRadius: 5,
                      ),
                    ],
                    color: Colors.white.withOpacity(0.5),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(20.0),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Image.asset(
                          "images/youobelogo.jpg"
                        ),
                        const SizedBox(height: 20,),
                        Align(
                          alignment: Alignment.topLeft,
                          child: Text(
                            "Mr Balance | Mohamed Kamal",
                            style: TextStyle(fontSize: 20, color: Colors.black.withOpacity(0.8)),
                          ),
                        ),
                        const SizedBox(height: 15,),
                        Align(
                          alignment: Alignment.center,
                          child: Text(
                            "Mr. Balance, with years of teaching experience and a passion for simplifying the language, is here to help you succeed in your exams and truly understand English.",
                            overflow: TextOverflow.clip,
                            style: TextStyle(fontSize: 15, color: Colors.black.withOpacity(0.8)),
                          ),
                        ),
                        const Spacer(),
                        TextButton(
                          onPressed: ()async{
                            await js.context.callMethod("urlLauncher",["https://youtube.com/@mrbalance2"]);
                          },
                          style: Styles().buttonStyle(Variables().mainColor, Variables().secondColor, 18),
                          child: Padding(
                            padding: const EdgeInsets.all(10),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Image.asset(
                                  "images/YouTube_play_button_icon_(2013–2017).png",
                                  width: 20,
                                ),
                                const SizedBox(width: 5,),
                                Text(
                                  "Subscribe on Channel",
                                  style: Styles().style(20, Colors.white, false),
                                ),
                              ],
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              ]
            ),
            ////////
            const SizedBox(height: 40,),
            /// footer
            Container(
              color: Variables().secondColor,
              padding: const EdgeInsets.all(20),
              child: Padding(
                padding: const EdgeInsets.all(10),
                child: Column(
                  children: [
                    Align(
                      alignment: Alignment.topLeft,
                      child: SizedBox(
                        width: MediaQuery.of(context).size.width,
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Align(
                              alignment: Alignment.center,
                              child: Text(
                                "Our Aim",
                                style: Styles().style(25, Colors.white, true),
                              ),
                            ),
                            const SizedBox(height: 20,),
                            Align(
                              alignment: Alignment.topLeft,
                              child: Text(
                                "Our mission is to inspire a love of English in every learner by creating a supportive, engaging, and interactive online environment. We strive to empower students at all levels to communicate confidently, think critically, and express themselves creatively in English. Through personalized resources and innovative teaching methods, our platform is dedicated to making language learning accessible, enjoyable, and meaningful for everyone, Mr Mohamed Kamal.",
                                overflow: TextOverflow.clip,
                                style: Styles().style(15, Colors.white, true),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Align(
                      alignment: Alignment.topRight,
                      child: SizedBox(
                        width: MediaQuery.of(context).size.width,
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            // links
                            Align(
                              alignment: Alignment.center,
                              child: Text(
                                "Social Links",
                                style: Styles().style(25, Colors.white, true),
                              ),
                            ),
                            const SizedBox(height: 10,),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Align(
                                  alignment: Alignment.topLeft,
                                  child: TextButton(
                                    style: Styles().buttonStyle(Variables().mainColor,Variables().secondColor,18),
                                    onPressed: ()async{
                                      await js.context.callMethod("urlLauncher",["https://facebook.com/MrMohammedKamalB"]);
                                    },
                                    child: Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Text(
                                        "Facebook",
                                        overflow: TextOverflow.clip,
                                        style: Styles().style(15, Colors.white, true),
                                      ),
                                    ),
                                  ),
                                ),
                                // const SizedBox(height: 10,),
                                Align(
                                  alignment: Alignment.topLeft,
                                  child: TextButton(
                                    style: Styles().buttonStyle(Colors.black,Colors.grey,18),
                                    onPressed: ()async{
                                      await js.context.callMethod("urlLauncher",["https://www.tiktok.com/@mr.balance.mohamedkamal"]);
                                    },
                                    child: Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Text(
                                        "TikTok",
                                        overflow: TextOverflow.clip,
                                        style: Styles().style(15, Colors.white, true),
                                      ),
                                    ),
                                  ),
                                ),
                                // const SizedBox(height: 10,),
                                Align(
                                  alignment: Alignment.topLeft,
                                  child: TextButton(
                                    style: Styles().buttonStyle(Colors.red,Colors.red.shade800,18),
                                    onPressed: ()async{
                                      await js.context.callMethod("urlLauncher",["https://youtube.com/@mrbalance2"]);
                                    },
                                    child: Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Text(
                                        "Youtube",
                                        overflow: TextOverflow.clip,
                                        style: Styles().style(15, Colors.white, true),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            ////////////
                            ///// QR
                            const SizedBox(height: 10),
                            Container(
                              padding: const EdgeInsets.all(5),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(18),
                                border: Border.all(color: Colors.white,width:2)
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    "Scan",
                                    style: Styles().style(20,Colors.white,false),
                                  ),
                                  SizedBox(
                                    width: 200,
                                    child: Image.asset("images/qr.jpeg")
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(height: 10),
                            ///
                            ///contact methods
                            Align(
                              alignment: Alignment.center,
                              child: Text(
                                "Contact us",
                                style: Styles().style(25, Colors.white, true),
                              ),
                            ),
                            const SizedBox(height: 10,),
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Text(
                                "Technical Support Phone: 010 90 91 08 28",
                                overflow: TextOverflow.clip,
                                style: Styles().style(15, Colors.white, true),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Text(
                                "Mr Phone: 01000 98 00 44",
                                overflow: TextOverflow.clip,
                                style: Styles().style(15, Colors.white, true),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Text(
                                "Assistant Phone: 01015489032",
                                overflow: TextOverflow.clip,
                                style: Styles().style(15, Colors.white, true),
                              ),
                            ),
                            // const SizedBox(height: 10,),
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Text(
                                "Email: contact@balance-academy.com",
                                overflow: TextOverflow.clip,
                                style: Styles().style(15, Colors.white, true),
                              ),
                            ),
                          ],
                        ),
                      ),
                    )
                    // Row(
                    //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    //   children: [
                    //     SizedBox(
                    //       width: MediaQuery.of(context).size.width/2 -10,
                    //       child: Column(
                    //         mainAxisSize: MainAxisSize.min,
                    //         children: [
                    //           Align(
                    //             alignment: Alignment.center,
                    //             child: Text(
                    //               "Our Aim",
                    //               style: Styles().style(25, Colors.white, true),
                    //             ),
                    //           ),
                    //           const SizedBox(height: 20,),
                    //           Align(
                    //             alignment: Alignment.topLeft,
                    //             child: Text(
                    //               "Our mission is to inspire a love of English in every learner by creating a supportive, engaging, and interactive online environment. We strive to empower students at all levels to communicate confidently, think critically, and express themselves creatively in English. Through personalized resources and innovative teaching methods, our platform is dedicated to making language learning accessible, enjoyable, and meaningful for everyone, Mr Mohamed Kamal.",
                    //               overflow: TextOverflow.clip,
                    //               style: Styles().style(15, Colors.white, true),
                    //             ),
                    //           ),
                    //         ],
                    //       ),
                    //     ),
                    //     SizedBox(
                    //       width: MediaQuery.of(context).size.width/2 -60,
                    //       child: Column(
                    //         mainAxisSize: MainAxisSize.min,
                    //         children: [
                    //           // links
                    //           Align(
                    //             alignment: Alignment.center,
                    //             child: Text(
                    //               "Social Links",
                    //               style: Styles().style(25, Colors.white, true),
                    //             ),
                    //           ),
                    //           const SizedBox(height: 10,),
                    //           Row(
                    //             mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    //             children: [
                    //               Align(
                    //                 alignment: Alignment.topLeft,
                    //                 child: TextButton(
                    //                   style: Styles().buttonStyle(Variables().mainColor,Variables().secondColor,18),
                    //                   onPressed: (){},
                    //                   child: Padding(
                    //                     padding: const EdgeInsets.all(8.0),
                    //                     child: Text(
                    //                       "Facebook",
                    //                       overflow: TextOverflow.clip,
                    //                       style: Styles().style(15, Colors.white, true),
                    //                     ),
                    //                   ),
                    //                 ),
                    //               ),
                    //               // const SizedBox(height: 10,),
                    //               Align(
                    //                 alignment: Alignment.topLeft,
                    //                 child: TextButton(
                    //                   style: Styles().buttonStyle(Colors.black,Colors.grey,18),
                    //                   onPressed: (){},
                    //                   child: Padding(
                    //                     padding: const EdgeInsets.all(8.0),
                    //                     child: Text(
                    //                       "TikTok",
                    //                       overflow: TextOverflow.clip,
                    //                       style: Styles().style(15, Colors.white, true),
                    //                     ),
                    //                   ),
                    //                 ),
                    //               ),
                    //               // const SizedBox(height: 10,),
                    //               Align(
                    //                 alignment: Alignment.topLeft,
                    //                 child: TextButton(
                    //                   style: Styles().buttonStyle(Colors.red,Colors.red.shade800,18),
                    //                   onPressed: (){},
                    //                   child: Padding(
                    //                     padding: const EdgeInsets.all(8.0),
                    //                     child: Text(
                    //                       "Youtube",
                    //                       overflow: TextOverflow.clip,
                    //                       style: Styles().style(15, Colors.white, true),
                    //                     ),
                    //                   ),
                    //                 ),
                    //               ),
                    //             ],
                    //           ),
                    //           ////////////
                    //           ///// QR
                    //           const SizedBox(height: 10),
                    //           Container(
                    //             padding: const EdgeInsets.all(5),
                    //             decoration: BoxDecoration(
                    //               borderRadius: BorderRadius.circular(18),
                    //               border: Border.all(color: Colors.white,width:2)
                    //             ),

                    //             child: Row(
                    //               mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    //               children: [
                    //                 Text(
                    //                   "Scan",
                    //                   style: Styles().style(20,Colors.white,false),
                    //                 ),
                    //                 SizedBox(
                    //                   width: 200,
                    //                   child: Image.asset("images/qr.jpeg")
                    //                 ),
                    //               ],
                    //             ),
                    //           ),
                    //           const SizedBox(height: 10),
                    //           ///
                    //           ///contact methods
                    //           Align(
                    //             alignment: Alignment.center,
                    //             child: Text(
                    //               "Contact us",
                    //               style: Styles().style(25, Colors.white, true),
                    //             ),
                    //           ),
                    //           const SizedBox(height: 10,),
                    //           Padding(
                    //             padding: const EdgeInsets.all(8.0),
                    //             child: Text(
                    //               "Phone: +201000980044",
                    //               overflow: TextOverflow.clip,
                    //               style: Styles().style(15, Colors.white, true),
                    //             ),
                    //           ),
                    //           // const SizedBox(height: 10,),
                    //           Padding(
                    //             padding: const EdgeInsets.all(8.0),
                    //             child: Text(
                    //               "Email: contact@balancacademy.com",
                    //               overflow: TextOverflow.clip,
                    //               style: Styles().style(15, Colors.white, true),
                    //             ),
                    //           ),
                    //         ],
                    //       ),
                    //     ),
                    //   ],
                    // ),
                    // Align(
                    //   alignment: Alignment.center,
                    //   child: Text(
                    //     "Proudly presented by Quadro",
                    //     style: Styles().style(12,Colors.white,false),
                    //   )
                    // )
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
// Our mission is to inspire a love of English in every learner by creating a supportive, engaging, and interactive online environment. We strive to empower students at all levels to communicate confidently, think critically, and express themselves creatively in English. Through personalized resources and innovative teaching methods, our platform is dedicated to making language learning accessible, enjoyable, and meaningful for everyone.
// Mr Mohamed Kamal