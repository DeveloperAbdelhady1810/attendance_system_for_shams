import 'package:flutter/material.dart';
import 'package:quadroedu/classes/styles.dart';
import 'package:quadroedu/classes/variables.dart';
import 'package:auto_size_text/auto_size_text.dart';
class WalletScreen extends StatefulWidget {
  const WalletScreen({super.key});
  @override
  State<WalletScreen> createState() => _WalletScreenState();
}
bool loading = false;
class _WalletScreenState extends State<WalletScreen> {
  TextEditingController codeController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: Builder(
          builder: (BuildContext context) {
            return IconButton(
              icon: const Icon(Icons.close,color:Colors.white ),
              onPressed: () { Navigator.pop(context); },
              tooltip: MaterialLocalizations.of(context).closeButtonTooltip,
            );
          },
        ),
        backgroundColor: Variables().secondColor,
        title: Text(
          'Wallet',
          style: Styles().style(25,Colors.white,true)
        ),
      ),
      body: SizedBox(
        width: MediaQuery.of(context).size.width-20,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: Align(
                alignment: Alignment.topLeft,
                child: Container(
                  padding: const EdgeInsets.all(5),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(18),
                    boxShadow: [
                      BoxShadow(color: Variables().secondColor,blurRadius: 5,spreadRadius: 5) ,
                      BoxShadow(color: Variables().mainColor,blurRadius: 5,spreadRadius: 5) ,
                    ]
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Icon(
                        Icons.account_balance_wallet,
                        color: Variables().mainColor,
                      ),
                      const SizedBox(width: 5,),
                      Text(
                        "${Variables().getStudent().balance} EGP",
                        style: Styles().style(25,Colors.black,true),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const SizedBox(),
                Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Align(
                      alignment: Alignment.topLeft,
                      child: Text(
                        "Charge with code",
                        style: Styles().style(20, Colors.black, true),
                      ),
                    ),
                    Container(
                      width: 400,
                      height: 50,
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        border: Border.all(
                          color: Variables().secondColor,
                        ),
                        borderRadius: BorderRadius.circular(20)
                      ),
                      child: TextField(
                        textAlign: TextAlign.center,
                        controller: codeController,
                        cursorColor: Variables().secondColor,
                        decoration: InputDecoration(
                          border: OutlineInputBorder(
                            borderSide: BorderSide.none,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 5,),
                    Container(
                      padding: const EdgeInsets.all(5),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(18),
                        boxShadow: [
                          BoxShadow(color: Variables().secondColor,blurRadius: 5,spreadRadius: 5) ,
                          BoxShadow(color: Variables().mainColor,blurRadius: 5,spreadRadius: 5) ,
                        ]
                      ),
                      child: TextButton.icon(
                        style: Styles().buttonStyle(Colors.white, Colors.grey, 20),
                        onPressed: ()async{
                          setState(() {
                            loading = true;
                          });
                          Map dataResponse = await Variables().charge_code(codeController.text);
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: dataResponse['status']==202?Colors.green:Colors.red,content: AutoSizeText(dataResponse['message'],style: Styles().style(25, Colors.white, true),)));
                          setState(() {
                            loading = false;
                          });
                        },
                        label: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child:!loading? AutoSizeText(
                            "Charge", 
                            style: Styles().style(25, Variables().secondColor, true),
                          )
                          :
                          CircularProgressIndicator(color: Variables().mainColor,),
                        )
                      ),
                    ),
                    const SizedBox(height: 5,),
                    Divider(color: Variables().mainColor,height: 2,),
                    const SizedBox(height: 5,),
                    Text(
                      "Other Payment Methods",
                      style: Styles().style(25, Colors.black, true),
                    ),
                    const SizedBox(height: 5,),
                    Text(
                      "Coming Soon",
                      style: Styles().style(18, Colors.black, false),
                    ),
                  ],
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
  // Container(
                //   width: MediaQuery.of(context).size.width,
                //   decoration: BoxDecoration(
                //     color: Colors.white,
                //     borderRadius: BorderRadius.circular(10),
                //   ),
                //   child: Padding(
                //     padding: const EdgeInsets.all(20),
                //     child: Align(
                //       alignment: Alignment.center,
                //       child: AutoSizeText(
                //         "You have: ${Variables().getStudent().balance} EGP",
                //         style: Styles().style(30, Variables().secondColor, true),
                //       ),
                //     ),
                //   ),
                // ),
                // const SizedBox(
                //   height: 15,
                // ),
                // Align(
                //   alignment: Alignment.topLeft,
                //   child: AutoSizeText(
                //     "Recharge your balance",
                //     style: Styles().style(30, Colors.white, true),
                //   ),
                // ),
                // const SizedBox(
                //   height: 20,
                // ),
                // TextField(
                //   controller: codeController,
                //   decoration: InputDecoration(
                //     border: OutlineInputBorder(
                //       borderRadius: BorderRadius.circular(10),
                //       borderSide: BorderSide(
                //         color: Colors.white,
                //         width: 3,
                //       ),
                //       gapPadding: 5
                //     ),
                //     enabledBorder: OutlineInputBorder(
                //       borderRadius: BorderRadius.circular(10),
                //       borderSide: BorderSide(
                //         color: Colors.white,
                //         width: 3,
                //       ),
                //       gapPadding: 5
                //     ),
                //     focusedBorder: OutlineInputBorder(
                //       borderRadius: BorderRadius.circular(10),
                //       borderSide: BorderSide(
                //         color: Colors.white,
                //         width: 3,
                //       ),
                //       gapPadding: 5
                //     ),
                //     disabledBorder: OutlineInputBorder(
                //       borderRadius: BorderRadius.circular(10),
                //       borderSide: BorderSide(
                //         color: Colors.white,
                //         width: 3,
                //       ),
                //       gapPadding: 5
                //     ),
                //     labelText: "Enter Your Code",
                //     labelStyle: Styles().style(25, Colors.white, false),
                //   ),
                //   style: Styles().style(25, Colors.white, true),
                // ),
                // const SizedBox(height: 15,),
                // TextButton.icon(
                //   style: Styles().buttonStyle(Colors.white, Colors.grey, 20),
                //   onPressed: ()async{
                //     setState(() {
                //       loading = true;
                //     });
                //     Map dataResponse = await Variables().charge_code(codeController.text);
                //     ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: dataResponse['status']==202?Colors.green:Colors.red,content: AutoSizeText(dataResponse['message'],style: Styles().style(25, Colors.white, true),)));
                //     setState(() {
                //       loading = false;
                //     });
                //   },
                //   label: Padding(
                //     padding: const EdgeInsets.all(8.0),
                //     child:!loading? AutoSizeText(
                //       "Charge", 
                //       style: Styles().style(25, Variables().secondColor, true),
                //     )
                //     :
                //     CircularProgressIndicator(color: Variables().mainColor,),
                //   )
                // ),
                // Spacer(),
                // Container(
                //   width: MediaQuery.of(context).size.width,
                //   decoration: BoxDecoration(
                //     color: Colors.white,
                //     borderRadius: BorderRadius.only(
                //       bottomLeft: Radius.circular(0),
                //       bottomRight: Radius.circular(0),
                //       topLeft: Radius.circular(500),
                //       topRight: Radius.circular(500),
                //     ),
                //   ),
                //   child: Padding(padding: const EdgeInsets.all(100)),
                // ),
              