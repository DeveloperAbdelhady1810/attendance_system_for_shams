import 'dart:convert';
import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:quadroedu/adapters/session.dart';
import 'package:http/http.dart' as http;
import 'package:quadroedu/classes/styles.dart';
import 'package:quadroedu/classes/variables.dart';
class AnswersScreen extends StatefulWidget {
  const AnswersScreen({super.key, required this.chpname, required this.chpstage, required this.session});
  final String chpname;
  final String chpstage;
  final Session session;
  @override
  State<AnswersScreen> createState() => _AnswersScreenState();
}
List questions = [];
int currentIndex = 0;
Map answers = {};
class _AnswersScreenState extends State<AnswersScreen> {
  async()async{
    http.Response response = await http.post(
      Uri.parse(
        "${Variables().url}get_answers.php"
      ),
      body: {
        "chpname": widget.chpname,
        "chpstage": widget.chpstage,
        "sessionname": widget.session.name,
        "state":"quiz",
        "phone":Variables().getStudent().phone
      }
    );
    if (response.statusCode == 202) {
      Map answersResponse = json.decode(response.body);
      answersResponse.forEach((key,value){
        setState((){
          answers.addAll(
            {
              value['questionid']:value['answer'],
            }
          );
        });
      });
    }
  }
  @override
  void initState() {
    questions.clear();
    answers.clear();
    async();
    questions.addAll(widget.session.quiz.questions);
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Center(
            child: AutoSizeText(
              'Quiz on ${widget.session.quiz.onSession}',
              style: Styles().style(30, Colors.black, true),
            ),
          ),
          Divider(
            thickness: 2,
            height: 2,
            color: Variables().mainColor,
          ),
          Card(
            elevation: 10,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
              side: BorderSide(color: Variables().mainColor, width: 2),
            ),
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                children: [
                  Image.network(
                    width: MediaQuery.of(context).size.width * 0.6,
                    height: MediaQuery.of(context).size.height * 0.3,
                    questions[currentIndex].imageUrl,
                    fit: BoxFit.cover,
                  ),
                  const SizedBox(height: 20),
                  AutoSizeText(
                    questions[currentIndex].question,
                    style: Styles().style(25, Colors.black, false),
                  ),
                  const SizedBox(height: 20),
                  AutoSizeText(
                    "Your Answer is :"+answers[questions[currentIndex].id]
                  ),
                  AutoSizeText(
                    "The right answer was :"+questions[currentIndex].rightLetter
                  ),
                ],
              )
            )
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              currentIndex>0?TextButton.icon(
                onPressed: () {
                  setState(() {
                    // _isA = answers[currentIndex-1]==null? false : answers[currentIndex-1]=="A"?true:false;
                    // _isB = answers[currentIndex-1]==null? false : answers[currentIndex-1]=="B"?true:false;
                    // _isC = answers[currentIndex-1]==null? false : answers[currentIndex-1]=="C"?true:false;
                    // _isD = answers[currentIndex-1]==null? false : answers[currentIndex-1]=="D"?true:false;
                    currentIndex--;
                  });
                },
                icon: Icon(
                  Icons.arrow_back_ios_new,
                  color: Variables().mainColor,
                  size: 30,
                ),
                label: AutoSizeText(
                  'Save & Back',
                  style: Styles().style(25, Variables().mainColor, false),
                ),
              ):const SizedBox(),
              TextButton.icon(
                onPressed: () async{
                  if (currentIndex<questions.length-1) {
                    setState(() {
                      // _isA = answers[currentIndex+1]==null? false : answers[currentIndex+1]=="A"?true:false;
                      // _isB = answers[currentIndex+1]==null? false : answers[currentIndex+1]=="B"?true:false;
                      // _isC = answers[currentIndex+1]==null? false : answers[currentIndex+1]=="C"?true:false;
                      // _isD = answers[currentIndex+1]==null? false : answers[currentIndex+1]=="D"?true:false;
                      currentIndex++;
                    });
                  } else {
                    Navigator.pop(context);
                    // await submitQuiz();
                  }
                },
                icon: Icon(
                  Icons.arrow_forward_ios,
                  color: Variables().mainColor,
                  size: 30,
                ),
                label: AutoSizeText(
                  currentIndex<questions.length-1?'Save & Next':'Save & Close',
                  style: Styles().style(25, Variables().mainColor, false),
                ),
              )
            ],
          ),
          const Spacer(),
          Wrap(
            children: questions
              .map((e) => Card(
                color:currentIndex==questions.indexOf(e)?Variables().mainColor: Colors.grey.withValues(alpha: 0.5),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                    side: BorderSide(
                      color:Colors.grey.withValues(alpha: 0.5),
                      width: 1,
                    ),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: TextButton(
                      onPressed: () {
                        setState(() {
                          currentIndex = questions.indexOf(e);
                          // _isA = answers[currentIndex]==null? false : answers[currentIndex]=="A"?true:false;
                          // _isB = answers[currentIndex]==null? false : answers[currentIndex]=="B"?true:false;
                          // _isC = answers[currentIndex]==null? false : answers[currentIndex]=="C"?true:false;
                          // _isD = answers[currentIndex]==null? false : answers[currentIndex]=="D"?true:false;
                        });
                      },
                      child: AutoSizeText(
                        (questions.indexOf(e) + 1).toString(),
                        style: Styles().style(20,currentIndex==questions.indexOf(e)?Colors.white: Colors.black, false),
                      ),
                    ),
                  ),
                )
              )
              .toList(),
        )
        ]
      ),
    );
  }
}