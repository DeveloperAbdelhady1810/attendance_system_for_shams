import 'dart:async';
import 'package:auto_size_text/auto_size_text.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:quadroedu/adapters/question.dart';
import 'package:quadroedu/adapters/session.dart';
import 'package:quadroedu/classes/styles.dart';
import 'package:http/http.dart' as http;
import 'package:quadroedu/classes/variables.dart';
import 'dart:js' as js;
class QuizScreen extends StatefulWidget {
  const QuizScreen({super.key, required this.session, required this.chpname, required this.chpstage});
  final Session session;
  final String chpname;
  final String chpstage;
  @override
  State<QuizScreen> createState() => _QuizScreenState();
}
late Timer _timer;
List questions = [];
Map answers = {};
List answersToChoose = [];
String choosedAnswer = "";
Map marks = {};
int currentIndex = 0;
// bool _isA = false;
// bool _isB = false;
// bool _isC = false;
// bool _isD = false;
late int _current;
String filenameuploaded = "";
bool uploading = false;
bool loadingAnswer = false;
class _QuizScreenState extends State<QuizScreen> {
  Future<String> uploadFile() async {
    final file = await FilePicker.platform.pickFiles();
    if (file != null) {
      final bytes = file.files[0].bytes;
      final url = 'https://storage.bunnycdn.com/balanceacademyfiles/${file.files[0].name}';
      final headers = {
        'AccessKey': '8a9a18a0-019f-4f1b-98f7a8a608d1-5981-4eb1',
        'Content-Type': 'application/octet-stream',
      };
      final response = await http.put(Uri.parse(url), headers: headers, body: bytes);
      if (response.statusCode == 201) {
        return "https://balanceacademyfiles.b-cdn.net/${file.files[0].name}";
      } else {
        print('Error uploading file: ${response.statusCode}');
        return "Error";
      }
    }else{
      return "no file";
    }
  }

  startTimer() async {
    const oneSec = Duration(seconds: 1);
    _timer = Timer.periodic(oneSec, (timer) async {
      if (_current == 0) {
        setState(() {
          timer.cancel();
        });
        await submitQuiz();
      } else {
        setState(() {
          _current--;
        });
      }
    });
  }
  @override
  void initState() {
    Variables().settings.delete(widget.session.quiz.onSession);
    _current = int.parse(widget.session.quiz.quizTimer) * 60;
    super.initState();
    questions.addAll(widget.session.quiz.questions);
    answersToChoose.addAll([questions[currentIndex].rightLetter,questions[currentIndex].wrong1,questions[currentIndex].wrong2,questions[currentIndex].wrong3]);
    answersToChoose.shuffle();
    startTimer();
  }
  submitQuiz()async{
    http.Response response = await http.post(
      Uri.parse(
        "${Variables().url}submit_mark.php",
      ),
      body:{
        "chpname":widget.chpname,
        "chpstage":widget.chpstage,
        "sessionname":widget.session.name,
        "phone":Variables().getStudent().phone,
        "state":"quiz",
        "mark": marks.isNotEmpty? marks.values.toList().reduce((a, b) => a + b).toString():"0",
      }
    );
    if(response.statusCode == 202){
      Navigator.pop(context);
    }else{
      print("${response.statusCode} Failed");
    }
  }
  addAnswer(String answer,Question question, value)async{
    setState((){
      loadingAnswer = true;
    });
    http.Response response = await http.post(
      Uri.parse(
        "${Variables().url}add_answer.php",
      ),
      body: {
        "answer": answer,
        "questionid": question.id,
        "question":question.question,
        "sessionname":question.sessionname,
        "chpstage":widget.session.stage,
        "chpname":question.chpname,
        "rightAnswer":question.rightLetter,
        "wrong1":question.wrong1,
        "wrong2":question.wrong2,
        "wrong3":question.wrong3,
        "state":"quiz",
        "phone":Variables().getStudent().phone,
        "imageurl":question.imageUrl,
        "mark":question.mark
      }
    );
    if (response.statusCode==202) {
    //   // success
      setState((){
        answers.addAll(
          {
            currentIndex:answer
          }
        );
        choosedAnswer = answer;
      });
    //   if (answer=="A") {
    //     setState(() {
    //       answers.addAll({currentIndex:"A"});
    //       _isB = false;
    //       _isC = false;
    //       _isD = false;
    //       _isA = true;
    //     });
    //   } else if(answer=="B"){
    //     setState(() {
    //       answers.addAll({currentIndex:"B"});
    //       _isA = false;
    //       _isC = false;
    //       _isD = false;
    //       _isB = true;
    //     });
    //   } else if(answer=="C"){
    //     setState(() {
    //       answers.addAll({currentIndex:"C"});
    //       _isA = false;
    //       _isB = false;
    //       _isD = false;
    //       _isC = true;
    //     });
    //   } else if(answer=="D"){
    //     setState(() {
    //       answers.addAll({currentIndex:"D"});
    //       _isA = false;
    //       _isB = false;
    //       _isC = false;
    //       _isD = true;
    //     });
    //   }
      if(question.rightLetter==answer){
        setState(() {
          marks.addAll({
            question.id:double.parse(question.mark),
          });
        });
      }else{
        setState(() {
          marks.addAll({
            question.id:0,
          });
        });
      }
    //   // print(marks);
    } else {
      // 303, 302 (Failed)
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: AutoSizeText("Error Code: ${response.statusCode}")));
    }
    setState((){
      loadingAnswer = false;
    });
  }
  @override
  void dispose() {
    questions.clear();
    answers.clear();
    marks.clear();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Center(
            child: AutoSizeText(
              'Quiz on ${widget.session.quiz.onSession}',
              style: Styles().style(30, Colors.black, true),
            ),
          ),
          Divider(
            thickness: 2,
            height: 2,
            color: Variables().mainColor,
          ),
          Card(
            elevation: 10,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
              side: BorderSide(color: Variables().mainColor, width: 2),
            ),
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: questions[currentIndex].isMCQ
              ?
              Column(
                children: [
                  TextButton(
                    onPressed:(){
                      js.context.callMethod("urlLauncher",[questions[currentIndex].imageUrl]);
                    },
                    child: Image.network(
                      width: MediaQuery.of(context).size.width * 0.8,
                      height: MediaQuery.of(context).size.height * 0.3,
                      questions[currentIndex].imageUrl,
                      fit: BoxFit.cover,
                    ),
                  ),
                  const SizedBox(height: 20),
                  Column(
                    children: [
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Checkbox(
                            value: choosedAnswer == answersToChoose[0],
                            onChanged: (value) async{
                              await addAnswer(answersToChoose[0],questions[currentIndex],value);
                            },
                          ),
                          AutoSizeText(
                            answersToChoose[0]
                          ), 
                        ]
                      ),
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Checkbox(
                            value: choosedAnswer == answersToChoose[1],
                            onChanged: (value) async{
                              await addAnswer(answersToChoose[1],questions[currentIndex],value);
                            },
                          ),
                          AutoSizeText(
                            answersToChoose[1]
                          ), 
                        ]
                      ),
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Checkbox(
                            value: choosedAnswer == answersToChoose[2],
                            onChanged: (value) async{
                              await addAnswer(answersToChoose[2],questions[currentIndex],value);
                            },
                          ),
                          AutoSizeText(
                            answersToChoose[2]
                          ), 
                        ]
                      ),
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Checkbox(
                            value: choosedAnswer == answersToChoose[3],
                            onChanged: (value) async{
                              await addAnswer(answersToChoose[3],questions[currentIndex],value);
                            },
                          ),
                          AutoSizeText(
                            answersToChoose[3]
                          ), 
                        ]
                      ),
                    ]
                  ),
                  // Row(
                  //   children: [
                  //     Checkbox(
                  //       value: _isA,
                  //       onChanged: (value) async{
                  //         await addAnswer("A",questions[currentIndex],value);
                  //       },
                  //     ),
                  //     const AutoSizeText("A"),
                  //     const SizedBox(width: 20),
                  //     Checkbox(
                  //       value: _isB,
                  //       onChanged: (value) async{
                  //         await addAnswer("B",questions[currentIndex],value);
                  //       },
                  //     ),
                  //     const AutoSizeText("B"),
                  //     const SizedBox(width: 20),
                  //     Checkbox(
                  //       value: _isC,
                  //       onChanged: (value) async{
                  //         await addAnswer("C",questions[currentIndex],value);
                  //       },
                  //     ),
                  //     const AutoSizeText("C"),
                  //     const SizedBox(width: 20),
                  //     Checkbox(
                  //       value: _isD,
                  //       onChanged: (value) async{
                  //         await addAnswer("D",questions[currentIndex],value);
                  //       },
                  //     ),
                  //     const AutoSizeText("D"),
                  //   ],
                  // ),
                  AutoSizeText(
                    questions[currentIndex].question,
                    style: Styles().style(25, Colors.black, false),
                  ),
                  const SizedBox(height: 20),
                ],
              )
              :
              Column(
                children: [
                  TextButton(
                    onPressed:(){
                      js.context.callMethod("urlLauncher",[questions[currentIndex].imageUrl]);
                    },
                    child: Image.network(
                      width: 200,
                      questions[currentIndex].imageUrl,
                      fit: BoxFit.cover,
                    ),
                  ),
                  const SizedBox(height: 20),
                  AutoSizeText(
                    questions[currentIndex].question,
                    style: Styles().style(25, Colors.black, false),
                  ),
                  const SizedBox(height: 20),
                  TextButton.icon(
                    style: Styles().buttonStyle(Variables().mainColor, Variables().secondColor, 20),
                    onPressed: ()async{
                      setState(() {
                        uploading = true;
                      });
                      String fileUrl = await uploadFile();
                      if (fileUrl == "Error") {
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: AutoSizeText("Error in uploading")));
                      } else if(fileUrl=="no file"){
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: AutoSizeText("No Files Selected")));
                      }else{
                        setState(() {
                          filenameuploaded = fileUrl.replaceAll("https://balanceacademyfiles.b-cdn.net/", "");
                        });
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: AutoSizeText("${fileUrl.replaceAll("https://balanceacademyfiles.b-cdn.net/", "")} Uploaded")));
                        http.Response storeUpload = await http.post(
                          Uri.parse(
                            "${Variables().url}upload.php"
                          ),
                          body: {
                            "name" : Variables().getStudent().name,
                            "url" : fileUrl,
                            "chpname": widget.chpname,
                            "sessionname" : widget.session.name,
                            "stage" : Variables().getStudent().stage,
                            "state" : "quiz",
                            "filename" : fileUrl.replaceAll("https://balanceacademyfiles.b-cdn.net/", ""),
                            "questionid" : questions[currentIndex].id,
                            "question" : questions[currentIndex].question,
                            "phone":Variables().getStudent().phone,
                          }
                        );
                      }
                      setState(() {
                        filenameuploaded = fileUrl.replaceAll("https://balanceacademyfiles.b-cdn.net/", "");
                        uploading = false;
                      });
                    },
                    icon: Icon(
                      Icons.upload,
                      size: 19,
                      color: Colors.white,
                    ),
                    label: AutoSizeText(
                      filenameuploaded==""?"Upload":filenameuploaded,
                      style: Styles().style(25, Colors.white, false),
                    )
                  )
                ],
              )
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              currentIndex>0?TextButton.icon(
                onPressed: () {
                  if(loadingAnswer == true){
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Please wait")));
                  }else{
                    setState(() {
                      // _isA = answers[currentIndex-1]==null? false : answers[currentIndex-1]=="A"?true:false;
                      // _isB = answers[currentIndex-1]==null? false : answers[currentIndex-1]=="B"?true:false;
                      // _isC = answers[currentIndex-1]==null? false : answers[currentIndex-1]=="C"?true:false;
                      // _isD = answers[currentIndex-1]==null? false : answers[currentIndex-1]=="D"?true:false;
                      currentIndex--;
                      answersToChoose.clear();
                      answersToChoose.addAll([questions[currentIndex].rightLetter,questions[currentIndex].wrong1,questions[currentIndex].wrong2,questions[currentIndex].wrong3]);
                      answersToChoose.shuffle();
                      choosedAnswer= "";
                    });
                  }
                },
                icon: Icon(
                  Icons.arrow_back_ios_new,
                  color: Variables().mainColor,
                  size: 30,
                ),
                label: !loadingAnswer?AutoSizeText(
                  'Save & Back',
                  style: Styles().style(25, Variables().mainColor, false),
                ):CircularProgressIndicator(),
              ):const SizedBox(),
              TextButton.icon(
                onPressed: () async{
                  if(loadingAnswer == true){
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Please wait")));
                  }else{
                    if (currentIndex<questions.length-1) {
                      setState(() {
                        // _isA = answers[currentIndex+1]==null? false : answers[currentIndex+1]=="A"?true:false;
                        // _isB = answers[currentIndex+1]==null? false : answers[currentIndex+1]=="B"?true:false;
                        // _isC = answers[currentIndex+1]==null? false : answers[currentIndex+1]=="C"?true:false;
                        // _isD = answers[currentIndex+1]==null? false : answers[currentIndex+1]=="D"?true:false;
                        currentIndex++;
                        answersToChoose.clear();
                        answersToChoose.addAll([questions[currentIndex].rightLetter,questions[currentIndex].wrong1,questions[currentIndex].wrong2,questions[currentIndex].wrong3]);
                        answersToChoose.shuffle();
                        choosedAnswer= "";
                      });
                    } else {
                      await submitQuiz();
                    }
                  }
                  
                },
                icon: Icon(
                  Icons.arrow_forward_ios,
                  color: Variables().mainColor,
                  size: 30,
                ),
                label: !loadingAnswer?AutoSizeText(
                  currentIndex<questions.length-1?'Save & Next':'Save & Submit',
                  style: Styles().style(25, Variables().mainColor, false),
                ):CircularProgressIndicator(),
              )
            ],
          ),
          const Spacer(),
          !loadingAnswer?Wrap(
            children: questions
              .map((e) => Card(
                color:currentIndex==questions.indexOf(e)?Variables().mainColor: Colors.grey.withValues(alpha: 0.5),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                    side: BorderSide(
                      color:Colors.grey.withValues(alpha: 0.5),
                      width: 1,
                    ),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: TextButton(
                      onPressed: () {
                        setState(() {
                          currentIndex = questions.indexOf(e);
                          answersToChoose.clear();
                          answersToChoose.addAll([questions[currentIndex].rightLetter,questions[currentIndex].wrong1,questions[currentIndex].wrong2,questions[currentIndex].wrong3]);
                          answersToChoose.shuffle();
                          // _isA = answers[currentIndex]==null? false : answers[currentIndex]=="A"?true:false;
                          // _isB = answers[currentIndex]==null? false : answers[currentIndex]=="B"?true:false;
                          // _isC = answers[currentIndex]==null? false : answers[currentIndex]=="C"?true:false;
                          // _isD = answers[currentIndex]==null? false : answers[currentIndex]=="D"?true:false;
                        });
                      },
                      child: AutoSizeText(
                        (questions.indexOf(e) + 1).toString(),
                        style: Styles().style(20,currentIndex==questions.indexOf(e)?Colors.white: Colors.black, false),
                      ),
                    ),
                  ),
                )
              )
              .toList(),
          ):SizedBox()
        ]
      ),
      floatingActionButton: AutoSizeText(
        '${(_current ~/ 60) < 10 ? '0' : ''}${(_current ~/ 60)}:${(_current % 60) < 10 ? '0' : ''}${(_current % 60)}',
        style: Styles().style(20, Colors.black, false),
      )
    );
  }
}