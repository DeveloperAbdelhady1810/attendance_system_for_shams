import 'dart:convert';
import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:quadroedu/adapters/question.dart';
import 'package:quadroedu/adapters/session.dart';
import 'package:quadroedu/classes/styles.dart';
import 'package:quadroedu/classes/variables.dart';
import 'package:quadroedu/screens/answers_screen.dart';
import 'package:quadroedu/screens/homework_screen.dart';
import 'package:quadroedu/screens/quiz_screen.dart';
import 'package:quadroedu/screens/video_screen.dart';
import 'dart:js' as js;
import 'package:http/http.dart' as http;
class SessionScreen extends StatefulWidget {
  const SessionScreen({super.key, required this.session, required this.chpname});
  final Session session;
  final String chpname;
  @override
  State<SessionScreen> createState() => _SessionScreenState();
}
class _SessionScreenState extends State<SessionScreen> {
  async()async{
    try{
      http.Response videosResponse = await http.post(
        Uri.parse(
          "${Variables().url}get_videos.php"
        ),
        body: {
          "chpname": widget.chpname,
          "chpstage": widget.session.stage,
          "sessionname": widget.session.name,
          "phone": Variables().getStudent().phone,
        }
      );
      Map videosResponseMap = json.decode(videosResponse.body);
      videosResponseMap.forEach((key,value){
        setState(() {
          widget.session.videos.insert(videosResponseMap.keys.toList().indexOf(key), value);
        });
      });
    }catch(e){
      print("Failed to get videos");
    }
    try{
      http.Response docsResponse = await http.post(
        Uri.parse(
          "${Variables().url}get_docs.php"
        ),
        body: {
          "chpname": widget.chpname,
          "chpstage": widget.session.stage,
          "sessionname": widget.session.name,
        }
      );
      Map docsResponseMap = json.decode(docsResponse.body);
      docsResponseMap.forEach((key,value){
        setState(() {
          widget.session.docs.insert(docsResponseMap.keys.toList().indexOf(key), value);
        });
      });
    }catch(e){
      print("Failed to get docs");
    }
    try{
      http.Response otherDataResponse = await http.post(
        Uri.parse(
          "${Variables().url}get_otherData.php"
        ),
        body: {
          "chpname": widget.chpname,
          "chpstage": widget.session.stage,
          "phone": Variables().getStudent().phone,
          "sessionname": widget.session.name,
        }
      );
      Map otherDataResponseMap = json.decode(otherDataResponse.body);
      setState(() {
      try {
        widget.session.homework.mark = otherDataResponseMap['hwMark'].toString();
        // print(value['hwMark']);
      } catch (e) {
        print("Failed to put hwmark");
      }
      try {
        widget.session.mark = otherDataResponseMap['mark']??"0";
      } catch (e) {
        print("Failed to put mark");
      }
      try {
        List  questions = otherDataResponseMap['quizQuestions'];
        for (Map value in questions) {
          widget.session.quiz.questions.insert(
            questions.indexOf(value),
            Question(
              imageUrl: value['imageUrl'].toString(),
              mark: value['mark'].toString(),
              isMCQ: value['isMCQ']=="true"?true:false,
              question: value['question'].toString(),
              rightLetter: value['rightanswer'].toString(),
              wrong1: value['wrong1'].toString(),
              wrong2: value['wrong2'].toString(),
              wrong3: value['wrong3'].toString(),
              chpname: value['chpname'].toString(),
              sessionname: value['sessionname'].toString(),
              sessionstage: value['sessionstage'].toString(),
              id: value['id'].toString(),
            )

          );
        }
      } catch (e) {
        print("Failed to put quiz questions");
      }
      try {
        List questions = otherDataResponseMap['hwQuestions'];
        for (Map value in questions) {
          widget.session.homework.questions.insert(
            questions.indexOf(value),
            Question(
              imageUrl: value['imageUrl'].toString(),
              mark: value['mark'].toString(),
              isMCQ: value['isMCQ']=="true"?true:false,
              question: value['question'].toString(),
              rightLetter: value['rightanswer'].toString(),
              wrong1: value['wrong1'].toString(),
              wrong2: value['wrong2'].toString(),
              wrong3: value['wrong3'].toString(),
              chpname: value['chpname'].toString(),
              sessionname: value['sessionname'].toString(),
              sessionstage: value['sessionstage'].toString(),
              id: value['id'].toString(),
            )
          );
        }
      } catch (e) {
        print("Failed to put hw questions");
      }
      //   widget.session.docs.insert(docsResponseMap.keys.toList().indexOf(key), value);
    });
    }catch(e){
      print("Failed to get otherData");
    }
  }
  bool _isExpanded = false;
  bool _isExpanded2 = false;
  bool _isExpanded3 = false;
  @override
  void initState() {
    async();
    super.initState();
  }
  @override
  void dispose() {
    widget.session.docs.clear();
    widget.session.videos.clear();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.session.name),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Align(
              alignment: Alignment.centerLeft,
              child: AutoSizeText(
                widget.session.quiz.questions.isNotEmpty
                ? "Steps you should pass ... 😒🤷‍♀️"
                : "No Steps 😊",
                style: Styles().style(30, Colors.black, true),
              ),
            ),
            widget.session.quiz.questions.isNotEmpty?
              widget.session.mark ==""?
                TextButton(
                  onPressed: () {
                    Navigator.push(context,
                      MaterialPageRoute(
                        builder: (context) => QuizScreen(
                            chpname: widget.chpname,
                            chpstage: widget.session.stage,
                            session: widget.session,
                          )
                        )
                      );
                  },
                  child: AutoSizeText(
                    "Take quiz on ${widget.session.quiz.onSession}",
                    style: Styles().style(30, Colors.black, true),
                  ),
                )
                :
                double.parse(widget.session.mark) >= double.parse(widget.session.quiz.successMark)?
                AutoSizeText(
                  "You passed the quiz on ${widget.session.quiz.onSession} (${widget.session.mark}/${widget.session.quiz.fullMark})",
                  style: Styles().style(30, Colors.green, true),
                )
                :Column(
                    children: [
                      AutoSizeText(
                        "You failed in the quiz on ${widget.session.quiz.onSession} (${widget.session.mark}/${widget.session.quiz.fullMark})",
                        style: Styles().style(30, Colors.red, true),
                      ),
                      TextButton(
                        style: Styles().buttonStyle(Colors.red, Colors.red[900], 18),
                        onPressed: () {
                          Navigator.push(context,
                            MaterialPageRoute(
                              builder: (context) => AnswersScreen(
                                  chpname: widget.chpname,
                                  chpstage: widget.session.stage,
                                  session: widget.session,
                                )
                              )
                            );
                          },
                          child: AutoSizeText(
                          "See Your Answers",
                          style: Styles().style(30, Colors.white, true),
                        ),
                      ),
                      TextButton(
                        style: Styles().buttonStyle(Colors.red, Colors.red[900], 18),
                        onPressed: () {
                          Navigator.pop(context);
                          Navigator.push(context,
                            MaterialPageRoute(
                              builder: (context) => QuizScreen(
                                  chpname: widget.chpname,
                                  chpstage: widget.session.stage,
                                  session: widget.session,
                                )
                              )
                            );
                          },
                          child: AutoSizeText(
                          "Take quiz on ${widget.session.quiz.onSession} again",
                          style: Styles().style(30, Colors.white, true),
                        ),
                      )
                    ],
                  )
            : const SizedBox(),
            const SizedBox(height: 10),
            Divider(
              color: Variables().mainColor,
              height: 3,
              thickness: 3,
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: MediaQuery.of(context).size.width * 0.7,
              child: Column(
                children: [
                  GestureDetector(
                    onTap: () {
                      setState(() {
                        _isExpanded = !_isExpanded;
                      });
                    },
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 500),
                      width: MediaQuery.of(context).size.width,
                      height: _isExpanded ? 305 : 50,
                      decoration: BoxDecoration(
                        color: Colors.grey,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: _isExpanded
                      ? ListView.builder(
                          shrinkWrap: true,
                          itemCount: widget.session.videos.length + 1,
                          itemBuilder: (context, index) {
                            if (index == 0) {
                              return Padding(
                                padding: const EdgeInsets.all(10.0),
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    AutoSizeText('Videos',style: Styles().style(25, Colors.white, true)),
                                    Icon(
                                      Icons.keyboard_arrow_up,
                                      size: 30,
                                      color: Colors.white,
                                    )
                                  ],
                                ),
                              );
                            } else {
                              return ListTile(
                                title: AutoSizeText(
                                  widget.session.videos[index - 1]['videotitle']+" (${5-widget.session.videos[index - 1]['views']} Views Left)",
                                  style: Styles().style(25, Colors.white, false),
                                ),
                                subtitle: 5-widget.session.videos[index - 1]['views'] >0?TextButton(
                                  style: Styles().buttonStyle(Colors.white,const Color.fromARGB(255, 210, 210, 210),18),
                                  onPressed: () async {
                                    if (double.parse(widget.session.mark.isNotEmpty? widget.session.mark: "0") >=double.parse(widget.session.quiz.successMark.isNotEmpty? widget.session.quiz.successMark: "0")) {
                                      await http.post(
                                        Uri.parse(
                                          "${Variables().url}add_view.php",
                                        ),
                                        body: {
                                          "sessionname":widget.session.name,
                                          "chpname":widget.chpname,
                                          "chpstage":widget.session.stage,
                                          "videourl":widget.session.videos[index - 1]['videourl'],
                                          "phone": Variables().getStudent().phone
                                        }
                                      );
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                          builder: (context) => VideoScreen(
                                            videotitle: widget.session.videos[index - 1]['videotitle'],
                                            videourl: widget.session.videos[index - 1]['videourl'],
                                          )
                                        )
                                      );
                                    } else {
                                      showDialog(
                                        context: context,
                                        builder: (context) => Dialog(
                                          child: Center(
                                            child: AutoSizeText(
                                              "You need to pass quiz first 😒",
                                              style: Styles().style(30,
                                                  Variables().mainColor, true),
                                            ),
                                          ),
                                        )
                                      );
                                    }
                                  },
                                  child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: AutoSizeText(
                                      "Start",
                                      style: Styles()
                                          .style(20, Colors.black, false),
                                    ),
                                  )
                                ):Text("Your Views are over"),
                              );
                            }
                          })
                      : Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              AutoSizeText('Videos',
                                  style: Styles().style(25, Colors.white, true)),
                              Icon(
                                Icons.keyboard_arrow_down,
                                size: 30,
                                color: Colors.white,
                              )
                            ],
                          ),
                        ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  GestureDetector(
                      onTap: () {
                        setState(() {
                          _isExpanded2 = !_isExpanded2;
                        });
                      },
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 500),
                        width: MediaQuery.of(context).size.width,
                        height: _isExpanded2 ? 305 : 50,
                        decoration: BoxDecoration(
                          color: Colors.grey,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: _isExpanded2
                            ? ListView.builder(
                                shrinkWrap: true,
                                itemCount: widget.session.docs.length + 1,
                                itemBuilder: (context, index) {
                                  if (index == 0) {
                                    return Padding(
                                      padding: const EdgeInsets.all(10.0),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          AutoSizeText('Documents',
                                              style: Styles()
                                                  .style(25, Colors.white, true)),
                                          Icon(
                                            Icons.keyboard_arrow_up,
                                            size: 30,
                                            color: Colors.white,
                                          )
                                        ],
                                      ),
                                    );
                                  } else {
                                    return ListTile(
                                        title: AutoSizeText(
                                          widget.session.docs[index - 1]['doctitle'],
                                          style:
                                              Styles().style(25, Colors.white, false),
                                        ),
                                        subtitle: TextButton(
                                            style: Styles().buttonStyle(
                                                Colors.white,
                                                const Color.fromARGB(
                                                    255, 210, 210, 210),
                                                18),
                                            onPressed: () {
                                              if (double.parse(
                                                      widget.session.mark.isNotEmpty
                                                          ? widget.session.mark
                                                          : "0") >=
                                                  double.parse(widget.session.quiz
                                                          .successMark.isNotEmpty
                                                      ? widget
                                                          .session.quiz.successMark
                                                      : "0")) {
                                                js.context.callMethod("urlLauncher", [
                                                  widget.session.docs[index - 1]
                                                      ['docurl'],
                                                ]);
                                              } else {
                                                showDialog(
                                                    context: context,
                                                    builder: (context) => Dialog(
                                                          child: Center(
                                                            child: AutoSizeText(
                                                              "You need to pass quiz first 😒",
                                                              style: Styles().style(
                                                                  30,
                                                                  Variables().mainColor,
                                                                  true),
                                                            ),
                                                          ),
                                                        ));
                                              }
                                            },
                                            child: Padding(
                                              padding: const EdgeInsets.all(8.0),
                                              child: AutoSizeText(
                                                "View",
                                                style: Styles()
                                                    .style(20, Colors.black, false),
                                              ),
                                            )));
                                  }
                                })
                            : Padding(
                                padding: const EdgeInsets.all(10.0),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    AutoSizeText('Documents',
                                        style:
                                            Styles().style(25, Colors.white, true)),
                                    Icon(
                                      Icons.keyboard_arrow_down,
                                      size: 30,
                                      color: Colors.white,
                                    )
                                  ],
                                ),
                              ),
                      )),
                  const SizedBox(height: 20),
                  GestureDetector(
                    onTap: () {
                      setState(() {
                        _isExpanded3 = !_isExpanded3;
                      });
                    },
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 500),
                      width: MediaQuery.of(context).size.width,
                      height: _isExpanded3 ? 305 : 50,
                      decoration: BoxDecoration(
                        color: Colors.grey,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: _isExpanded3
                      ? ListView(
                          shrinkWrap: true,
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(10.0),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  AutoSizeText('Assignments',
                                      style: Styles()
                                          .style(25, Colors.white, true)),
                                  Icon(
                                    Icons.keyboard_arrow_up,
                                    size: 30,
                                    color: Colors.white,
                                  )
                                ],
                              ),
                            ),
                            widget.session.homework.mark == ""
                            ? TextButton(
                                style: Styles().buttonStyle(Variables().mainColor, Variables().secondColor, 20),
                                onPressed: () {
                                  if (widget.session.homework.questions.isNotEmpty) {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(builder: (context) =>HomeworkScreen(session:widget.session,chpname: widget.chpname,))
                                    );
                                  } else {
                                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: Variables().mainColor, content:AutoSizeText("No Homework")));
                                  }
                                },
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: AutoSizeText(
                                    "Assign Homework",
                                    style: Styles().style(25, Colors.white, false),
                                  ),
                                ),
                              )
                            : Card(
                              elevation: 5,
                              color:
                              double.parse(
                                widget.session.homework.mark==""?"0":widget.session.homework.mark
                              ) 
                              >=
                              double.parse(
                                widget.session.homework.successMark==""?"0":widget.session.homework.successMark
                              )
                              ? Colors.green
                              : Colors.red,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: AutoSizeText(
                                  double.parse(widget.session.homework.mark) >=
                                          double.parse(widget.session
                                            .homework.successMark)
                                      ? "You got ${widget.session.homework.mark}/${widget.session.homework.fullMark}"
                                      : "You got ${widget.session.homework.mark}/${widget.session.homework.fullMark} (Success Mark: ${widget.session.homework.successMark})",
                                  style: Styles()
                                      .style(25, Colors.white, false),
                                ),
                              ),
                            )
                          ],
                        )
                      : Padding(
                              padding: const EdgeInsets.all(10.0),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  AutoSizeText('Assignments',
                                      style:
                                          Styles().style(25, Colors.white, true)),
                                  Icon(
                                    Icons.keyboard_arrow_down,
                                    size: 30,
                                    color: Colors.white,
                                  )
                                ],
                              ),
                            ),
                    )
                  )
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}