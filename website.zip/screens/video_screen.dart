import 'package:flutter/material.dart';
import 'dart:html' as html;
import 'dart:ui_web' as ui;
import 'package:auto_size_text/auto_size_text.dart';
import 'package:quadroedu/classes/styles.dart';

class VideoScreen extends StatefulWidget {
  const VideoScreen({
    super.key,
    required this.videourl,
    required this.videotitle,
  });

  final String videourl;
  final String videotitle;

  @override
  State<VideoScreen> createState() => _VideoScreenState();
}

class _VideoScreenState extends State<VideoScreen> {
  String viewID = "";
  int _iframeCounter = 0; // Counter to force re-render

  void setEmbedCode() {
    // Remove the old iframe from the DOM (if it exists)
    final oldIframeElement =
        html.document.getElementById(viewID + _iframeCounter.toString());
    if (oldIframeElement != null) {
      oldIframeElement.remove();
    }

    // Register a new iframe with the updated URL
    ui.platformViewRegistry.registerViewFactory(
      viewID + _iframeCounter.toString(), // Unique ID for each iframe
      (int id) => html.IFrameElement()
        ..width = "100%"
        ..height = "76%"
        ..src = widget.videourl
        ..style.border = 'none'
        ..allowFullscreen = true,

        
    );
  }

  @override
  void dispose() {
    // Remove the iframe element from the DOM when the widget is disposed
    final iframeElement =
        html.document.getElementById(viewID + _iframeCounter.toString());
    if (iframeElement != null) {
      iframeElement.remove();
    }
    super.dispose();
  }

  @override
  void didUpdateWidget(VideoScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.videourl != widget.videourl) {
      // If the video URL has changed, force a re-render
      setState(() {
        _iframeCounter++; // Increment counter to force re-render
        setEmbedCode(); // Re-register the iframe with the new URL
      });
    }
  }

  void refreshIframe() {
    setState(() {
      _iframeCounter++; // Increment counter to force re-render
      setEmbedCode(); // Re-register the iframe with a new ID
    });
  }

  @override
  void initState() {
    super.initState();
    viewID = widget.videourl;
    setEmbedCode();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.videotitle),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(
              height: 500,
              child: HtmlElementView(
                viewType: viewID + _iframeCounter.toString(), // Use the updated ID
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Align(
                alignment: Alignment.centerRight,
                child: AutoSizeText(
                  "لو الفيديو وقف ومش عايز يتحرك دوس Refresh وشغله تاني ومش هتخسر ولا view",
                  style: Styles()
                      .style(15, Colors.red, true, style: FontStyle.normal),
                  textAlign: TextAlign.right,
                  textDirection: TextDirection.rtl,
                ),
              ),
            ),
            TextButton(
              style: Styles().buttonStyle(Colors.blue,Colors.blue[900],18,bordersidecolor: Colors.blue),
              onPressed: refreshIframe,
              child: Padding(
                padding: const EdgeInsets.all(10.0),
                child: AutoSizeText(
                  "Refresh",
                  style: Styles().style(25, Colors.white, true),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
