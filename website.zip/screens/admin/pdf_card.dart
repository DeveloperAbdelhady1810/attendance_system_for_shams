import 'package:flutter/material.dart';
import 'package:quadroedu/classes/styles.dart';
class PdfCard extends StatelessWidget {
  PdfCard({Key? key, required this.index, required this.pdfLinkController, required this.pdfnameController}) : super(key: key);
  final int index;
  final TextEditingController pdfLinkController;
  final TextEditingController pdfnameController;
  String pdfState = "Explanation";
  @override
  Widget build(BuildContext context) {
    return StatefulBuilder(
      builder: (context,setState){
        return SizedBox(
          // height: 200,
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Pdf No.${index+2}: ",
                    style: Styles().style(25, Colors.blue, true),
                  ),
                  const SizedBox(width: 5,),
                  SizedBox(
                    width: 250,
                    child: TextField(
                      controller: pdfLinkController,
                      style: Styles().style(20,Colors.green,true),
                      decoration: InputDecoration(
                        labelText: "Link",
                        labelStyle: Styles().style(20,Colors.green,true),
                        // hintText: 'Enter session Number',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(18),
                          borderSide:const BorderSide(
                            color: Colors.indigo,
                            width: 2,
                          ),
                          gapPadding: 5,
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(18),
                          borderSide:const BorderSide(
                            color: Colors.green,
                            width: 2,
                          ),
                          gapPadding: 5,
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(18),
                          borderSide:const BorderSide(
                            color: Colors.green,
                            width: 2,
                          ),
                          gapPadding: 5,
                        ),
                        disabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(18),
                          borderSide:const BorderSide(
                            color: Colors.green,
                            width: 2,
                          ),
                          gapPadding: 5,
                        ),
                      )
                    ),
                  ),
                  const SizedBox(width: 5,),
                  SizedBox(
                    width: 250,
                    child: TextField(
                      controller: pdfnameController,
                      style: Styles().style(20,Colors.green,true),
                      decoration: InputDecoration(
                        labelText: "Pdf Name",
                        labelStyle: Styles().style(20,Colors.green,true),
                        // hintText: 'Enter session Number',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(18),
                          borderSide:const BorderSide(
                            color: Colors.indigo,
                            width: 2,
                          ),
                          gapPadding: 5,
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(18),
                          borderSide:const BorderSide(
                            color: Colors.green,
                            width: 2,
                          ),
                          gapPadding: 5,
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(18),
                          borderSide:const BorderSide(
                            color: Colors.green,
                            width: 2,
                          ),
                          gapPadding: 5,
                        ),
                        disabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(18),
                          borderSide:const BorderSide(
                            color: Colors.green,
                            width: 2,
                          ),
                          gapPadding: 5,
                        ),
                      )
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      }
    );
  }
}