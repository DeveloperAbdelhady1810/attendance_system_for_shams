import 'dart:convert';

import 'package:auto_size_text/auto_size_text.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:quadroedu/adapters/question.dart';
import 'package:quadroedu/classes/styles.dart';
import 'package:quadroedu/classes/variables.dart';
import 'dart:js' as js;
import 'package:http/http.dart' as http;
class CreateHwScreen extends StatefulWidget {
  const CreateHwScreen({super.key, required this.chpname, required this.sessionname, required this.stage});
  final String chpname;
  final String sessionname;
  final String stage;
  @override
  State<CreateHwScreen> createState() => _CreateHwScreenState();
}
String selectedQuestionType = 'MCQ';
String selectedQuestionAnswer = 'A';
List questions = [];
bool uploading = false;
String filenameuploaded = "";
int currentIndex = 0;
TextEditingController questionTitleController = TextEditingController();
TextEditingController questionMarkController = TextEditingController();
class _CreateHwScreenState extends State<CreateHwScreen> {
  async() async{
    http.Response otherDataResponse = await http.post(
      Uri.parse(
        "${Variables().url}get_otherData.php"
      ),
      body: {
        "chpname": widget.chpname,
        "chpstage": widget.stage,
        "phone": "",
        "sessionname": widget.sessionname,
      }
    );
    Map otherDataResponseMap = json.decode(otherDataResponse.body);
    setState(() {
      try {
        List questions2 = otherDataResponseMap['hwQuestions'];
        for (Map value in questions2) {
          questions.insert(
            questions2.indexOf(value),
            Question(
              imageUrl: value['imageUrl'].toString(),
              mark: value['mark'].toString(),
              isMCQ: value['isMCQ']=="true"?true:false,
              question: value['question'].toString(),
              rightLetter: value['rightanswer'].toString(),
              wrong1: value['wrong1'].toString(),
              wrong2: value['wrong2'].toString(),
              wrong3: value['wrong3'].toString(),
              chpname: value['chpname'].toString(),
              sessionname: value['sessionname'].toString(),
              sessionstage: value['sessionstage'].toString(),
              id: value['id'].toString(),
            )
          );
        }
      } catch (e) {
        print("Failed to put hw questions");
      }
    });
  }
  Future<String> uploadFile() async {
    final file = await FilePicker.platform.pickFiles();
    if (file != null) {
      final bytes = file.files[0].bytes;
      final url = 'https://storage.bunnycdn.com/balanceacademyfiles/${file.files[0].name}';
      final headers = {
        'AccessKey': '8a9a18a0-019f-4f1b-98f7a8a608d1-5981-4eb1',
        'Content-Type': 'application/octet-stream',
      };
      final response = await http.put(Uri.parse(url), headers: headers, body: bytes);
      if (response.statusCode == 201) {
        return "https://balanceacademyfiles.b-cdn.net/${file.files[0].name}";
      } else {
        print('Error uploading file: ${response.statusCode}');
        return "Error";
      }
    }else{
      return "no file";
    }
  }
  @override
  void initState() {
    async();
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Create HW'),
      ),
      body: Column(
        children: [
          Align(
            alignment: Alignment.center,
            child: Card(
              elevation: 10,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
                side: BorderSide(color: Variables().mainColor, width: 2),
              ),
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: currentIndex > questions.length-1? Column(
                  children:[
                    TextButton(
                      style: Styles().buttonStyle(Colors.black, Colors.grey, 18),
                      onPressed: (){
                        showDialog(context: context, builder: (context)=>StatefulBuilder(
                          builder: (context,setState2){
                            return Dialog(
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Column(
                                  children: [
                                    Align(
                                      alignment: Alignment.topLeft,
                                      child: AutoSizeText(
                                        "Type: ",
                                        style: Styles().style(25, Colors.blue, true),
                                      ),
                                    ),
                                    Align(
                                      alignment: Alignment.topRight,
                                      child: DropdownButton(
                                        value: selectedQuestionType,
                                        items: [
                                          DropdownMenuItem(value: 'MCQ',child: Text('MCQ'),),
                                          DropdownMenuItem(value: 'Paragraph', child: Text('Paragraph'))
                                        ],
                                        onChanged: (value){
                                          setState2((){
                                            selectedQuestionType = value as String;
                                          });
                                        }
                                      ),
                                    ),
                                    Align(
                                      alignment: Alignment.topLeft,
                                      child: AutoSizeText(
                                        "Question Title",
                                        style: Styles().style(25, Colors.black, true),
                                      ),
                                    ),
                                    Align(
                                      alignment: Alignment.topLeft,
                                      child: TextField(
                                        controller: questionTitleController,
                                        style: Styles().style(18, Colors.black, false),
                                        decoration: InputDecoration(
                                          border: OutlineInputBorder(),
                                          labelText: 'Question Title',
                                        )
                                      ),
                                    ),
                                    selectedQuestionType=='MCQ'?Align(
                                      alignment: Alignment.topLeft,
                                      child: AutoSizeText(
                                        "Question Mark",
                                        style: Styles().style(25, Colors.black, true),
                                      ),
                                    ):const SizedBox(),
                                    selectedQuestionType=='MCQ'?Align(
                                      alignment: Alignment.topLeft,
                                      child: TextField(
                                        controller: questionMarkController,
                                        style: Styles().style(18, Colors.black, false),
                                        decoration: InputDecoration(
                                          border: OutlineInputBorder(),
                                          labelText: 'Question Mark',
                                        )
                                      ),
                                    ): const SizedBox(),
                                    selectedQuestionType=='MCQ'? Align(
                                      alignment: Alignment.topLeft,
                                      child: AutoSizeText(
                                        "Question Answer",
                                        style: Styles().style(25, Colors.black, true),
                                      ),
                                    ):const SizedBox(),
                                    selectedQuestionType=='MCQ'? Align(
                                      alignment: Alignment.topRight,
                                      child: DropdownButton(
                                        value: selectedQuestionAnswer,
                                        items: [
                                          DropdownMenuItem(value: 'A', child: Text('A')),
                                          DropdownMenuItem(value: 'B', child: Text('B')),
                                          DropdownMenuItem(value: 'C', child: Text('C')),
                                          DropdownMenuItem(value: 'D', child: Text('D')),
                                        ],
                                        onChanged: (value){
                                          setState2((){
                                            selectedQuestionAnswer = value as String;
                                          });
                                        }
                                      ),
                                    ):const SizedBox(),
                                    TextButton.icon(
                                      style: Styles().buttonStyle(Variables().mainColor, Variables().secondColor, 20),
                                      onPressed: ()async{
                                        setState2(() {
                                          uploading = true;
                                        });
                                        String fileUrl = await uploadFile();
                                        if (fileUrl == "Error") {
                                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: AutoSizeText("Error in uploading")));
                                        } else if(fileUrl=="no file"){
                                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: AutoSizeText("No Files Selected")));
                                        }else{
                                          setState2(() {
                                            filenameuploaded = fileUrl.replaceAll("https://balanceacademyfiles.b-cdn.net/", "");
                                          });
                                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: AutoSizeText("${fileUrl.replaceAll("https://balanceacademyfiles.b-cdn.net/", "")} Uploaded")));
                                        }
                                        setState2(() {
                                          filenameuploaded = fileUrl.replaceAll("https://balanceacademyfiles.b-cdn.net/", "");
                                          uploading = false;
                                        });
                                      },
                                      icon: Icon(
                                        Icons.upload,
                                        size: 19,
                                        color: Colors.white,
                                      ),
                                      label: AutoSizeText(
                                        filenameuploaded==""?"Upload":filenameuploaded,
                                        style: Styles().style(25, Colors.white, false),
                                      )
                                    ),
                                    const SizedBox(height:20),
                                    TextButton(
                                      style: Styles().buttonStyle(Variables().mainColor, Variables().secondColor, 20),
                                      onPressed: ()async{
                                        List answers = [
                                          'A',
                                          'B',
                                          'C',
                                          'D'
                                        ];
                                        answers.remove(selectedQuestionAnswer);
                                        http.Response questionResponse = await http.post(
                                          Uri.parse("${Variables().url}add_question.php"),
                                          body: {
                                            "sessionname": widget.sessionname,
                                            "isMCQ": selectedQuestionType=='MCQ'? "true":"false",
                                            "chpstage": widget.stage,
                                            "chpname": widget.chpname,
                                            "question": questionTitleController.text,
                                            "rightAnswer": selectedQuestionAnswer,
                                            "wrong1": answers[0],
                                            "wrong2": answers[1],
                                            "wrong3": answers[2],
                                            "mediaUrl": "https://balanceacademyfiles.b-cdn.net/$filenameuploaded",
                                            "mark": questionMarkController.text,
                                            "state":"hw",
                                          }
                                        );
                                        if (questionResponse.statusCode == 303) {
                                          setState((){
                                            questions.add(
                                              Question(
                                                imageUrl: "https://balanceacademyfiles.b-cdn.net/$filenameuploaded",
                                                mark: questionMarkController.text,
                                                isMCQ: selectedQuestionType=='MCQ'? true:false,
                                                question: questionTitleController.text,
                                                rightLetter: selectedQuestionAnswer,
                                                wrong1: answers[0],
                                                wrong2: answers[1],
                                                wrong3: answers[2],
                                                chpname: widget.chpname,
                                                sessionname: widget.sessionname,
                                                sessionstage: widget.stage,
                                                id: ""
                                              )
                                            );
                                          });
                                          Navigator.pop(context);
                                          ScaffoldMessenger.of(context).showSnackBar(
                                            SnackBar(
                                              content: AutoSizeText("${questionTitleController.text} Saved.")
                                            )
                                          );
                                        } else {
                                          ScaffoldMessenger.of(context).showSnackBar(
                                            SnackBar(
                                              content: AutoSizeText("${questionTitleController.text} didn`t Saved.")
                                            )
                                          );
                                        }
                                      },
                                      child: Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Text(
                                          "Add Question",
                                          style: Styles().style(25, Colors.white, false),
                                        ),
                                      )
                                    )
                                  ],
                                ),
                              ),
                            );
                          },
                        ));
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: AutoSizeText(
                          "Add Question",
                          style: Styles().style(25, Colors.white, true),
                        ),
                      )
                    ),
                    Wrap(
                      children: questions
                        .map((e) => Card(
                          color:currentIndex==questions.indexOf(e)?Variables().mainColor: Colors.grey.withValues(alpha: 0.5),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                              side: BorderSide(
                                color:Colors.grey.withValues(alpha: 0.5),
                                width: 1,
                              ),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: TextButton(
                                onPressed: () {
                                  setState(() {
                                    currentIndex = questions.indexOf(e);
                                  });
                                },
                                child: AutoSizeText(
                                  (questions.indexOf(e) + 1).toString(),
                                  style: Styles().style(20,currentIndex==questions.indexOf(e)?Colors.white: Colors.black, false),
                                ),
                              ),
                            ),
                          )
                        )
                        .toList(),
                    )
                  ]
                ):Column(
                  children: [
                    Row(
                      children: [
                        IconButton(
                          icon:Icon(Icons.delete),
                          onPressed: ()async{
                            http.Response questionRemoveResponse = await http.post(
                              Uri.parse("${Variables().url}remove_question.php"),
                              body: {
                                "sessionname": widget.sessionname,
                                "isMCQ": questions[currentIndex].isMCQ.toString(),
                                "chpstage": widget.stage,
                                "chpname": widget.chpname,
                                "question": questions[currentIndex].question,
                                "rightAnswer": questions[currentIndex].rightLetter,
                                "mediaUrl": questions[currentIndex].imageUrl,
                                "mark": questions[currentIndex].mark,
                                "state":"hw",
                              }
                            );
                            if(questionRemoveResponse.statusCode==202){
                              setState(() {
                                questions.removeAt(currentIndex);
                                if(questions.isEmpty){
                                  currentIndex=0;
                                }else{
                                  if(currentIndex>questions.length-1) {
                                    currentIndex = questions.length - 1;
                                  }
                                }
                              });
                            }

                          },
                        ),
                        TextButton(
                          onPressed:(){
                            js.context.callMethod("urlLauncher",[questions[currentIndex].imageUrl]);
                          },
                          child: Image.network(
                            width: 200,
                            questions[currentIndex].imageUrl,
                            fit: BoxFit.cover,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),
                    AutoSizeText(
                      questions[currentIndex].question,
                      style: Styles().style(25, Colors.black, false),
                    ),
                    const SizedBox(height: 20),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        AutoSizeText(
                          questions[currentIndex].isMCQ?"MCQ":"Paragraph",
                          style: Styles().style(25, Colors.black, false),
                        ),
                        AutoSizeText(
                          questions[currentIndex].isMCQ?questions[currentIndex].rightLetter:"",
                          style: Styles().style(25, Colors.black, false),
                        ),
                        AutoSizeText(
                          questions[currentIndex].isMCQ?questions[currentIndex].mark:"",
                          style: Styles().style(25, Colors.black, false),
                        ),
                        
                      ],
                    ),
                  ],
                )
              ),
            ),
          ),
          const SizedBox(height:30),
          Wrap(
            children: questions
              .map((e) => Card(
                color:currentIndex==questions.indexOf(e)?Variables().mainColor: Colors.grey.withValues(alpha: 0.5),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                    side: BorderSide(
                      color:Colors.grey.withValues(alpha: 0.5),
                      width: 1,
                    ),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: TextButton(
                      onPressed: () {
                        setState(() {
                          currentIndex = questions.indexOf(e);
                        });
                      },
                      child: AutoSizeText(
                        (questions.indexOf(e) + 1).toString(),
                        style: Styles().style(20,currentIndex==questions.indexOf(e)?Colors.white: Colors.black, false),
                      ),
                    ),
                  ),
                )
              )
              .toList()..add(
                Card(
                  color:Variables().mainColor,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                    side: BorderSide(
                      color:Colors.grey.withValues(alpha: 0.5),
                      width: 1,
                    ),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: TextButton(
                      onPressed: () {
                        showDialog(context: context, builder: (context)=>StatefulBuilder(
                          builder: (context,setState2){
                            return Dialog(
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Column(
                                  children: [
                                    Align(
                                      alignment: Alignment.topLeft,
                                      child: AutoSizeText(
                                        "Type: ",
                                        style: Styles().style(25, Colors.blue, true),
                                      ),
                                    ),
                                    Align(
                                      alignment: Alignment.topRight,
                                      child: DropdownButton(
                                        value: selectedQuestionType,
                                        items: [
                                          DropdownMenuItem(value: 'MCQ',child: Text('MCQ'),),
                                          DropdownMenuItem(value: 'Paragraph', child: Text('Paragraph'))
                                        ],
                                        onChanged: (value){
                                          setState2((){
                                            selectedQuestionType = value as String;
                                          });
                                        }
                                      ),
                                    ),
                                    Align(
                                      alignment: Alignment.topLeft,
                                      child: AutoSizeText(
                                        "Question Title",
                                        style: Styles().style(25, Colors.black, true),
                                      ),
                                    ),
                                    Align(
                                      alignment: Alignment.topLeft,
                                      child: TextField(
                                        controller: questionTitleController,
                                        style: Styles().style(18, Colors.black, false),
                                        decoration: InputDecoration(
                                          border: OutlineInputBorder(),
                                          labelText: 'Question Title',
                                        )
                                      ),
                                    ),
                                    selectedQuestionType=='MCQ'?Align(
                                      alignment: Alignment.topLeft,
                                      child: AutoSizeText(
                                        "Question Mark",
                                        style: Styles().style(25, Colors.black, true),
                                      ),
                                    ):const SizedBox(),
                                    selectedQuestionType=='MCQ'?Align(
                                      alignment: Alignment.topLeft,
                                      child: TextField(
                                        controller: questionMarkController,
                                        style: Styles().style(18, Colors.black, false),
                                        decoration: InputDecoration(
                                          border: OutlineInputBorder(),
                                          labelText: 'Question Mark',
                                        )
                                      ),
                                    ): const SizedBox(),
                                    selectedQuestionType=='MCQ'? Align(
                                      alignment: Alignment.topLeft,
                                      child: AutoSizeText(
                                        "Question Answer",
                                        style: Styles().style(25, Colors.black, true),
                                      ),
                                    ):const SizedBox(),
                                    selectedQuestionType=='MCQ'? Align(
                                      alignment: Alignment.topRight,
                                      child: DropdownButton(
                                        value: selectedQuestionAnswer,
                                        items: [
                                          DropdownMenuItem(value: 'A', child: Text('A')),
                                          DropdownMenuItem(value: 'B', child: Text('B')),
                                          DropdownMenuItem(value: 'C', child: Text('C')),
                                          DropdownMenuItem(value: 'D', child: Text('D')),
                                        ],
                                        onChanged: (value){
                                          setState2((){
                                            selectedQuestionAnswer = value as String;
                                          });
                                        }
                                      ),
                                    ):const SizedBox(),
                                    TextButton.icon(
                                      style: Styles().buttonStyle(Variables().mainColor, Variables().secondColor, 20),
                                      onPressed: ()async{
                                        setState2(() {
                                          uploading = true;
                                        });
                                        String fileUrl = await uploadFile();
                                        if (fileUrl == "Error") {
                                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: AutoSizeText("Error in uploading")));
                                        } else if(fileUrl=="no file"){
                                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: AutoSizeText("No Files Selected")));
                                        }else{
                                          setState2(() {
                                            filenameuploaded = fileUrl.replaceAll("https://balanceacademyfiles.b-cdn.net/", "");
                                          });
                                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: AutoSizeText("${fileUrl.replaceAll("https://balanceacademyfiles.b-cdn.net/", "")} Uploaded")));
                                        }
                                        setState2(() {
                                          filenameuploaded = fileUrl.replaceAll("https://balanceacademyfiles.b-cdn.net/", "");
                                          uploading = false;
                                        });
                                      },
                                      icon: Icon(
                                        Icons.upload,
                                        size: 19,
                                        color: Colors.white,
                                      ),
                                      label: AutoSizeText(
                                        filenameuploaded==""?"Upload":filenameuploaded,
                                        style: Styles().style(25, Colors.white, false),
                                      )
                                    ),
                                    const SizedBox(height:20),
                                    TextButton(
                                      style: Styles().buttonStyle(Variables().mainColor, Variables().secondColor, 20),
                                      onPressed: ()async{
                                        List answers = [
                                          'A',
                                          'B',
                                          'C',
                                          'D'
                                        ];
                                        answers.remove(selectedQuestionAnswer);
                                        http.Response questionResponse = await http.post(
                                          Uri.parse("${Variables().url}add_question.php"),
                                          body: {
                                            "sessionname": widget.sessionname,
                                            "isMCQ": selectedQuestionType=='MCQ'? "true":"false",
                                            "chpstage": widget.stage,
                                            "chpname": widget.chpname,
                                            "question": questionTitleController.text,
                                            "rightAnswer": selectedQuestionAnswer,
                                            "wrong1": answers[0],
                                            "wrong2": answers[1],
                                            "wrong3": answers[2],
                                            "mediaUrl": "https://balanceacademyfiles.b-cdn.net/$filenameuploaded",
                                            "mark": questionMarkController.text,
                                            "state":"hw",
                                          }
                                        );
                                        if (questionResponse.statusCode == 303) {
                                          setState((){
                                            questions.add(
                                              Question(
                                                imageUrl: "https://balanceacademyfiles.b-cdn.net/$filenameuploaded",
                                                mark: questionMarkController.text,
                                                isMCQ: selectedQuestionType=='MCQ'? true:false,
                                                question: questionTitleController.text,
                                                rightLetter: selectedQuestionAnswer,
                                                wrong1: answers[0],
                                                wrong2: answers[1],
                                                wrong3: answers[2],
                                                chpname: widget.chpname,
                                                sessionname: widget.sessionname,
                                                sessionstage: widget.stage,
                                                id: ""
                                              )
                                            );
                                          });
                                          Navigator.pop(context);
                                          ScaffoldMessenger.of(context).showSnackBar(
                                            SnackBar(
                                              content: AutoSizeText("${questionTitleController.text} Saved.")
                                            )
                                          );
                                        } else {
                                          ScaffoldMessenger.of(context).showSnackBar(
                                            SnackBar(
                                              content: AutoSizeText("${questionTitleController.text} didn`t Saved.")
                                            )
                                          );
                                        }
                                      },
                                      child: Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Text(
                                          "Add Question",
                                          style: Styles().style(25, Colors.white, false),
                                        ),
                                      )
                                    )
                                  ],
                                ),
                              ),
                            );
                          },
                        ));
                      },
                      child: AutoSizeText(
                        "Add",
                        style: Styles().style(20,Colors.white, false),
                      ),
                    ),
                  ),
                )
              ),
          )
        ]
      )
    );
  }
}