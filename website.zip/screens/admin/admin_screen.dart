import 'dart:convert';
import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:quadroedu/classes/styles.dart';
import 'package:quadroedu/classes/variables.dart';
import 'package:http/http.dart' as http;
import 'package:quadroedu/screens/admin/chapter_admin_screen.dart';
import 'package:quadroedu/screens/admin/codes_screen.dart';
import 'package:quadroedu/screens/admin/search_student_screen.dart';
import 'package:file_picker/file_picker.dart';
String selectedStage = "First Secondry";
TextEditingController chapterNameController = TextEditingController();
String filenameuploaded = "";
bool uploading = false;
class AdminScreen extends StatefulWidget {
  const AdminScreen({super.key});

  @override
  State<AdminScreen> createState() => _AdminScreenState();
}
class _AdminScreenState extends State<AdminScreen> {
  Future<String> uploadFile() async {
    final file = await FilePicker.platform.pickFiles();
    if (file != null) {
      final bytes = file.files[0].bytes;
      final url = 'https://storage.bunnycdn.com/balanceacademyfiles/${file.files[0].name}';
      final headers = {
        'AccessKey': '8a9a18a0-019f-4f1b-98f7a8a608d1-5981-4eb1',
        'Content-Type': 'application/octet-stream',
      };
      final response = await http.put(Uri.parse(url), headers: headers, body: bytes);
      if (response.statusCode == 201) {
        return "https://balanceacademyfiles.b-cdn.net/${file.files[0].name}";
      } else {
        print('Error uploading file: ${response.statusCode}');
        return "Error";
      }
    }else{
      return "no file";
    }
  }
  Future<int> updateChapterData(String column,String data,String id)async{
    http.Response response = await http.post(
      Uri.parse(
        "${Variables().url}update_chapter.php"
      ),
      body: {
        "column": column,
        "value": data,
        "id": id
      }
    );
    return response.statusCode;
  }
  List chapters = [];
  int currentIndex = 0;
  async()async{
    http.Response chaptersResponse = await http.post(
      Uri.parse(
        "${Variables().url}get_chapters.php",
      ),
      body: {
        "stage":"All",
        "isscientific":"All",
      }
    );
    Map chaptersResponseMap = json.decode(chaptersResponse.body);
    chaptersResponseMap.forEach((key,value){
      setState(() {
        chapters.insert(chaptersResponseMap.keys.toList().indexOf(key),value);
      });
    });
  }
  @override
  void initState() {
    async();
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    List screens = [
      Padding(
        padding: const EdgeInsets.all(8.0),
        child: SingleChildScrollView(
          child: Column(
            children: [
              Align(
                alignment: Alignment.topLeft,
                child: Text(
                  "Chapters",
                  style: Styles().style(22,Colors.indigo,true)
                )
              ),
              Align(
                alignment: Alignment.topRight,
                child: TextButton(
                  onPressed: (){
                    showDialog(context: context, builder: (context)=>Dialog(
                      child: StatefulBuilder(
                        builder: (context,setState2){
                          return Padding(
                            padding: const EdgeInsets.all(20.0),
                            child: Column(
                              children: [
                                AutoSizeText(
                                  "Add Chapter",
                                  style: Styles().style(25, Variables().mainColor, true),
                                ),
                                const SizedBox(height: 10,),
                                SizedBox(
                                  width: 300,
                                  child: TextField(
                                    controller: chapterNameController,
                                    decoration: InputDecoration(
                                      labelText: "Chapter Name",
                                      border: OutlineInputBorder(),
                                    ),
                                  ),
                                ),
                                const SizedBox(height: 10,),
                                TextButton.icon(
                                  style: Styles().buttonStyle(Variables().mainColor, Variables().secondColor, 20),
                                  onPressed: ()async{
                                    setState2(() {
                                      uploading = true;
                                    });
                                    String fileUrl = await uploadFile();
                                    if (fileUrl == "Error") {
                                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: AutoSizeText("Error in uploading")));
                                    } else if(fileUrl=="no file"){
                                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: AutoSizeText("No Files Selected")));
                                    }else{
                                      setState2(() {
                                        filenameuploaded = fileUrl.replaceAll("https://balanceacademyfiles.b-cdn.net/", "");
                                      });
                                    }
                                    setState2(() {
                                      filenameuploaded = fileUrl.replaceAll("https://balanceacademyfiles.b-cdn.net/", "");
                                      uploading = false;
                                    });
                                  },
                                  icon: Icon(
                                    Icons.upload,
                                    size: 19,
                                    color: Colors.white,
                                  ),
                                  label: AutoSizeText(
                                    filenameuploaded==""?"Upload":filenameuploaded,
                                    style: Styles().style(25, Colors.white, false),
                                  )
                                ),
                                const SizedBox(height: 10,),
                                SizedBox(
                                  width: 300,
                                  child: DropdownButton(
                                    value: selectedStage,
                                    items: [
                                      DropdownMenuItem(value: "First Secondry", child: AutoSizeText("First Secondry")),
                                      DropdownMenuItem(value: "Second Secondry", child: AutoSizeText("Second Secondry")),
                                      DropdownMenuItem(value: "Third Secondry", child: AutoSizeText("Third Secondry")),
                                    ],
                                    onChanged: (value){
                                      setState2((){
                                        selectedStage = value.toString();
                                      });
                                    }
                                  ),
                                ),
                                const SizedBox(height: 10,),
                                TextButton(
                                  onPressed: ()async{
                                    http.Response response = await http.post(
                                      Uri.parse("${Variables().url}add_chapter.php"),
                                      body: {
                                        "chapter_name": chapterNameController.text,
                                        "stage": selectedStage,
                                        "image": "https://balanceacademyfiles.b-cdn.net/$filenameuploaded",
                                      }
                                    );
                                    if (response.statusCode==202) {
                                      Navigator.pop(context);
                                      setState(() {
                                        chapters.clear();
                                      });
                                      await async();
                                    } else {
                                      Navigator.pop(context);
                                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: Colors.red,content: Text("Something went wrong with code :${response.statusCode}")));
                                    }
                                  },
                                  child: AutoSizeText(
                                    "Add",
                                    style: Styles().style(20, Variables().secondColor, false),
                                  )
                                )
                              ]
                            ),
                          );
                        }
                      ),
                    ));
                  
                  },
                  child: Text(
                    "Add Chapter",
                    style: Styles().style(22,Colors.indigo,true)
                  ),
                )
              ),
              DataTable(
                border: TableBorder(
                  horizontalInside: BorderSide(color: Colors.grey, width: 1),
                  top: BorderSide(color: Colors.grey, width: 1),
                  bottom: BorderSide(color: Colors.grey, width: 1),
                  left: BorderSide(color: Colors.grey, width: 1),
                  right: BorderSide(color: Colors.grey, width: 1),
                ),
                columns: [
                  DataColumn(
                    label: Text(
                      "#",
                    )
                  ),
                  DataColumn(
                    label: Text(
                      "Name",
                    )
                  ),
                  DataColumn(
                    label: Text(
                      "Stage",
                    )
                  ),
                  DataColumn(
                    label: Text(
                      "Image",
                    )
                  ),
                  // DataColumn(
                  //   label: Text(
                  //     "الشعبة",
                  //   )
                  // ),
                  DataColumn(
                    label: Text(
                      "See Sessions",
                    )
                  ),
                  DataColumn(
                    label: Text(
                      "Deactivate",
                    )
                  ),
                ],
                rows: chapters.map((chapter){
                  TextEditingController name = TextEditingController(text: chapter['name']);
                  String selectedStage = chapter['stage'];
                  // String selectedScientific = chapter['isscientific'];
                  return DataRow(
                    cells: [
                      DataCell(
                        Text(
                          (chapters.indexOf(chapter)+1).toString(),
                        )
                      ),
                      DataCell(
                        TextField(
                          controller: name,
                          onSubmitted: (value)async{
                            await updateChapterData("name",value,chapter['id']);
                          },
                        )
                      ),
                      DataCell(
                        // TextField(
                        //   controller: stage,
                        // )
                        StatefulBuilder(
                          builder: (context,setState2){
                            return DropdownButton(
                              value: selectedStage,
                              items: [
                                DropdownMenuItem(value: "First Secondry", child: Text("First Secondry")),
                                DropdownMenuItem(value: "Second Secondry", child: Text("Second Secondry")),
                                DropdownMenuItem(value: "Third Secondry", child: Text("Third Secondry")),
                              ],
                              onChanged: (value)async{
                                setState2(() {
                                  selectedStage = value as String;
                                });
                                await updateChapterData("stage",value as String,chapter['id']);
                              },
                            );
                          }
                        )
                      ),
                      DataCell(
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            TextButton(
                              onPressed: (){
                                showDialog(context: context,builder: (context)=>Dialog(
                                  child: Image.network(
                                    chapter['image'],
                                  ),
                                ));
                              },
                              child: Image.network(
                                chapter['image'],
                                width: 200,
                              ),
                            ),
                            IconButton(
                              icon: Icon(
                                Icons.edit,
                                color: Colors.blue
                              ),
                              onPressed: () async {
                                setState(() {
                                  uploading = true;
                                });
                                String fileUrl = await uploadFile();
                                if (fileUrl == "Error") {
                                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: AutoSizeText("Error in uploading")));
                                } else if(fileUrl=="no file"){
                                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: AutoSizeText("No Files Selected")));
                                }else{
                                  setState(() {
                                    filenameuploaded = fileUrl.replaceAll("https://balanceacademyfiles.b-cdn.net/", "");
                                  });
                                  http.Response response = await http.post(
                                    Uri.parse("${Variables().url}updateChapterImage.php"),
                                    body: {
                                      "id": chapter['id'],
                                      "url": "https://balanceacademyfiles.b-cdn.net/$filenameuploaded"
                                    }
                                  );
                                  if(response.statusCode == 303){
                                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: AutoSizeText("Done Saved Successfully")));
                                  }else{
                                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: AutoSizeText("Error in saving")));
                                  }
                                }
                                setState(() {
                                  filenameuploaded = fileUrl.replaceAll("https://balanceacademyfiles.b-cdn.net/", "");
                                  uploading = false;
                                });
                              },
                            )
                          ],
                        )
                      ),
                      // DataCell(
                      //   Text(""),
                        // Text(
                        //   chapter['isscientific'] == "true"?"علمي":"أدبي",
                        // )
                        // DropdownButton(
                        //   value: selectedScientific,
                        //   items: [
                        //     DropdownMenuItem(value: "All", child: Text("للكل")),
                        //     DropdownMenuItem(value: "true", child: Text("علمي")),
                        //     DropdownMenuItem(value: "false", child: Text("أدبي")),
                        //   ],
                        //   onChanged: (value){
                        //     setState(() {
                        //       selectedScientific = value as String;
                        //     });
                        //   },
                        // )
                        // StatefulBuilder(
                        //   builder: (context,setState2){
                        //     return DropdownButton(
                        //       value: selectedScientific,
                        //       items: [
                        //         DropdownMenuItem(value: "All", child: Text("للكل")),
                        //         DropdownMenuItem(value: "true", child: Text("علمي")),
                        //         DropdownMenuItem(value: "false", child: Text("أدبي")),
                        //       ],
                        //       onChanged: (value)async{
                        //         setState2(() {
                        //           selectedScientific = value as String;
                        //         });
                        //         await updateChapterData("isscientific",value as String,chapter['id']);
                        //       },
                        //     );
                        //   }
                        // )
                      // ),
                      DataCell(
                        TextButton(
                          onPressed: (){
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => ChapterAdminScreen(chapterName: chapter['name'],chapterStage: chapter['stage'],)),
                            );
                          },
                          child: Text(
                            "See Sessions"
                          )
                        )
                      ),
                      DataCell(
                        TextButton(
                          onPressed: ()async{
                            http.Response response = await http.post(
                              Uri.parse(
                                "${Variables().url}delete_chapter.php"
                              ),
                              body: {
                                "name":chapter['name'],
                                "stage":chapter['stage'],
                              }
                            );
                            if (response.statusCode == 303) {
                              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Done"),));
                            } else {
                              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Failed Code: ${response.statusCode}")));
                            }
                            setState((){});
                          },
                          child: Text(
                            "Delete"
                          )
                        )
                      ),
                    ]
                  );
                }).toList()
              ),
            ]
          )
        ),
      ),
      CodesScreen(),
      SearchStudentScreen()
    ];
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.indigo,
        title: Text(
          "Admin Dashboard",
          style: Styles().style(25,Colors.white,true)
        ),
        centerTitle: true,
        elevation: 20,
      ),
      body: screens[currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: currentIndex,
        onTap: (value){
          setState((){
            currentIndex = value;
          });
        },
        items: [
          BottomNavigationBarItem(
            label: "Chapters",
            tooltip: "Chapters Table",
            icon: Icon(Icons.book)
          ),
          BottomNavigationBarItem(
            label: "Online Codes",
            tooltip: "Online Codes Ativation/Deactivation",
            icon: Icon(Icons.wallet)
          ),
          BottomNavigationBarItem(
            label: "Students",
            tooltip: "Students Management",
            icon: Icon(Icons.people)
          ),
        ]
      ),
    );
    //old 
    // Scaffold(
    //   body: Wrap(
    //     alignment: WrapAlignment.center,
    //     children: [
    //       TextButton(
    //         style: Styles().buttonStyle(Colors.indigo, Colors.indigo[900], 20),
    //         onPressed: (){
    //           Navigator.push(context, MaterialPageRoute(builder: (context)=>ChaptersAdminScreen()));
    //         },
    //         child: Padding(
    //           padding: const EdgeInsets.all(10.0),
    //           child: Text(
    //             "Chapters",
    //             style: Styles().style(25, Colors.white, true),
    //           ),
    //         )
    //       ),
    //       TextButton(
    //         style: Styles().buttonStyle(Colors.indigo, Colors.indigo[900], 20),
    //         onPressed: (){
    //           Navigator.push(context, MaterialPageRoute(builder: (context)=>SearchStudentScreen()));
    //         },
    //         child: Padding(
    //           padding: const EdgeInsets.all(10.0),
    //           child: Text(
    //             "Students",
    //             style: Styles().style(25, Colors.white, true),
    //           ),
    //         )
    //       ),
    //       TextButton(
    //         style: Styles().buttonStyle(Colors.indigo, Colors.indigo[900], 20),
    //         onPressed: (){
    //           Navigator.push(context, MaterialPageRoute(builder: (context)=>CodesScreen()));
    //         },
    //         child: Padding(
    //           padding: const EdgeInsets.all(10.0),
    //           child: Text(
    //             "Codes",
    //             style: Styles().style(25, Colors.white, true),
    //           ),
    //         )
    //       ),
    //       // TextButton(
    //       //   style: Styles().buttonStyle(Colors.indigo, Colors.indigo[900], 20),
    //       //   onPressed: (){
    //       //     Navigator.push(context, MaterialPageRoute(builder: (context)=>Codes))
    //       //   },
    //       //   child: Padding(
    //       //     padding: const EdgeInsets.all(10.0),
    //       //     child: Text(
    //       //       "Online Codes",
    //       //       style: Styles().style(25, Colors.white, true),
    //       //     ),
    //       //   )
    //       // ),
    //     ],
    //   ),
    // );
  }
}