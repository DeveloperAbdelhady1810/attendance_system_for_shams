import 'package:flutter/material.dart';
import 'package:quadroedu/classes/styles.dart';
import 'package:quadroedu/classes/variables.dart';
class TableScreen extends StatefulWidget {
  const TableScreen({super.key, required this.attendance});
  final Map attendance;
  @override
  State<TableScreen> createState() => _TableScreenState();
}
int attended = 0;
int absent = 0;
List searchResults = [];
TextEditingController searchController = TextEditingController();
class _TableScreenState extends State<TableScreen> {
  @override
  void initState() {
    attended = 0;
    absent= 0;
    // print(student['Attendance']);
    for (Map student in widget.attendance.values) {
      setState((){
        if(student['Attendance']){
          attended++;
        }else{
          absent++;
        }
      });
    }
    super.initState();
  }
  search(value)async{
    for (Map student in widget.attendance.values) {
      setState((){
        searchResults.clear();
        if(student['Name'].toString().toLowerCase().contains(value.toLowerCase())){
          searchResults.add(student);
        }else if(student['studentID'] == value.toString().replaceAll(" ", "")){
          searchResults.add(student);
        }else if(student['Phone']== value.toString().replaceAll(" ", "")){
          searchResults.add(student);
        }else if(student['Parent'] == value.toString().replaceAll(" ", "")){
          searchResults.add(student);
        }else if(value==""){
          searchResults.clear();
        }
      });
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Table'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: SingleChildScrollView(
          child: Column(
            children: [
              Text(
                'Table',
                style: Styles().style(30,Variables().mainColor,true),
              ),
              const SizedBox(height: 20),
              Text(
                'Attended: $attended',
                style: Styles().style(20,Variables().mainColor,true),
              ),
              Text(
                'Absent: $absent',
                style: Styles().style(20,Variables().mainColor,true),
              ),
              const SizedBox(height: 10,),
              Align(
                alignment: Alignment.center,
                child: SizedBox(
                  width: MediaQuery.of(context).size.width -200,
                  child: TextField(
                    controller: searchController,
                    decoration: InputDecoration(
                      prefixIcon: Icon(Icons.search),
                      suffixIcon: IconButton(
                        icon: Icon(Icons.close),
                        onPressed: () {
                          setState(() {
                            searchController.clear();
                            searchResults.clear();
                          });
                        },
                      ),
                    ),
                    onChanged: (value)async{
                      await search(value);
                    },
                  ),
                ),
              ),
              const SizedBox(height: 10,),
              searchResults.isEmpty?
              Table(
                border: TableBorder.all(
                  color: Colors.black,
                  width: 1,
                ),
                children: [
                  TableRow(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text('Student ID', style: TextStyle(fontWeight: FontWeight.bold)),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text('Name', style: TextStyle(fontWeight: FontWeight.bold)),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text('Attendance', style: TextStyle(fontWeight: FontWeight.bold)),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text('Parent', style: TextStyle(fontWeight: FontWeight.bold)),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text('Phone', style: TextStyle(fontWeight: FontWeight.bold)),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text('Date', style: TextStyle(fontWeight: FontWeight.bold)),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text('Time', style: TextStyle(fontWeight: FontWeight.bold)),
                      ),
                    ],
                  ),
                  ...widget.attendance.values.map((student) {
                    return TableRow(
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text(student['studentID']),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text(student['Name']),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text(student['Attendance'] ? 'Present' : 'Absent'),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text(student['Parent']),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text(student['Phone']),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text(student['Date']),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text(student['Time']),
                        ),
                      ],
                    );
                  }).toList(),
                ],
              )
              :Table(
                border: TableBorder.all(
                  color: Colors.black,
                  width: 1,
                ),
                children: [
                  TableRow(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text('Student ID', style: TextStyle(fontWeight: FontWeight.bold)),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text('Name', style: TextStyle(fontWeight: FontWeight.bold)),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text('Attendance', style: TextStyle(fontWeight: FontWeight.bold)),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text('Parent', style: TextStyle(fontWeight: FontWeight.bold)),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text('Phone', style: TextStyle(fontWeight: FontWeight.bold)),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text('Date', style: TextStyle(fontWeight: FontWeight.bold)),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text('Time', style: TextStyle(fontWeight: FontWeight.bold)),
                      ),
                    ],
                  ),
                  ...searchResults.map((student) {
                    return TableRow(
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text(student['studentID']),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text(student['Name']),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text(student['Attendance'] ? 'Present' : 'Absent'),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text(student['Parent']),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text(student['Phone']),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text(student['Date']),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text(student['Time']),
                        ),
                      ],
                    );
                  }).toList(),
                ],
              ),
            ]
          ),
        ),
      ),
    );
  }
}