import 'dart:convert';
import 'package:auto_size_text/auto_size_text.dart';
import 'package:file_picker/file_picker.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:quadroedu/classes/styles.dart';
import 'package:quadroedu/classes/variables.dart';
import 'package:quadroedu/screens/admin/chapter_admin_screen.dart';
class ChaptersAdminScreen extends StatefulWidget {
  const ChaptersAdminScreen({super.key});
  @override
  State<ChaptersAdminScreen> createState() => _ChaptersAdminScreenState();
}
String filenameuploaded = "";
bool uploading = false;
List chapters = [];
String selectedScientific = "true";
String selectedStage = "First Secondry";
TextEditingController chapterNameController = TextEditingController();
class _ChaptersAdminScreenState extends State<ChaptersAdminScreen> {
  Future<String> uploadFile() async {
    final file = await FilePicker.platform.pickFiles();
    if (file != null) {
      final bytes = file.files[0].bytes;
      final url = 'https://storage.bunnycdn.com/balanceacademyfiles/${file.files[0].name}';
      final headers = {
        'AccessKey': '8a9a18a0-019f-4f1b-98f7a8a608d1-5981-4eb1',
        'Content-Type': 'application/octet-stream',
      };
      final response = await http.put(Uri.parse(url), headers: headers, body: bytes);
      if (response.statusCode == 201) {
        return "https://balanceacademyfiles.b-cdn.net/${file.files[0].name}";
      } else {
        print('Error uploading file: ${response.statusCode}');
        return "Error";
      }
    }else{
      return "no file";
    }
  }
  async()async{
    http.Response chaptersResponse = await http.post(
      Uri.parse(
        "${Variables().url}get_chapters.php",
      ),
      body: {
        "stage":"All",
        "isscientific":"All",
      }
    );
    Map chaptersResponseMap = json.decode(chaptersResponse.body);
    chaptersResponseMap.forEach((key,value){
      setState(() {
        chapters.insert(chaptersResponseMap.keys.toList().indexOf(key),value);
      });
    });
  }
  @override
  void initState() {
    async();
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width - 205;
    final crossAxisCount = screenWidth ~/ 300;
    return Scaffold(
      appBar: AppBar(
        title: AutoSizeText("Chapters"),
        elevation: 20,
        bottomOpacity: 0.7,
      ),
      body: GridView.builder(
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: crossAxisCount > 0 ? crossAxisCount : 1,
          childAspectRatio: 1,
          crossAxisSpacing: 10,
          mainAxisSpacing: 10,
        ),
        itemCount: chapters.length+1,
        itemBuilder: (context, index) {
          try {
            return SizedBox(
              width: 300,
              height: 400,
              child: TextButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => ChapterAdminScreen(chapterName: chapters.elementAt(index)['name'],chapterStage: chapters.elementAt(index)['stage'],)),
                  );
                },
                child: Card(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(15),
                    child: Column(
                      children: [
                        SizedBox(
                          height: 200,
                          // width: 200,
                          child: Image.network(
                            chapters.elementAt(index)['image'],
                            fit: BoxFit.cover,
                          ),
                        ),
                        Spacer(),
                        AutoSizeText(
                          chapters.elementAt(index)['name'],
                          style: Styles().style(17, Colors.black, false),
                        ),
                        AutoSizeText(
                          chapters.elementAt(index)['isscientific']=="true"?"علمي":"أدبي",
                          style: Styles().style(17, Colors.black, false),
                        ),
                        AutoSizeText(
                          chapters.elementAt(index)['stage'],
                          style: Styles().style(17, Colors.black, false),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            );
          } catch (e) {
            return SizedBox(
              width: 300,
              height: 400,
              child: TextButton(
                onPressed: () {
                  showDialog(context: context, builder: (context)=>Dialog(
                    child: StatefulBuilder(
                      builder: (context,setState2){
                        return Padding(
                          padding: const EdgeInsets.all(20.0),
                          child: Column(
                            children: [
                              AutoSizeText(
                                "Add Chapter",
                                style: Styles().style(25, Variables().mainColor, true),
                              ),
                              const SizedBox(height: 10,),
                              SizedBox(
                                width: 300,
                                child: TextField(
                                  controller: chapterNameController,
                                  decoration: InputDecoration(
                                    labelText: "Chapter Name",
                                    border: OutlineInputBorder(),
                                  ),
                                ),
                              ),
                              const SizedBox(height: 10,),
                              TextButton.icon(
                                style: Styles().buttonStyle(Variables().mainColor, Variables().secondColor, 20),
                                onPressed: ()async{
                                  setState2(() {
                                    uploading = true;
                                  });
                                  String fileUrl = await uploadFile();
                                  if (fileUrl == "Error") {
                                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: AutoSizeText("Error in uploading")));
                                  } else if(fileUrl=="no file"){
                                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: AutoSizeText("No Files Selected")));
                                  }else{
                                    setState2(() {
                                      filenameuploaded = fileUrl.replaceAll("https://balanceacademyfiles.b-cdn.net/", "");
                                    });
                                  }
                                  setState2(() {
                                    filenameuploaded = fileUrl.replaceAll("https://balanceacademyfiles.b-cdn.net/", "");
                                    uploading = false;
                                  });
                                },
                                icon: Icon(
                                  Icons.upload,
                                  size: 19,
                                  color: Colors.white,
                                ),
                                label: AutoSizeText(
                                  filenameuploaded==""?"Upload":filenameuploaded,
                                  style: Styles().style(25, Colors.white, false),
                                )
                              ),
                              const SizedBox(height: 10,),
                              SizedBox(
                                width: 300,
                                child: DropdownButton(
                                  value: selectedScientific,
                                  items: [
                                    DropdownMenuItem(value: "true", child: AutoSizeText("علمي")),
                                    DropdownMenuItem(value: "false", child: AutoSizeText("أدبي")),
                                  ],
                                  onChanged: (value){
                                    setState2((){
                                      selectedScientific = value.toString();
                                    });
                                  }
                                ),
                              ),
                              const SizedBox(height: 10,),
                              SizedBox(
                                width: 300,
                                child: DropdownButton(
                                  value: selectedStage,
                                  items: [
                                    DropdownMenuItem(value: "First Secondry", child: AutoSizeText("First Secondry")),
                                    DropdownMenuItem(value: "Second Secondry", child: AutoSizeText("Second Secondry")),
                                    DropdownMenuItem(value: "Third Secondry", child: AutoSizeText("Third Secondry")),
                                  ],
                                  onChanged: (value){
                                    setState2((){
                                      selectedStage = value.toString();
                                    });
                                  }
                                ),
                              ),
                              const SizedBox(height: 10,),
                              TextButton(
                                onPressed: ()async{
                                  http.Response response = await http.post(
                                    Uri.parse("${Variables().url}add_chapter.php"),
                                    body: {
                                      "chapter_name": chapterNameController.text,
                                      "scientific": selectedScientific,
                                      "stage": selectedStage,
                                      "image": "https://balanceacademyfiles.b-cdn.net/$filenameuploaded",
                                    }
                                  );
                                  if (response.statusCode==202) {
                                    Navigator.pop(context);
                                    setState(() {
                                      chapters.clear();
                                    });
                                    await async();
                                  } else {
                                    Navigator.pop(context);
                                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: Colors.red,content: Text("Something went wrong with code :${response.statusCode}")));
                                  }
                                },
                                child: AutoSizeText(
                                  "Add",
                                  style: Styles().style(20, Variables().secondColor, false),
                                )
                              )
                            ]
                          ),
                        );
                      }
                    ),
                  ));
                },
                child: Card(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(15),
                    child: AutoSizeText(
                      "Add Chapter",
                      style: Styles().style(25, Colors.black, true),
                    )
                  ),
                ),
              ),
            );
          }
        },
      ),
    );
  }
}