import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'dart:js'as js;
import 'package:http/http.dart' as http;
import 'package:quadroedu/classes/styles.dart';
import 'package:quadroedu/classes/variables.dart';
class HomeworkCorrection extends StatefulWidget {
  const HomeworkCorrection({Key? key, required this.stage, required this.sessionname, required this.uploads, required this.state}) : super(key: key);
  final String stage;
  final String sessionname;
  final List uploads;
  final String state;
  @override
  State<HomeworkCorrection> createState() => _HomeworkCorrectionState();
}
List<Widget> uploadsCards = [];
List<String> emailsgot = [];
class _HomeworkCorrectionState extends State<HomeworkCorrection> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: AutoSizeText("Homework Correction"),
        elevation: 20,
        bottomOpacity: 0.7,
      ),
      body: Container(
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Text('Correction',
                style: Styles().style(22, Colors.blue, true)
              ),
              const SizedBox(height: 10,),
              Text('Stage: ${widget.stage}',
                style: Styles().style(22, Colors.blue, true)
              ),
              const SizedBox(height: 10,),
              Text('Session: ${widget.sessionname}',
                style: Styles().style(22, Colors.blue, true)
              ),
              const SizedBox(height: 10,),
              const Divider(
                color: Colors.blue,
                thickness: 3,
                height: 3,
              ),
              const SizedBox(height: 30,),
              ListView.builder(
                shrinkWrap: true,
                physics: ScrollPhysics(),
                itemCount: widget.uploads.length,
                itemBuilder: (context,index){
                  // Map currentUpload = widget.uploads.elementAt(index);
                  List<Widget> allCurrentUploads = [];
                  String currentStudentEmail = widget.uploads.elementAt(index)['phone'];
                  if(!emailsgot.contains(currentStudentEmail)){
                    emailsgot.add(currentStudentEmail);
                    for (Map upload in widget.uploads) {
                      if(upload['phone'] == currentStudentEmail){
                        allCurrentUploads.add(
                          TextButton.icon(
                            onPressed: () async{
                              // Navigator.of(context).push(MaterialPageRoute(builder: (context)=>PdfView(name: key,stage: session.stage,sessionname: session.name,)));
                              js.context.callMethod("urlLauncher",[upload['fileurl']]);
                            },
                            icon: const Icon(Icons.play_arrow,color:Colors.blue),
                            label: Text(
                              "${upload['question']} Answer",
                              style:Styles().style(25,Colors.blue,true)
                            )
                          ),
                        );
                      }
                    }
                    // print(allCurrentUploads.length);
                    return Card(
                      elevation: 20,
                      child: Padding(
                        padding: const EdgeInsets.all(10.0),
                        child: Column(
                          children: [
                            Text(
                              "${widget.uploads.elementAt(index)['stdname']}",
                              style: Styles().style(20, Colors.black, false),
                            ),
                            ListView(
                              shrinkWrap: true,
                              children:allCurrentUploads,
                            ),
                            SizedBox(
                              height: 100,
                              width: 300,
                              child: TextField(
                                controller: TextEditingController(),
                                style: Styles().style(20,Colors.indigo,true),
                                decoration: InputDecoration(
                                  labelText: "Submit Mark",
                                  labelStyle: Styles().style(20,Colors.indigo,true),
                                  // hintText: 'Enter session Number',
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(18),
                                    borderSide: const BorderSide(
                                      color: Colors.indigo,
                                      width: 2,
                                    ),
                                    gapPadding: 5,
                                  ),
                                  enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(18),
                                    borderSide:const BorderSide(
                                      color: Colors.indigo,
                                      width: 2,
                                    ),
                                    gapPadding: 5,
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(18),
                                    borderSide:const BorderSide(
                                      color: Colors.indigo,
                                      width: 2,
                                    ),
                                    gapPadding: 5,
                                  ),
                                  disabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(18),
                                    borderSide:const BorderSide(
                                      color: Colors.indigo,
                                      width: 2,
                                    ),
                                    gapPadding: 5,
                                  ),
                                ),
                                onSubmitted: (value2)async{
                                  http.Response updatemark = await http.post(
                                    Uri.parse(
                                      "${Variables().url}update_mark2.php"
                                    ),
                                    body: {
                                      "sessionname":widget.sessionname,
                                      "chpname":widget.uploads.elementAt(index)['chpname'],
                                      "mark":value2,
                                      "stage":widget.stage,
                                      "email": widget.uploads.elementAt(index)['phone'],
                                      "state": widget.state
                                    }
                                  );
                                  if(updatemark.statusCode == 303){
                                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Done")));
                                  }else if(updatemark.statusCode ==400){
                                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Error in database")));
                                  }else if(updatemark.statusCode == 500){
                                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Error with this student")));
                                  }else{
                                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Error")));
                                  }

                                },
                              ),
                            )
                          ],
                        ),
                      ),
                    );
                  }else{
                    return Text("");
                  }
                }
              )
            ],
          ),
        ),
      ),
    );
  }
}