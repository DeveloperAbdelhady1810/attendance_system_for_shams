import 'package:auto_size_text/auto_size_text.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:quadroedu/classes/styles.dart';
import 'package:quadroedu/classes/variables.dart';
class CreateQuizScreen extends StatefulWidget {
  const CreateQuizScreen({Key? key,required this.quiztimer,required this.mcq,required this.paragraph,required this.sessionname,required this.stage, required this.chpname}): super(key: key);
  final String quiztimer;
  final String mcq;
  final String paragraph;
  final String sessionname;
  final String stage;
  final String chpname;
  @override
  State<CreateQuizScreen> createState() => _CreateQuizScreenState();
}
List<Map> mcqquestions = [];
List<Map> paragraphquestions = [];
bool loading = false;
class _CreateQuizScreenState extends State<CreateQuizScreen> {
  Future<String> uploadFile() async {
    final file = await FilePicker.platform.pickFiles();
    if (file != null) {
      final bytes = file.files[0].bytes;
      final url = 'https://storage.bunnycdn.com/balanceacademyfiles/${file.files[0].name}';
      final headers = {
        'AccessKey': '8a9a18a0-019f-4f1b-98f7a8a608d1-5981-4eb1',
        'Content-Type': 'application/octet-stream',
      };
      final response = await http.put(Uri.parse(url), headers: headers, body: bytes);
      if (response.statusCode == 201) {
        return "https://balanceacademyfiles.b-cdn.net/${file.files[0].name}";
      } else {
        print('Error uploading file: ${response.statusCode}');
        return "Error";
      }
    }else{
      return "no file";
    }
  }
  @override
  void initState() {
    mcqquestions.clear();
    paragraphquestions.clear();
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: AutoSizeText("Create Quiz"),
        elevation: 20,
        bottomOpacity: 0.7,
      ),
      body: Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        padding: const EdgeInsets.all(20),
        margin: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          boxShadow: const [
            BoxShadow(color: Colors.blue, blurRadius: 5),
          ],
        ),
        child: SingleChildScrollView(
          child: Column(
            children: [
              Align(
                alignment: Alignment.topRight,
                child: TextButton(
                  onPressed: () async {
                    setState(() {
                      loading = true;
                    });
                    // print(mcqquestions.length);
                    // print(paragraphquestions.length);
                    // for (Map question in mcqquestions) {
                    ///////////////////////////////////////////////////////////
                    // for(var i=0;i<mcqquestions.length;i++){
                    //   Map question = mcqquestions[i];
                    //   http.Response questionResponse = await http.post(
                    //     Uri.parse(
                    //       "${Variables().ip}add_question.php"
                    //     ),
                    //     body: {
                    //       "sessionname":widget.sessionname,
                    //       "type":"mcq",
                    //       "stage":widget.stage,
                    //       "question":question["question"].text,
                    //       "right":question['right'].text,
                    //       "false1":question['false1'].text,
                    //       "false2":question['false2'].text,
                    //       "false3":question['false3'].text,
                    //       "mediaUrl":question['url'].text,
                    //     }
                    //   );
                    // }
                    ///////////////////////////////////////////////////////////
                    // for (Map question in paragraphquestions) {
                    //   http.Response questionResponse = await http.post(
                    //     Uri.parse(
                    //       "${Variables().ip}add_question.php"
                    //     ),
                    //     body: {
                    //       "sessionname":widget.sessionname,
                    //       "type":"paragraph",
                    //       "stage":widget.stage,
                    //       "question":question["question"].text,
                    //       "right":"",
                    //       "false1":"",
                    //       "false2":"",
                    //       "false3":"",
                    //       "mediaUrl":question['url'].text,
                    //     }
                    //   );
                    // }
                    // http.Response timerResponse = await http.post(
                    //   Uri.parse("${Variables().url}set_quiz_timer.php"),
                    //   body: {
                    //     "sessionname": widget.sessionname,
                    //     "stage": widget.stage,
                    //     "timer": widget.quiztimer,
                    //   }
                    // );
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                      content: SizedBox(
                        height: MediaQuery.of(context).size.height - 200,
                        child: Center(
                          child: AutoSizeText(
                            "Done",
                            style: Styles().style(23, Colors.white, true),
                          ),
                        )
                      ),
                      backgroundColor: Colors.green,
                      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.only(bottomLeft: Radius.circular(18),bottomRight: Radius.circular(18),topRight: Radius.circular(18))),
                    ));
                    setState(() {
                      loading = false;
                    });
                  },
                  style: ButtonStyle(
                    elevation: WidgetStateProperty.all<double>(20),
                    overlayColor: WidgetStateProperty.all<Color>(
                        const Color.fromARGB(255, 0, 79, 144)),
                    backgroundColor:
                        WidgetStateProperty.all<Color>(Colors.blue),
                    padding:
                        WidgetStateProperty.all(const EdgeInsets.all(10)),
                  ),
                  child: AutoSizeText("Finish",style: Styles().style(20, Colors.white, true)),
                ),
              ),
              ListView.builder(
                shrinkWrap: true,
                itemCount: int.parse(widget.mcq),
                itemBuilder: (context, index) {
                  String filenameuploaded = "";
                  TextEditingController mark = TextEditingController(text: "1");
                  TextEditingController question = TextEditingController();
                  TextEditingController right = TextEditingController();
                  TextEditingController false1 = TextEditingController();
                  TextEditingController false2 = TextEditingController();
                  TextEditingController false3 = TextEditingController();
                  // mcqquestions.insert(
                  //   index,
                  //   {
                  //     "url":url,
                  //     "question":question,
                  //     "type":"mcq",
                  //     "right":right,
                  //     "false1":false1,
                  //     "false2":false2,
                  //     "false3":false3,
                  //   }
                  // );
                  return Card(
                    elevation: 20,
                    shadowColor: Colors.blue,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                      side: const BorderSide(
                        color: Colors.blue,
                        width: 1.5,
                      )
                    ),
                    margin: const EdgeInsets.all(10),
                    color: Colors.white,
                    child: Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Align(
                                alignment: Alignment.topLeft,
                                child: AutoSizeText(
                                  "MCQ Question No.${index + 1}",
                                  style: Styles().style(25, Colors.blue, false),
                                ),
                              ),
                              Align(
                                alignment: Alignment.topRight,
                                child: TextButton(
                                  onPressed: () async {
                                    http.Response questionResponse = await http.post(
                                      Uri.parse("${Variables().url}add_question.php"),
                                      body: {
                                        "sessionname": widget.sessionname,
                                        "isMCQ": "true",
                                        "chpstage": widget.stage,
                                        "chpname": widget.chpname,
                                        "question": question.text,
                                        "rightAnswer": right.text,
                                        "wrong1": false1.text,
                                        "wrong2": false2.text,
                                        "wrong3": false3.text,
                                        "mediaUrl": "https://balanceacademyfiles.b-cdn.net/$filenameuploaded",
                                        "mark": mark.text,
                                        "state":"quiz",


                                      }
                                    );
                                    if (questionResponse.statusCode == 303) {
                                      ScaffoldMessenger.of(context).showSnackBar(
                                        SnackBar(
                                          content: AutoSizeText("${question.text} Saved.")
                                        )
                                      );
                                    } else {
                                      ScaffoldMessenger.of(context).showSnackBar(
                                        SnackBar(
                                          content: AutoSizeText("${question.text} didn`t Saved.")
                                        )
                                      );
                                    }
                                  },
                                  style: ButtonStyle(
                                    backgroundColor:WidgetStateProperty.all(Colors.white),
                                    overlayColor: WidgetStateProperty.all(
                                        Color.fromARGB(255, 0, 53, 96)),
                                    padding: MaterialStateProperty.all(
                                        const EdgeInsets.all(10)),
                                    shape: MaterialStateProperty.all(
                                        RoundedRectangleBorder(
                                            borderRadius:
                                                BorderRadius.circular(18),
                                            side: BorderSide(
                                                color: Colors.blue,
                                                width: 2))),
                                  ),
                                  child: AutoSizeText(
                                    "Save",
                                    style: Styles().style(25, Colors.blue, false),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(
                            height: 5,
                          ),

                          Row(
                            mainAxisAlignment:MainAxisAlignment.spaceBetween,
                            children: [
                              AutoSizeText(
                                "Image",
                                style: Styles().style(25, Colors.blue, false),
                              ),
                              TextButton.icon(
                                style: Styles().buttonStyle(Variables().mainColor, Variables().secondColor, 20),
                                onPressed: ()async{
                                  setState(() {
                                  });
                                  String fileUrl = await uploadFile();
                                  if (fileUrl == "Error") {
                                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: AutoSizeText("Error in uploading")));
                                  } else if(fileUrl=="no file"){
                                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: AutoSizeText("No Files Selected")));
                                  }else{
                                    setState(() {
                                      filenameuploaded = fileUrl.replaceAll("https://balanceacademyfiles.b-cdn.net/", "");
                                    });
                                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: AutoSizeText("${fileUrl.replaceAll("https://balanceacademyfiles.b-cdn.net/", "")} Uploaded")));
                                    // http.Response storeUpload = await http.post(
                                    //   Uri.parse(
                                    //     "${Variables().url}upload.php"
                                    //   ),
                                    //   body: {
                                    //     "name" : Variables().getStudent().name,
                                    //     "url" : fileUrl,
                                    //     "chpname": widget.chpname,
                                    //     "sessionname" : widget.session.name,
                                    //     "stage" : Variables().getStudent().stage,
                                    //     "state" : "quiz",
                                    //     "filename" : fileUrl.replaceAll("https://balanceacademyfiles.b-cdn.net/", ""),
                                    //     "questionid" : "",
                                    //     "question" : questions[currentIndex].question
                                    //   }
                                    // );
                                  }
                                  setState(() {
                                    filenameuploaded = fileUrl.replaceAll("https://balanceacademyfiles.b-cdn.net/", "");
                                  });
                                },
                                icon: Icon(
                                  Icons.upload,
                                  size: 19,
                                  color: Colors.white,
                                ),
                                label: AutoSizeText(
                                  filenameuploaded==""?"Upload":filenameuploaded,
                                  style: Styles().style(25, Colors.white, false),
                                )
                              )
                              // SizedBox(
                              //   width: MediaQuery.of(context).size.width * 0.6,
                              //   child: TextField(
                              //     controller: url,
                              //     decoration: InputDecoration(
                              //       border: OutlineInputBorder(
                              //         borderRadius:
                              //             BorderRadius.circular(20),
                              //         borderSide: const BorderSide(
                              //             color: Colors.blue, width: 2),
                              //       ),
                              //       labelText: "Image Url",
                              //       // hintText: "EX.(10)",
                              //       hintStyle: Styles()
                              //           .style(18, Colors.blue, false),
                              //       labelStyle: Styles()
                              //           .style(20, Colors.blue, false),
                              //       floatingLabelStyle: Styles()
                              //           .style(20, Colors.blue, false),
                              //     ),
                              //     style:
                              //         Styles().style(21, Colors.black, true),
                              //   ),
                              // ),
                            ],
                          ),
                          const SizedBox(height: 10),
                          Row(
                            mainAxisAlignment:MainAxisAlignment.spaceBetween,
                            children: [
                              AutoSizeText(
                                "Question",
                                style:Styles().style(25, Colors.blue, false),
                              ),
                              SizedBox(
                                width:MediaQuery.of(context).size.width * 0.6,
                                child: TextField(
                                  // controller: mcqquestions.elementAt(index)['question'],
                                  controller: question,
                                  decoration: InputDecoration(
                                    border: OutlineInputBorder(
                                      borderRadius:BorderRadius.circular(20),
                                      borderSide: const BorderSide(
                                        color: Colors.blue, width: 2
                                      ),
                                    ),
                                    labelText: "Enter Question",
                                    // hintText: "EX.(10)",
                                    hintStyle: Styles().style(18, Colors.blue, false),
                                    labelStyle: Styles().style(20, Colors.blue, false),
                                    floatingLabelStyle: Styles().style(20, Colors.blue, false),
                                  ),
                                  style: Styles().style(21, Colors.black, true),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 10),
                          Row(
                            mainAxisAlignment:MainAxisAlignment.spaceBetween,
                            children: [
                              AutoSizeText(
                                "Mark",
                                style:Styles().style(25, Colors.blue, false),
                              ),
                              SizedBox(
                                width: MediaQuery.of(context).size.width * 0.6,
                                child: TextField(
                                  // controller: mcqquestions.elementAt(index)['question'],
                                  controller: mark,
                                  decoration: InputDecoration(
                                    border: OutlineInputBorder(
                                      borderRadius:
                                          BorderRadius.circular(20),
                                      borderSide: const BorderSide(
                                          color: Colors.blue, width: 2),
                                    ),
                                    labelText: "Enter Question",
                                    // hintText: "EX.(10)",
                                    hintStyle: Styles()
                                        .style(18, Colors.blue, false),
                                    labelStyle: Styles()
                                        .style(20, Colors.blue, false),
                                    floatingLabelStyle: Styles()
                                        .style(20, Colors.blue, false),
                                  ),
                                  style: Styles().style(21, Colors.black, true),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          const Divider(
                            thickness: 2,
                            height: 2,
                            color: Colors.blue,
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          TextField(
                            // controller: mcqquestions.elementAt(index)['right'],
                            controller: right,
                            decoration: InputDecoration(
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(20),
                                borderSide: const BorderSide(
                                    color: Colors.green, width: 2),
                              ),
                              labelText: "Enter Right Answer",
                              // hintText: "EX.(10)",
                              hintStyle:
                                  Styles().style(18, Colors.blue, false),
                              labelStyle:
                                  Styles().style(20, Colors.blue, false),
                              floatingLabelStyle:
                                  Styles().style(20, Colors.green, false),
                            ),
                            style: Styles().style(21, Colors.black, true),
                          ),
                          TextField(
                            // controller: mcqquestions.elementAt(index)['false1'],
                            controller: false1,
                            decoration: InputDecoration(
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(20),
                                borderSide: const BorderSide(
                                    color: Colors.red, width: 2),
                              ),
                              labelText: "Enter A Wrong Answer",
                              // hintText: "EX.(10)",
                              hintStyle:
                                  Styles().style(18, Colors.blue, false),
                              labelStyle:
                                  Styles().style(20, Colors.blue, false),
                              floatingLabelStyle:
                                  Styles().style(20, Colors.red, false),
                            ),
                            style: Styles().style(21, Colors.black, true),
                          ),
                          TextField(
                            // controller: mcqquestions.elementAt(index)['false2'],
                            controller: false2,
                            decoration: InputDecoration(
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(20),
                                borderSide: const BorderSide(
                                    color: Colors.red, width: 2),
                              ),
                              labelText: "Enter A Wrong Answer",
                              // hintText: "EX.(10)",
                              hintStyle:
                                  Styles().style(18, Colors.blue, false),
                              labelStyle:
                                  Styles().style(20, Colors.blue, false),
                              floatingLabelStyle:
                                  Styles().style(20, Colors.red, false),
                            ),
                            style: Styles().style(21, Colors.black, true),
                          ),
                          TextField(
                            // controller: mcqquestions.elementAt(index)['false3'],
                            controller: false3,
                            decoration: InputDecoration(
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(20),
                                borderSide: const BorderSide(
                                    color: Colors.red, width: 2),
                              ),
                              labelText: "Enter A Wrong Answer",
                              // hintText: "EX.(10)",
                              hintStyle:
                                  Styles().style(18, Colors.blue, false),
                              labelStyle:
                                  Styles().style(20, Colors.blue, false),
                              floatingLabelStyle:
                                  Styles().style(20, Colors.red, false),
                            ),
                            style: Styles().style(21, Colors.black, true),
                          ),
                        ],
                      ),
                    ),
                  );
                }
              ),
              const Divider(color: Colors.blue, height: 2, thickness: 2),
              ListView.builder(
                shrinkWrap: true,
                itemCount: int.parse(widget.paragraph),
                itemBuilder: (context, index) {
                  String filenameuploaded = "";
                  TextEditingController url = TextEditingController();
                  TextEditingController question = TextEditingController();
                  // paragraphquestions.insert(
                  //   index,
                  //   {
                  //     "url":url,
                  //     "question":question,
                  //     "type":"paragraph"
                  //   }
                  // );
                  return Card(
                    elevation: 20,
                    shadowColor: Colors.blue,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                      side: const BorderSide(
                        color: Colors.blue,
                        width: 1.5,
                      )
                    ),
                    margin: const EdgeInsets.all(10),
                    color: Colors.white,
                    child: Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Column(
                        children: [
                          Row(
                            mainAxisAlignment:MainAxisAlignment.spaceBetween,
                            children: [
                              Align(
                                alignment: Alignment.topLeft,
                                child: AutoSizeText(
                                  "Paragraph Question No.${index + 1}",
                                  style:
                                      Styles().style(25, Colors.blue, false),
                                ),
                              ),
                              Align(
                                alignment: Alignment.topRight,
                                child: TextButton(
                                  onPressed: () async {
                                    http.Response questionResponse = await http.post(
                                      Uri.parse("${Variables().url}add_question.php"),
                                      body: {
                                        "sessionname": widget.sessionname,
                                        "isMCQ": "false",
                                        "chpstage": widget.stage,
                                        "chpname": widget.chpname,
                                        "question": question.text,
                                        "rightAnswer": "",
                                        "wrong1": "",
                                        "wrong2": "",
                                        "wrong3": "",
                                        "mediaUrl": "https://balanceacademyfiles.b-cdn.net/$filenameuploaded",
                                        "mark": "0",
                                        "state":"quiz",
                                      }
                                    );
                                    if (questionResponse.statusCode == 303) {
                                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: AutoSizeText("${question.text} Saved.")));
                                    } else {
                                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: AutoSizeText("${question.text} didn`t Saved.")));
                                    }
                                  },
                                  style: ButtonStyle(
                                    backgroundColor:
                                        MaterialStateProperty.all(
                                            Colors.white),
                                    overlayColor: MaterialStateProperty.all(
                                        Color.fromARGB(255, 0, 53, 96)),
                                    padding: MaterialStateProperty.all(
                                        const EdgeInsets.all(10)),
                                    shape: MaterialStateProperty.all(
                                        RoundedRectangleBorder(
                                            borderRadius:
                                                BorderRadius.circular(18),
                                            side: BorderSide(
                                                color: Colors.blue,
                                                width: 2))),
                                  ),
                                  child: AutoSizeText(
                                    "Save",
                                    style: Styles().style(25, Colors.blue, false),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          TextButton.icon(
                            style: Styles().buttonStyle(Variables().mainColor, Variables().secondColor, 20),
                            onPressed: ()async{
                              setState(() {
                              });
                              String fileUrl = await uploadFile();
                              if (fileUrl == "Error") {
                                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: AutoSizeText("Error in uploading")));
                              } else if(fileUrl=="no file"){
                                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: AutoSizeText("No Files Selected")));
                              }else{
                                setState(() {
                                  filenameuploaded = fileUrl.replaceAll("https://balanceacademyfiles.b-cdn.net/", "");
                                });
                                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: AutoSizeText("${fileUrl.replaceAll("https://balanceacademyfiles.b-cdn.net/", "")} Uploaded")));
                                // http.Response storeUpload = await http.post(
                                //   Uri.parse(
                                //     "${Variables().url}upload.php"
                                //   ),
                                //   body: {
                                //     "name" : Variables().getStudent().name,
                                //     "url" : fileUrl,
                                //     "chpname": widget.chpname,
                                //     "sessionname" : widget.session.name,
                                //     "stage" : Variables().getStudent().stage,
                                //     "state" : "quiz",
                                //     "filename" : fileUrl.replaceAll("https://balanceacademyfiles.b-cdn.net/", ""),
                                //     "questionid" : "",
                                //     "question" : questions[currentIndex].question
                                //   }
                                // );
                              }
                              setState(() {
                                filenameuploaded = fileUrl.replaceAll("https://balanceacademyfiles.b-cdn.net/", "");
                              });
                            },
                            icon: Icon(
                              Icons.upload,
                              size: 19,
                              color: Colors.white,
                            ),
                            label: AutoSizeText(
                              filenameuploaded==""?"Upload":filenameuploaded,
                              style: Styles().style(25, Colors.white, false),
                            )
                          ),
                          const SizedBox(
                            height: 5,
                          ),
                          Row(
                            mainAxisAlignment:
                                MainAxisAlignment.spaceBetween,
                            children: [
                              AutoSizeText(
                                "Image",
                                style:
                                    Styles().style(25, Colors.blue, false),
                              ),
                              SizedBox(
                                width:
                                    MediaQuery.of(context).size.width * 0.6,
                                child: TextField(
                                  // controller: paragraphquestions.elementAt(index)['url'],
                                  controller: url,
                                  decoration: InputDecoration(
                                    border: OutlineInputBorder(
                                      borderRadius:
                                          BorderRadius.circular(20),
                                      borderSide: const BorderSide(
                                          color: Colors.blue, width: 2),
                                    ),
                                    labelText: "Image Url",
                                    // hintText: "EX.(10)",
                                    hintStyle: Styles()
                                        .style(18, Colors.blue, false),
                                    labelStyle: Styles()
                                        .style(20, Colors.blue, false),
                                    floatingLabelStyle: Styles()
                                        .style(20, Colors.blue, false),
                                  ),
                                  style:
                                      Styles().style(21, Colors.black, true),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 10),
                          Row(
                            mainAxisAlignment:
                                MainAxisAlignment.spaceBetween,
                            children: [
                              AutoSizeText(
                                "Question",
                                style:
                                    Styles().style(25, Colors.blue, false),
                              ),
                              SizedBox(
                                width:
                                    MediaQuery.of(context).size.width * 0.6,
                                child: TextField(
                                  // controller: paragraphquestions.elementAt(index)['question'],
                                  controller: question,
                                  decoration: InputDecoration(
                                    border: OutlineInputBorder(
                                      borderRadius:
                                          BorderRadius.circular(20),
                                      borderSide: const BorderSide(
                                          color: Colors.blue, width: 2),
                                    ),
                                    labelText: "Enter Question",
                                    // hintText: "EX.(10)",
                                    hintStyle: Styles()
                                        .style(18, Colors.blue, false),
                                    labelStyle: Styles()
                                        .style(20, Colors.blue, false),
                                    floatingLabelStyle: Styles()
                                        .style(20, Colors.blue, false),
                                  ),
                                  style:
                                      Styles().style(21, Colors.black, true),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          // const Divider(thickness: 2,height: 2,color: Colors.blue,),
                          const SizedBox(
                            height: 10,
                          ),
                        ],
                      ),
                    ),
                  );
                }
              ),
            ],
          ),
        ),
      ),
    );
  }
}
