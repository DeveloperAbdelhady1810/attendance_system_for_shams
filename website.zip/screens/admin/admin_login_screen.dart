import 'dart:convert';

import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:quadroedu/classes/styles.dart';
import 'package:quadroedu/classes/variables.dart';
import 'package:http/http.dart' as http;
import 'package:quadroedu/screens/admin/admin_screen.dart';
class AdminLoginScreen extends StatefulWidget {
  const AdminLoginScreen({super.key});

  @override
  State<AdminLoginScreen> createState() => _AdminLoginScreenState();
}
bool loadingLogin = false;
TextEditingController phoneController = TextEditingController();
TextEditingController passwordController = TextEditingController();
bool isSignedIn = false;
class _AdminLoginScreenState extends State<AdminLoginScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Card(
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                AutoSizeText(
                  "Admin Login",
                  style: Styles().style(30, Variables().mainColor, true),
                ),
                const SizedBox(height: 10,),
                SizedBox(
                  width: MediaQuery.of(context).size.width * 0.8,
                  child: TextField(
                    controller: phoneController,
                    decoration: InputDecoration(
                      labelText: 'Phone',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
                SizedBox(height: 20),
                SizedBox(
                  width: MediaQuery.of(context).size.width * 0.8,
                  child: TextField(
                    controller: passwordController,
                    decoration: InputDecoration(
                      labelText: 'Password',
                      border: OutlineInputBorder(),
                    ),
                    obscureText: true,
                  ),
                ),
                TextButton(
                  style: Styles().buttonStyle(Variables().mainColor,Variables().secondColor, 18,bordersidecolor: Colors.blue),
                  onPressed: () async {
                    if(loadingLogin == true){}else{
                      setState(() {
                        loadingLogin = true;
                      });
                      http.Response loginResponse = await http.post(
                        Uri.parse("${Variables().url}login_admin.php"),
                        body: {
                          "token": phoneController.text,
                          "password":passwordController.text,
                        }
                      );
                      // print(loginResponse.statusCode);
                      if (loginResponse.statusCode == 202) {
                        // print("Here");
                        String responseText = loginResponse.body.toString();
                        Map responseData = jsonDecode(responseText);
                        await Variables().loginAssistant(responseData);
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            backgroundColor: Colors.green,
                            content: Row(
                              mainAxisAlignment:MainAxisAlignment.spaceBetween,
                                children: [
                                  Icon(
                                    Icons.check,
                                    color: Colors.white,
                                    size: 30
                                  ),
                                  AutoSizeText(
                                    "Welcome Back ${responseData['name']}",
                                    style: Styles().style(25,Colors.white,true),
                                  ),
                                  const SizedBox()
                                ]
                              )
                            )
                        );
                        Navigator.pop(context);
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>AdminScreen()));
                      }else{
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                              backgroundColor: Colors.red,
                              content: Row(
                                mainAxisAlignment:MainAxisAlignment.spaceBetween,
                                children: [
                                  Icon(Icons.clear,color: Colors.white,size: 30),
                                  AutoSizeText(
                                    "Invalid Login",
                                    style: Styles().style(25,Colors.white,true),
                                  ),
                                  const SizedBox(),
                                ]
                              )
                            )
                          );
                      }
                      setState(() {
                        loadingLogin = false;
                      });
                    }
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: !loadingLogin
                    ? AutoSizeText(
                        "Login",
                        style: Styles().style(25, Colors.white, false),
                      )
                    : CircularProgressIndicator(color: Colors.white,),
                  )
                ),
              ]
            )
          )
        ),
      ),
    );
  }
}