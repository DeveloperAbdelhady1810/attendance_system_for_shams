import 'dart:convert';
import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:quadroedu/adapters/question.dart';
import 'package:quadroedu/adapters/session.dart';
import 'package:quadroedu/classes/variables.dart';
import 'package:http/http.dart' as http;
import 'package:quadroedu/screens/admin/create_hw_screen.dart';
import 'package:quadroedu/screens/admin/create_quiz_screen2.dart';
import 'package:quadroedu/screens/admin/homework_correction.dart';
import 'package:quadroedu/screens/admin/pdf_card.dart';
import 'package:quadroedu/screens/admin/table_screen.dart';
import 'package:quadroedu/screens/admin/video_card.dart';
import 'package:quadroedu/classes/styles.dart';
class AdminSessionScreen extends StatefulWidget {
  const AdminSessionScreen({Key? key, required this.session, required this.chpname, required this.chpstage, required this.state}): super(key: key);
  final Session session;
  final String chpname;
  final String chpstage;
  final String state;
  @override
  State<AdminSessionScreen> createState() => _AdminSessionScreenState();
}
String quizMark = "Yes";
TextEditingController secondnameController = TextEditingController();
TextEditingController chooseQuestionsNumberController = TextEditingController();
TextEditingController paragraphQuestionsNumberController = TextEditingController();
TextEditingController hwchooseQuestionsNumberController = TextEditingController();
TextEditingController hwparagraphQuestionsNumberController = TextEditingController();
TextEditingController quizsuccessMarkController = TextEditingController();
TextEditingController quizfullMarkController = TextEditingController();
TextEditingController hwfullMarkController = TextEditingController();
TextEditingController hwsuccessMarkController = TextEditingController();
TextEditingController timerController = TextEditingController();
TextEditingController priceController = TextEditingController();
Map<Widget, List> videoExplanationCards = {};
Map<Widget, List<TextEditingController>> pdfCards = {};
int counter = 1;
bool loadinghere = false;
String selectedTarget = "";
String selectedVisibility = "All";
Map attendance = {};
class _AdminSessionScreenState extends State<AdminSessionScreen> {
  async()async{
    setState((){
      timerController.text = widget.session.quiz.quizTimer;
      priceController.text = widget.session.price.toString();
      quizsuccessMarkController.text = widget.session.quiz.successMark.toString();
      quizfullMarkController.text = widget.session.quiz.fullMark.toString();
      hwsuccessMarkController.text = widget.session.homework.successMark.toString();
      hwfullMarkController.text = widget.session.homework.fullMark.toString();
    });
    http.Response videosResponse = await http.post(
      Uri.parse(
        "${Variables().url}get_videos.php"
      ),
      body: {
        "chpname": widget.chpname,
        "chpstage": widget.session.stage,
        "sessionname": widget.session.name,
      }
    );
    try {
      Map videosResponseMap = json.decode(videosResponse.body);
      videosResponseMap.forEach((key,value){
        final TextEditingController videoLinkController = TextEditingController(text: value['videourl']);
        final TextEditingController videonameController = TextEditingController(text: value['videotitle']);
        setState(() {
          videoExplanationCards.addAll({
            VideoCard(
              index: videoExplanationCards.length - 1,
              videoLinkController: videoLinkController,
              videonameController: videonameController)
              : [
                videoLinkController,
                videonameController,
                "Explanation"
              ]
          });
        });
        setState(() {
          widget.session.videos.insert(videosResponseMap.keys.toList().indexOf(key), value);
        });
      });  
    } catch (e) {}
    http.Response docsResponse = await http.post(
      Uri.parse(
        "${Variables().url}get_docs.php"
      ),
      body: {
        "chpname": widget.chpname,
        "chpstage": widget.session.stage,
        "sessionname": widget.session.name,
      }
    );
    
    try {
      Map docsResponseMap = json.decode(docsResponse.body);
      docsResponseMap.forEach((key,value){
        TextEditingController pdfLinkController =
              TextEditingController(text: value['docurl']);
          TextEditingController pdfnameController =
              TextEditingController(text: value['doctitle']);
          setState(() {
            pdfCards.addAll({
              PdfCard(
                index: pdfCards.length - 1,
                pdfLinkController: pdfLinkController,
                pdfnameController: pdfnameController,
              ): [pdfLinkController, pdfnameController]
            });
          });
        setState(() {
          widget.session.docs.insert(docsResponseMap.keys.toList().indexOf(key), value);
        });
      });
    } catch (e) {}
    http.Response otherDataResponse = await http.post(
      Uri.parse(
        "${Variables().url}get_otherData.php"
      ),
      body: {
        "chpname": widget.chpname,
        "chpstage": widget.session.stage,
        "phone": "",
        "sessionname": widget.session.name,
      }
    );
    
    try {
      Map otherDataResponseMap = json.decode(otherDataResponse.body);
      setState(() {
        try {
          attendance = otherDataResponseMap['attendance'];
        } catch (e) {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: Variables().secondColor,content: AutoSizeText("No Attendance in this session",style: Styles().style(25, Colors.white, true),)));
        }
        try {
          widget.session.homework.mark = otherDataResponseMap['hwMark'].toString();
          // print(value['hwMark']);
        } catch (e) {
          print("Failed to put hwmark");
        }
        try {
          widget.session.mark = otherDataResponseMap['mark']??"0";
        } catch (e) {
          print("Failed to put mark");
        }
        try {
          int mcqcounter = 0;
          int paracounter = 0;
          List  questions = otherDataResponseMap['quizQuestions'];
          for (Map value in questions) {
            if (value['isMCQ']=="true") {
              mcqcounter++;
            } else {
              paracounter++;
            }
            widget.session.quiz.questions.insert(
              questions.indexOf(value),
              Question(
                imageUrl: value['imageUrl'].toString(),
                mark: value['mark'].toString(),
                isMCQ: value['isMCQ']=="true"?true:false,
                question: value['question'].toString(),
                rightLetter: value['rightanswer'].toString(),
                wrong1: value['wrong1'].toString(),
                wrong2: value['wrong2'].toString(),
                wrong3: value['wrong3'].toString(),
                chpname: value['chpname'].toString(),
                sessionname: value['sessionname'].toString(),
                sessionstage: value['sessionstage'].toString(),
                id: value['id'].toString(),
              )
            );
          }
          chooseQuestionsNumberController.text = mcqcounter.toString();
          paragraphQuestionsNumberController.text = paracounter.toString();
        } catch (e) {
          print("Failed to put quiz questions");
        }
        
        try {
          List questions = otherDataResponseMap['hwQuestions'];
          int hwmcqcounter = 0;
          int hwparacounter = 0;
          for (Map value in questions) {
            if (value['isMCQ']=="true") {
              hwmcqcounter++;
            } else {
              hwparacounter++;
            }
            widget.session.homework.questions.insert(
              questions.indexOf(value),
              Question(
                imageUrl: value['imageUrl'].toString(),
                mark: value['mark'].toString(),
                isMCQ: value['isMCQ']=="true"?true:false,
                question: value['question'].toString(),
                rightLetter: value['rightanswer'].toString(),
                wrong1: value['wrong1'].toString(),
                wrong2: value['wrong2'].toString(),
                wrong3: value['wrong3'].toString(),
                chpname: value['chpname'].toString(),
                sessionname: value['sessionname'].toString(),
                sessionstage: value['sessionstage'].toString(),
                id: value['id'].toString(),
              )
            );
          }
          hwchooseQuestionsNumberController.text = hwmcqcounter.toString();
          hwparagraphQuestionsNumberController.text = hwparacounter.toString();
        } catch (e) {
          print("Failed to put hw questions");
        }
      });
    } catch (e) {}
  }
  @override
  void initState() {
    selectedTarget = widget.state;
    selectedVisibility = widget.session.isBuyable;
    async();
    super.initState();
  }
  @override
  void dispose() {
    attendance.clear();
    pdfCards.clear();
    videoExplanationCards.clear();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: AutoSizeText(widget.session.name),
        elevation: 20,
        bottomOpacity: 0.7,
      ),
      body: Container(
        padding: const EdgeInsets.all(20),
        child: SingleChildScrollView(
          child: Column(
            children: [
              const SizedBox(
                height: 15,
              ),
              Align(
                alignment: Alignment.center,
                child: AutoSizeText(
                  "Attendance",
                  style: Styles().style(30,Variables().secondColor,true),
                )
              ),
              const SizedBox(height: 10,),
              Align(
                alignment: Alignment.centerLeft,
                child: AutoSizeText(
                  "Students Count:",
                  style: Styles().style(25,Variables().secondColor,true),
                ),
              ),
              const SizedBox(height: 5,),
              Align(
                alignment: Alignment.centerRight,
                child: AutoSizeText(
                  attendance.length.toString(),
                  style: Styles().style(20,Variables().secondColor,true),
                ),
              ),
              Align(
                alignment: Alignment.center,
                child: TextButton(
                  style: Styles().buttonStyle(Variables().mainColor,Variables().secondColor,18,bordersidecolor: Variables().secondColor),
                  onPressed: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context)=>TableScreen(attendance:attendance)));
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: AutoSizeText(
                      "Details Table",
                      style: Styles().style(25,Colors.white,true),
                    ),
                  )
                )
              ),
              const SizedBox(
                height: 15,
              ),
              const Divider(
                color: Colors.indigo,
                thickness: 2,
                height: 2,
              ),
              ///////////////////////////////////////////////////////
              SizedBox(
                height: 20,
              ),
              // Row(
              //   mainAxisAlignment: MainAxisAlignment.center,
              //   children: [
              //     Expanded(
              //       child: TextField(
              //         controller: secondnameController,
              //         style: Styles().style(20, Colors.indigo, true),
              //         decoration: InputDecoration(
              //           labelText: "Session Name",
              //           labelStyle: Styles().style(20, Colors.indigo, true),
              //           border: OutlineInputBorder(
              //             borderRadius: BorderRadius.circular(18),
              //             borderSide: const BorderSide(
              //               color: Colors.indigo,
              //               width: 2,
              //             ),
              //             gapPadding: 5,
              //           ),
              //           enabledBorder: OutlineInputBorder(
              //             borderRadius: BorderRadius.circular(18),
              //             borderSide: const BorderSide(
              //               color: Colors.indigo,
              //               width: 2,
              //             ),
              //             gapPadding: 5,
              //           ),
              //           focusedBorder: OutlineInputBorder(
              //             borderRadius: BorderRadius.circular(18),
              //             borderSide: const BorderSide(
              //               color: Colors.indigo,
              //               width: 2,
              //             ),
              //             gapPadding: 5,
              //           ),
              //           suffixIcon: IconButton(
              //             onPressed: () async {},
              //             icon: const Icon(
              //               Icons.check,
              //               color: Colors.green,
              //             )
              //           ),
              //           disabledBorder: OutlineInputBorder(
              //             borderRadius: BorderRadius.circular(18),
              //             borderSide: const BorderSide(
              //               color: Colors.indigo,
              //               width: 2,
              //             ),
              //             gapPadding: 5,
              //           ),
              //         )
              //       )
              //     )
              //   ]
              // ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Session Targets: ",
                    style: Styles().style(25, Colors.blue, true),
                  ),
                  SizedBox(
                    width: 250,
                    child: DropdownButton(
                      value: selectedTarget,
                      items: [
                        DropdownMenuItem(
                          value: "All",
                          child: Text("All",style: Styles().style(20, Colors.indigo, true))
                        ),
                        DropdownMenuItem(
                          value: "Center",
                          child: Text("Center",style: Styles().style(20, Colors.indigo, true))
                        ),
                        DropdownMenuItem(
                          value: "Online",
                          child: Text("Online",style: Styles().style(20, Colors.indigo, true))
                        ),
                      ],
                      onChanged: (value) async {
                        //TODO: http request to update targets
                        http.Response response = await http.post(
                          Uri.parse(
                            "${Variables().url}update_session_targets.php"
                          ),
                          body:{
                            "target": value,
                            "sessionname":widget.session.name,
                            "chpname":widget.chpname,
                            "chpstage":widget.chpstage,
                          }
                        );
                        if(response.statusCode == 202){
                          setState(() {
                            selectedTarget = value as String;
                          });
                        }else{
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: Colors.red,content: AutoSizeText("Error withCode: ${response.statusCode}",style: Styles().style(25, Colors.white, true),),));
                        }
                      }
                    )
                  ),
                ],
              ),
              const SizedBox(
                height: 15,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Buyable: ",
                    style: Styles().style(25, Colors.blue, true),
                  ),
                  SizedBox(
                    width: 250,
                    child: DropdownButton(
                      value: selectedVisibility,
                      items: [
                        DropdownMenuItem(
                          value: "true",
                          child: Text("Buyable",style: Styles().style(20, Colors.indigo, true))
                        ),
                        DropdownMenuItem(
                          value: "false",
                          child: Text("Not buyable",style: Styles().style(20, Colors.indigo, true))
                        ),
                      ],
                      onChanged: (value) async {
                        
                        //TODO: http request to update scientific
                        http.Response response = await http.post(
                          Uri.parse(
                            "${Variables().url}update_session_visibility.php"
                          ),
                          body:{
                            "visibility": value,
                            "sessionname":widget.session.name,
                            "chpname":widget.chpname,
                            "chpstage":widget.chpstage,
                          }
                        );
                        if(response.statusCode == 202){
                          setState(() {
                            selectedVisibility = value as String;
                          });
                        }else{
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: Colors.red,content: AutoSizeText("Error withCode: ${response.statusCode}",style: Styles().style(25, Colors.white, true),),));
                        }
                      }
                    )
                  ),
                ],
              ),
              const SizedBox(
                height: 15,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Session Price: ",
                    style: Styles().style(25, Colors.blue, true),
                  ),
                  SizedBox(
                    width: 250,
                    child: TextField(
                      controller: priceController,
                      style: Styles().style(20, Colors.indigo, true),
                      decoration: InputDecoration(
                        labelText: "Session Price",
                        labelStyle: Styles().style(20, Colors.indigo, true),
                        // hintText: 'Enter session Number',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(18),
                          borderSide: const BorderSide(
                            color: Colors.indigo,
                            width: 2,
                          ),
                          gapPadding: 5,
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(18),
                          borderSide: const BorderSide(
                            color: Colors.indigo,
                            width: 2,
                          ),
                          gapPadding: 5,
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(18),
                          borderSide: const BorderSide(
                            color: Colors.indigo,
                            width: 2,
                          ),
                          gapPadding: 5,
                        ),
                        suffixIcon: IconButton(
                          onPressed: () async {},
                          icon: const Icon(
                            Icons.check,
                            color: Colors.green,
                          )
                        ),
                        disabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(18),
                          borderSide: const BorderSide(
                            color: Colors.indigo,
                            width: 2,
                          ),
                          gapPadding: 5,
                        ),
                      ),
                      onSubmitted: (value) async {
                        http.Response response = await http.post(
                          Uri.parse(
                            "${Variables().url}update_session_price.php",
                          ),
                          body:{
                            "sessionname":widget.session.name,
                            "price":value,
                            "chpname":widget.chpname,
                            "chpstage":widget.chpstage
                          }
                        );
                        if(response.statusCode == 202){
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: Colors.green,content: AutoSizeText("Done",style: Styles().style(25, Colors.white, true),),));
                        }else{
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: Colors.red,content: AutoSizeText("Error withCode: ${response.statusCode}",style: Styles().style(25, Colors.white, true),),));
                        }
                      }
                    ),
                  ),
                ],
              ),
              const SizedBox(
                height: 15,
              ),
              const Divider(
                color: Colors.indigo,
                thickness: 2,
                height: 2,
              ),
              ///////////////////////////////////////////////////////
              Align(
                alignment: Alignment.topCenter,
                child: Text("Quiz Center",style: Styles().style(30, Colors.green, true)),
              ),
              const SizedBox(height: 20),
              const SizedBox(
                height: 7,
              ),
              const SizedBox(
                height: 7,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Time of quiz in minutes: ",
                    style: Styles().style(25, Colors.blue, true),
                  ),
                  SizedBox(
                    width: 250,
                    child: TextField(
                      controller: timerController,
                      style: Styles().style(20, Colors.indigo, true),
                      decoration: InputDecoration(
                        labelText: "Quiz Timer",
                        labelStyle: Styles().style(20, Colors.indigo, true),
                        // hintText: 'Enter session Number',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(18),
                          borderSide: const BorderSide(
                            color: Colors.indigo,
                            width: 2,
                          ),
                          gapPadding: 5,
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(18),
                          borderSide: const BorderSide(
                            color: Colors.indigo,
                            width: 2,
                          ),
                          gapPadding: 5,
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(18),
                          borderSide: const BorderSide(
                            color: Colors.indigo,
                            width: 2,
                          ),
                          gapPadding: 5,
                        ),
                        disabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(18),
                          borderSide: const BorderSide(
                            color: Colors.indigo,
                            width: 2,
                          ),
                          gapPadding: 5,
                        ),
                      ),
                      onSubmitted: (value)async{
                        http.Response response = await http.post(
                          Uri.parse(
                            "${Variables().url}update_quiz_timer.php",
                          ),
                          body:{
                            "sessionname":widget.session.name,
                            "timer":value,
                            "chpname":widget.chpname,
                            "chpstage":widget.chpstage
                          }
                        );
                        if(response.statusCode == 202){
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: Colors.green,content: AutoSizeText("Done",style: Styles().style(25, Colors.white, true),),));
                        }else{
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: Colors.red,content: AutoSizeText("Error withCode: ${response.statusCode}",style: Styles().style(25, Colors.white, true),),));
                        }
                      },
                    ),
                  ),
                ],
              ),
              const SizedBox(
                height: 7,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Quiz Success Mark: ",
                    style: Styles().style(25, Colors.blue, true),
                  ),
                  SizedBox(
                    width: 250,
                    child: TextField(
                      controller: quizsuccessMarkController,
                      style: Styles().style(20, Colors.indigo, true),
                      decoration: InputDecoration(
                        labelText: "Success Mark",
                        labelStyle: Styles().style(20, Colors.indigo, true),
                        // hintText: 'Enter session Number',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(18),
                          borderSide: const BorderSide(
                            color: Colors.indigo,
                            width: 2,
                          ),
                          gapPadding: 5,
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(18),
                          borderSide: const BorderSide(
                            color: Colors.indigo,
                            width: 2,
                          ),
                          gapPadding: 5,
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(18),
                          borderSide: const BorderSide(
                            color: Colors.indigo,
                            width: 2,
                          ),
                          gapPadding: 5,
                        ),
                        disabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(18),
                          borderSide: const BorderSide(
                            color: Colors.indigo,
                            width: 2,
                          ),
                          gapPadding: 5,
                        ),
                      ),
                      onSubmitted: (value)async{
                        http.Response response = await http.post(
                          Uri.parse(
                            "${Variables().url}update_quiz_success_mark.php",
                          ),
                          body:{
                            "sessionname":widget.session.name,
                            "mark":value,
                            "chpname":widget.chpname,
                            "chpstage":widget.chpstage
                          }
                        );
                        if(response.statusCode == 202){
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: Colors.green,content: AutoSizeText("Done",style: Styles().style(25, Colors.white, true),),));
                        }else{
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: Colors.red,content: AutoSizeText("Error withCode: ${response.statusCode}",style: Styles().style(25, Colors.white, true),),));
                        }
                      },
                    ),
                  ),
                ],
              ),
              const SizedBox(
                height: 7,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Quiz Full Mark: ",
                    style: Styles().style(25, Colors.blue, true),
                  ),
                  SizedBox(
                    width: 250,
                    child: TextField(
                      controller: quizfullMarkController,
                      style: Styles().style(20, Colors.indigo, true),
                      decoration: InputDecoration(
                        labelText: "Full Mark",
                        labelStyle: Styles().style(20, Colors.indigo, true),
                        // hintText: 'Enter session Number',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(18),
                          borderSide: const BorderSide(
                            color: Colors.indigo,
                            width: 2,
                          ),
                          gapPadding: 5,
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(18),
                          borderSide: const BorderSide(
                            color: Colors.indigo,
                            width: 2,
                          ),
                          gapPadding: 5,
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(18),
                          borderSide: const BorderSide(
                            color: Colors.indigo,
                            width: 2,
                          ),
                          gapPadding: 5,
                        ),
                        disabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(18),
                          borderSide: const BorderSide(
                            color: Colors.indigo,
                            width: 2,
                          ),
                          gapPadding: 5,
                        ),
                      ),
                      onSubmitted: (value)async{
                        http.Response response = await http.post(
                          Uri.parse(
                            "${Variables().url}update_quiz_full_mark.php",
                          ),
                          body:{
                            "sessionname":widget.session.name,
                            "mark":value,
                            "chpname":widget.chpname,
                            "chpstage":widget.chpstage
                          }
                        );
                        if(response.statusCode == 202){
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: Colors.green,content: AutoSizeText("Done",style: Styles().style(25, Colors.white, true),),));
                        }else{
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: Colors.red,content: AutoSizeText("Error withCode: ${response.statusCode}",style: Styles().style(25, Colors.white, true),),));
                        }
                      },
                    ),
                  ),
                ],
              ),
              const SizedBox(
                height: 7,
              ),
              Center(
                child: TextButton(
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all(Colors.indigo),
                    foregroundColor: MaterialStateProperty.all(Colors.white),
                    overlayColor: MaterialStateProperty.all(const Color.fromARGB(255, 0, 17, 115)),
                    shape: MaterialStateProperty.all(
                      RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(18),
                        side: const BorderSide(
                          color: Colors.indigo,
                          width: 2,
                        )
                      )
                    ),
                    padding:MaterialStateProperty.all(const EdgeInsets.all(15)),
                  ),
                  onPressed: () {
                    Navigator.of(context).push(MaterialPageRoute(
                      builder: (context) => CreateQuizScreen2(
                        chpname: widget.chpname,
                        // quiztimer: timerController.text,
                        // mcq: chooseQuestionsNumberController.text,
                        // paragraph: paragraphQuestionsNumberController.text,
                        sessionname: widget.session.name,
                        stage: widget.chpstage,
                      )
                    ));
                  },
                  child: Text(
                    "Go To Quiz Management",
                    style: Styles().style(22, Colors.white, true),
                  )
                ),
              ),
              const SizedBox(
                height: 7,
              ),
              Center(
                child: TextButton(
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all(Colors.indigo),
                      foregroundColor: MaterialStateProperty.all(Colors.white),
                      overlayColor: MaterialStateProperty.all(const Color.fromARGB(255, 0, 17, 115)),
                      shape: MaterialStateProperty.all(
                        RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(18),
                          side: const BorderSide(
                            color: Colors.indigo,
                            width: 2,
                          )
                        )
                      ),
                      padding: MaterialStateProperty.all(const EdgeInsets.all(15)),
                    ),
                  onPressed: () async {
                    http.Response hwuploadsResponse = await http.post(
                      Uri.parse("${Variables().url}get_hw_uploads.php"),
                      body: {
                        "sessionname": widget.session.name,
                        "stage": widget.chpstage,
                        "state": "quiz",
                        "chpname":widget.chpname,
                      }
                    );
                    if (hwuploadsResponse.statusCode == 303) {
                      Map hwuploads =jsonDecode(hwuploadsResponse.body.toString());
                      List finaluploads = hwuploads.values.toList();
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => HomeworkCorrection(
                            sessionname: widget.session.name,
                            stage: widget.chpstage,
                            uploads: finaluploads,
                            state: "quiz",
                          )
                        )
                      );
                    } else if (hwuploadsResponse.statusCode == 400) {
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("There is no Quiz uploads yet")));
                    } else {
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Failed")));
                    }
                  },
                  child: Text(
                    "Go To Quiz Correction",
                    style: Styles().style(22, Colors.white, true),
                  )
                ),
              ),
              const SizedBox(
                height: 15,
              ),
              const Divider(
                color: Colors.indigo,
                thickness: 2,
                height: 2,
              ),
              ///////////////////////////////////////////////////////
              const SizedBox(
                height: 15,
              ),
              Align(
                alignment: Alignment.topCenter,
                child: Text("Homework Center",
                    style: Styles().style(30, Colors.red, true)),
              ),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Success Mark: ",
                    style: Styles().style(25, Colors.blue, true),
                  ),
                  SizedBox(
                    width: 250,
                    child: TextField(
                      controller: hwsuccessMarkController,
                      style: Styles().style(20, Colors.indigo, true),
                      decoration: InputDecoration(
                        labelText: "Success Mark",
                        labelStyle: Styles().style(20, Colors.indigo, true),
                        // hintText: 'Enter session Number',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(18),
                          borderSide: const BorderSide(
                            color: Colors.indigo,
                            width: 2,
                          ),
                          gapPadding: 5,
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(18),
                          borderSide: const BorderSide(
                            color: Colors.indigo,
                            width: 2,
                          ),
                          gapPadding: 5,
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(18),
                          borderSide: const BorderSide(
                            color: Colors.indigo,
                            width: 2,
                          ),
                          gapPadding: 5,
                        ),
                        disabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(18),
                          borderSide: const BorderSide(
                            color: Colors.indigo,
                            width: 2,
                          ),
                          gapPadding: 5,
                        ),
                      ),
                      onSubmitted: (value)async{
                        http.Response response = await http.post(
                          Uri.parse(
                            "${Variables().url}update_hw_success_mark.php",
                          ),
                          body:{
                            "sessionname":widget.session.name,
                            "mark":value,
                            "chpname":widget.chpname,
                            "chpstage":widget.chpstage
                          }
                        );
                        if(response.statusCode == 202){
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: Colors.green,content: AutoSizeText("Done",style: Styles().style(25, Colors.white, true),),));
                        }else{
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: Colors.red,content: AutoSizeText("Error withCode: ${response.statusCode}",style: Styles().style(25, Colors.white, true),),));
                        }
                      },
                    ),
                  ),
                ],
              ),
              const SizedBox(
                height: 7
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Homework Full Mark: ",
                    style: Styles().style(25, Colors.blue, true),
                  ),
                  SizedBox(
                    width: 250,
                    child: TextField(
                      controller: hwfullMarkController,
                      style: Styles().style(20, Colors.indigo, true),
                      decoration: InputDecoration(
                        labelText: "Full Mark",
                        labelStyle: Styles().style(20, Colors.indigo, true),
                        // hintText: 'Enter session Number',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(18),
                          borderSide: const BorderSide(
                            color: Colors.indigo,
                            width: 2,
                          ),
                          gapPadding: 5,
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(18),
                          borderSide: const BorderSide(
                            color: Colors.indigo,
                            width: 2,
                          ),
                          gapPadding: 5,
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(18),
                          borderSide: const BorderSide(
                            color: Colors.indigo,
                            width: 2,
                          ),
                          gapPadding: 5,
                        ),
                        disabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(18),
                          borderSide: const BorderSide(
                            color: Colors.indigo,
                            width: 2,
                          ),
                          gapPadding: 5,
                        ),
                      ),
                      onSubmitted: (value)async{
                        http.Response response = await http.post(
                          Uri.parse(
                            "${Variables().url}update_hw_full_mark.php",
                          ),
                          body:{
                            "sessionname":widget.session.name,
                            "mark":value,
                            "chpname":widget.chpname,
                            "chpstage":widget.chpstage
                          }
                        );
                        if(response.statusCode == 202){
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: Colors.green,content: AutoSizeText("Done",style: Styles().style(25, Colors.white, true),),));
                        }else{
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: Colors.red,content: AutoSizeText("Error withCode: ${response.statusCode}",style: Styles().style(25, Colors.white, true),),));
                        }
                      },
                    ),
                  ),
                ],
              ),
              const SizedBox(
                height: 7,
              ),
              Center(
                child: TextButton(
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all(Colors.indigo),
                    foregroundColor: MaterialStateProperty.all(Colors.white),
                    overlayColor: MaterialStateProperty.all(const Color.fromARGB(255, 0, 17, 115)),
                    shape: MaterialStateProperty.all(
                      RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(18),
                        side: const BorderSide(
                          color: Colors.indigo,
                          width: 2,
                        )
                      )
                    ),
                    padding: MaterialStateProperty.all(const EdgeInsets.all(15)),
                  ),
                  onPressed: () async {
                    Navigator.push(context, MaterialPageRoute(builder: (context)=>CreateHwScreen(sessionname: widget.session.name, stage: widget.chpstage, chpname: widget.chpname)));
                    // setState(() {
                    //   loadinghere = true;
                    // 
                    // http.Response hwsaving = await http.post(
                    //     Uri.parse("${Variables().ip}hw_saving.php"),
                    //     body: {
                    //       "sessionname": widget.sessionNumber,
                    //       "successmark": hwsuccessMarkController.text,
                    //       "stage": widget.stage,
                    //     });
                    // ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                    //   content: SizedBox(
                    //       height: MediaQuery.of(context).size.height - 200,
                    //       child: Center(
                    //         child: Text(
                    //           "Done",
                    //           style: Styles().style(23, Colors.white, true),
                    //         ),
                    //       )),
                    //   backgroundColor: Colors.green,
                    //   shape: const RoundedRectangleBorder(
                    //       borderRadius: BorderRadius.only(
                    //           bottomLeft: Radius.circular(18),
                    //           bottomRight: Radius.circular(18),
                    //           topRight: Radius.circular(18))),
                    // ));
                    // Navigator.push(
                    //     context,
                    //     MaterialPageRoute(
                    //         builder: (context) => MakeHomeworkScreen(
                    //               mcq: hwchooseQuestionsNumberController
                    //                       .text.isNotEmpty
                    //                   ? hwchooseQuestionsNumberController
                    //                       .text
                    //                   : "0",
                    //               paragraph:
                    //                   hwparagraphQuestionsNumberController
                    //                           .text.isNotEmpty
                    //                       ? hwparagraphQuestionsNumberController
                    //                           .text
                    //                       : "0",
                    //               sessionname: widget.sessionNumber,
                    //               stage: widget.stage.toString(),
                    //             )));
                    // setState(() {
                    //   loadinghere = false;
                    // });
                  },
                  child: Text(
                    "Go To Homework Management",
                    style: Styles().style(22, Colors.white, true),
                  )
                ),
              ),
              const SizedBox(
                height: 15,
              ),
              Center(
                child: TextButton(
                  style: ButtonStyle(
                    backgroundColor:MaterialStateProperty.all(Colors.indigo),
                    foregroundColor:MaterialStateProperty.all(Colors.white),
                    overlayColor: MaterialStateProperty.all(const Color.fromARGB(255, 0, 17, 115)),
                    shape: MaterialStateProperty.all(
                      RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(18),
                        side: const BorderSide(
                          color: Colors.indigo,
                          width: 2,
                        )
                      )
                    ),
                    padding: MaterialStateProperty.all(const EdgeInsets.all(15)),
                  ),
                  onPressed: () async {
                    http.Response hwuploadsResponse = await http.post(
                      Uri.parse("${Variables().url}get_hw_uploads.php"),
                      body: {
                        "sessionname": widget.session.name,
                        "stage": widget.chpstage,
                        "state": "hw",
                        "chpname":widget.chpname,
                      }
                    );
                    if (hwuploadsResponse.statusCode == 303) {
                      Map hwuploads = jsonDecode(hwuploadsResponse.body.toString());
                      List finaluploads = hwuploads.values.toList();
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => HomeworkCorrection(
                            sessionname: widget.session.name,
                            stage: widget.chpstage,
                            uploads: finaluploads,
                            state:"hw",
                          )
                        )
                      );
                    } else if (hwuploadsResponse.statusCode == 400) {
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("There is no homeworks uploads yet")));
                    } else {
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Failed")));
                    }
                  },
                  child: Text(
                    "Go To Homework Correction",
                    style: Styles().style(22, Colors.white, true),
                  )
                ),
              ),
              const SizedBox(
                height: 15,
              ),
              const Divider(
                color: Colors.indigo,
                thickness: 2,
                height: 2,
              ),
              ///////////////////////////////////////////////////////
              const SizedBox(
                height: 15,
              ),
              Align(
                alignment: Alignment.topCenter,
                child: Text("Videos Links",
                    style: Styles().style(30, Colors.indigo, true)),
              ),
              const SizedBox(height: 20),
              Align(
                alignment: Alignment.topLeft,
                child: Text("Videos : ",
                    style: Styles().style(30, Colors.indigo, true)),
              ),
              const SizedBox(height: 20),
              ListView.builder(
                  shrinkWrap: true,
                  itemCount: videoExplanationCards.length,
                itemBuilder: (context, index) {
                  return Row(
                    children: [
                      videoExplanationCards.keys.elementAt(index),
                      IconButton(
                        onPressed: () async {
                          http.Response response = await http.post(
                            Uri.parse(
                              "${Variables().url}delete_video.php",
                            ),
                            body:{
                              "sessionname":widget.session.name,
                              "videourl":videoExplanationCards.values.elementAt(index)[0].text,
                              "videotitle":videoExplanationCards.values.elementAt(index)[1].text,
                              "chpname":widget.chpname,
                              "chpstage":widget.chpstage
                            }
                          );
                          if(response.statusCode == 202){
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: Colors.green,content: AutoSizeText("Done",style: Styles().style(25, Colors.white, true),),));
                            setState(() {
                              videoExplanationCards.remove(videoExplanationCards.keys.elementAt(index));
                            });
                          }else{
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: Colors.red,content: AutoSizeText("Error withCode: ${response.statusCode}",style: Styles().style(25, Colors.white, true),),));
                          }
                        },
                        icon: const Icon(Icons.delete, color: Colors.red)
                      )
                    ],
                  );
                }
              ),
              Align(
                alignment: Alignment.bottomRight,
                child: TextButton(
                  onPressed: () {
                    String state = "Explanation";
                    final TextEditingController videoLinkController = TextEditingController();
                    final TextEditingController videonameController = TextEditingController();
                    showDialog(
                      context: context,
                      builder: (context) {
                        return Dialog(
                          child: SizedBox(
                            height: MediaQuery.of(context).size.height -100,
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Column(
                                children: [
                                  SizedBox(width: MediaQuery.of(context).size.width-100,child: VideoCard(index: videoExplanationCards.length - 1, videoLinkController: videoLinkController, videonameController: videonameController)),
                                  const SizedBox(height: 10),
                                  ElevatedButton(
                                    onPressed: () async {
                                      http.Response response = await http.post(
                                        Uri.parse("${Variables().url}add_video.php"),
                                        body: {
                                          "sessionname":widget.session.name,
                                          "videourl":videoLinkController.text,
                                          "videotitle":videonameController.text,
                                          "chpname":widget.chpname,
                                          "chpstage":widget.chpstage
                                        },
                                      );
                                      if(response.statusCode == 202){
                                        Navigator.pop(context);
                                        setState(() {
                                          videoExplanationCards.addAll({
                                            VideoCard(
                                              index: videoExplanationCards.length - 1,
                                              videoLinkController: videoLinkController,
                                              videonameController: videonameController): [
                                              videoLinkController,
                                              videonameController,
                                              state
                                            ]
                                          });
                                        });
                                      }else{
                                        Navigator.pop(context);
                                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: Colors.red,content: AutoSizeText("Error withCode: ${response.statusCode}",style: Styles().style(25, Colors.white, true),),));
                                      }
                                    },
                                    child: AutoSizeText(
                                      "Add",
                                      style: Styles().style(22,Variables().secondColor,true),
                                    ),
                                  ),
                                ],
                              )
                            ),
                          )
                        );
                      }
                    );
                  },
                  // icon: const Icon(Icons.add, color: Colors.blue)
                  child: Text(
                    "Add Video",
                    style: Styles().style(20,Colors.blue,true)
                  )
                ),
              ),
              ////////////////////////////////
              const SizedBox(height: 20),
              // Align(
              //   alignment: Alignment.topLeft,
              //   child: Text("Homework Videos : ",
              //       style: Styles().style(30, Colors.indigo, true)),
              // ),
              // const SizedBox(height: 20),
              // ListView.builder(
              //     shrinkWrap: true,
              //     itemCount: videohwCards.length,
              //     itemBuilder: (context, index) {
              //       return Row(
              //         children: [
              //           videohwCards.keys.elementAt(index),
              //           IconButton(
              //               onPressed: () {
              //                 setState(() {
              //                   videohwCards.remove(
              //                       videohwCards.keys.elementAt(index));
              //                 });
              //               },
              //               icon: const Icon(Icons.delete, color: Colors.red))
              //         ],
              //       );
              //     }),
              
              // Align(
              //   alignment: Alignment.bottomRight,
              //   child: IconButton(
              //       onPressed: () {
              //         // String state = "Homework";
              //         // final TextEditingController videoLinkController =
              //         //     TextEditingController();
              //         // final TextEditingController videonameController =
              //         //     TextEditingController();

              //         // setState(() {
              //         //   videohwCards.addAll({
              //         //     VideoCard(
              //         //         index: videohwCards.length - 1,
              //         //         videoLinkController: videoLinkController,
              //         //         videonameController: videonameController): [
              //         //       videoLinkController,
              //         //       videonameController,
              //         //       state
              //         //     ]
              //         //   });
              //         // });
              //       },
              //       icon: const Icon(Icons.add, color: Colors.blue)),
              // ),
              //////////////////////
              Align(
                alignment: Alignment.topLeft,
                child: Text("PDFs : ",
                    style: Styles().style(30, Colors.indigo, true)),
              ),
              const SizedBox(height: 20),
              ListView.builder(
                shrinkWrap: true,
                itemCount: pdfCards.length,
                itemBuilder: (context, index) {
                  return Row(
                    children: [
                      pdfCards.keys.elementAt(index),
                      IconButton(
                        onPressed: () async {
                          http.Response response = await http.post(
                            Uri.parse(
                              "${Variables().url}delete_doc.php",
                            ),
                            body:{
                              "sessionname":widget.session.name,
                              "docurl":pdfCards.values.elementAt(index)[0].text,
                              "doctitle":pdfCards.values.elementAt(index)[1].text,
                              "chpname":widget.chpname,
                              "chpstage":widget.chpstage
                            }
                          );
                          if(response.statusCode == 202){
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: Colors.green,content: AutoSizeText("Done",style: Styles().style(25, Colors.white, true),),));
                            setState(() {
                              pdfCards.remove(pdfCards.keys.elementAt(index));
                            });
                          }else{
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: Colors.red,content: AutoSizeText("Error withCode: ${response.statusCode}",style: Styles().style(25, Colors.white, true),),));
                          }
                        },
                        icon: const Icon(Icons.delete, color: Colors.red)
                      )
                    ],
                  );
                }
              ),
              Align(
                alignment: Alignment.bottomRight,
                child: TextButton(
                  onPressed: () {
                    TextEditingController pdfLinkController = TextEditingController();
                    TextEditingController pdfnameController = TextEditingController();
                    showDialog(
                      context: context,
                      builder: (context) {
                        return Dialog(
                          // title: Text("Add Doc"),
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Column(
                              children: [
                                SizedBox(width: MediaQuery.of(context).size.width-100,child: PdfCard(index: pdfCards.length - 1, pdfLinkController: pdfLinkController, pdfnameController: pdfnameController)),
                                const SizedBox(height: 10),
                                ElevatedButton(
                                  onPressed: () async {
                                    http.Response response = await http.post(
                                      Uri.parse("${Variables().url}add_doc.php"),
                                      body: {
                                        "sessionname":widget.session.name,
                                        "docurl":pdfLinkController.text,
                                        "doctitle":pdfnameController.text,
                                        "chpname":widget.chpname,
                                        "chpstage":widget.chpstage
                                      },
                                    );
                                    if(response.statusCode == 202){
                                      Navigator.pop(context);
                                      setState(() {
                                        pdfCards.addAll({
                                          PdfCard(
                                            index: pdfCards.length - 1,
                                            pdfLinkController: pdfLinkController,
                                            pdfnameController: pdfnameController): [
                                            pdfLinkController,
                                            pdfnameController,
                                          ]
                                        });
                                      });
                                    }else{
                                      Navigator.pop(context);
                                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: Colors.red,content: AutoSizeText("Error withCode: ${response.statusCode}",style: Styles().style(25, Colors.white, true),),));
                                    }
                                  },
                                  child: AutoSizeText(
                                    "Add",
                                    style: Styles().style(22,Variables().secondColor,true),
                                  ),
                                ),
                              ],
                            )
                          )
                        );
                      }
                    );
                    setState(() {
                      pdfCards.addAll({
                        PdfCard(
                          index: pdfCards.length - 1,
                          pdfLinkController: pdfLinkController,
                          pdfnameController: pdfnameController,
                        ): [pdfLinkController, pdfnameController]
                      });
                    });
                  },
                  // icon: const Icon(Icons.add, color: Colors.blue)
                  child: Text(
                    "Add Document",
                    style: Styles().style(20,Colors.blue,true)
                  )
                ),
              ),
              const SizedBox(
                height: 7,
              ),
              Center(
                child: TextButton(
                    style: ButtonStyle(
                      backgroundColor:
                          MaterialStateProperty.all(Colors.indigo),
                      foregroundColor:
                          MaterialStateProperty.all(Colors.white),
                      overlayColor: MaterialStateProperty.all(
                          const Color.fromARGB(255, 0, 17, 115)),
                      shape: MaterialStateProperty.all(RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(18),
                          side: const BorderSide(
                            color: Colors.indigo,
                            width: 2,
                          ))),
                      padding:
                          MaterialStateProperty.all(const EdgeInsets.all(15)),
                    ),
                    onPressed: () async {
                      // for (var i = 0; i < videoExplanationCards.length; i++) {
                      //   http.Response explanationVideosLinksResponse =
                      //       await http.post(
                      //           Uri.parse(
                      //               "${Variables().ip}submit_videos_links.php"),
                      //           body: {
                      //         "stage": widget.stage,
                      //         "sessionname": widget.sessionNumber,
                      //         "videolink": videoExplanationCards.values
                      //             .elementAt(i)[0]
                      //             .text,
                      //         "videostate": "Explanation",
                      //         "videoname": videoExplanationCards.values
                      //             .elementAt(i)[1]
                      //             .text,
                      //       });
                      // }
                      // for (var i = 0; i < videohwCards.length; i++) {
                      //   http.Response hwVideosLinksResponse = await http.post(
                      //       Uri.parse(
                      //           "${Variables().ip}submit_videos_links.php"),
                      //       body: {
                      //         "stage": widget.stage,
                      //         "sessionname": widget.sessionNumber,
                      //         "videolink":
                      //             videohwCards.values.elementAt(i)[0].text,
                      //         "videostate": "Homework",
                      //         "videoname":
                      //             videohwCards.values.elementAt(i)[1].text,
                      //       });
                      // }
                      // for (var i = 0; i < pdfCards.length; i++) {
                      //   http.Response pdfLinksResponse = await http.post(
                      //       Uri.parse(
                      //           "${Variables().ip}submit_pdf_links.php"),
                      //       body: {
                      //         "stage": widget.stage,
                      //         "sessionname": widget.sessionNumber,
                      //         "pdflink": pdfCards.values.elementAt(i)[0].text,
                      //         "pdfname": pdfCards.values.elementAt(i)[1].text,
                      //       });
                      // }
                    },
                    child: Text(
                      "Submit links",
                      style: Styles().style(22, Colors.white, true),
                    )),
              ),
              const SizedBox(
                height: 15,
              ),
            ],
          ),
        ),
      ),
    );
  }
}