import 'dart:convert';
import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:quadroedu/adapters/homework.dart';
import 'package:quadroedu/adapters/quiz.dart';
import 'package:quadroedu/adapters/session.dart';
import 'package:quadroedu/classes/styles.dart';
import 'package:quadroedu/classes/variables.dart';
import 'package:http/http.dart' as http;
import 'package:quadroedu/screens/admin/admin_session_screen.dart';
import 'package:file_picker/file_picker.dart';
class ChapterAdminScreen extends StatefulWidget {
  const ChapterAdminScreen({super.key, required this.chapterName, required this.chapterStage});
  final String chapterName;
  final String chapterStage;
  @override
  State<ChapterAdminScreen> createState() => _ChapterAdminScreenState();
}

List sessions = [];
TextEditingController controllernameController = TextEditingController();
TextEditingController controllerdescriptionController = TextEditingController();
class _ChapterAdminScreenState extends State<ChapterAdminScreen> {
  Future<String> uploadFile() async {
    final file = await FilePicker.platform.pickFiles();
    if (file != null) {
      final bytes = file.files[0].bytes;
      final url = 'https://storage.bunnycdn.com/balanceacademyfiles/${file.files[0].name}';
      final headers = {
        'AccessKey': '8a9a18a0-019f-4f1b-98f7a8a608d1-5981-4eb1',
        'Content-Type': 'application/octet-stream',
      };
      final response = await http.put(Uri.parse(url), headers: headers, body: bytes);
      if (response.statusCode == 201) {
        return "https://balanceacademyfiles.b-cdn.net/${file.files[0].name}";
      } else {
        print('Error uploading file: ${response.statusCode}');
        return "Error";
      }
    }else{
      return "no file";
    }
  }
  async()async{
    http.Response sessionsResponse = await http.post(
      Uri.parse(
        "${Variables().url}get_sessions_admin.php",
      ),
      body:{
        "chpname": widget.chapterName,
        "chpstage": widget.chapterStage,
        "state":"All"
      }
    );
    Map sessionsResponseMap = json.decode(sessionsResponse.body);
    sessionsResponseMap.forEach((key,value) {
      setState(() {
        sessions.insert(sessionsResponseMap.keys.toList().indexOf(key),value);
      });
    });
  }
  @override
  void initState() {
    sessions.clear();
    async();
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width - 205;
    final crossAxisCount = screenWidth ~/ 350;
    return Scaffold(
      backgroundColor: Variables().secondColor,
      appBar: AppBar(
        title: AutoSizeText(widget.chapterName),
        elevation: 20,
        bottomOpacity: 0.7,
      ),
      body: GridView.builder(
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: crossAxisCount > 0 ? crossAxisCount : 1,
          childAspectRatio: 1,
          crossAxisSpacing: 10,
          mainAxisSpacing: 10,
        ),
        itemCount: sessions.length+1,
        itemBuilder: (context, index) {
          String filenameuploaded = "";
          TextEditingController sessionnameController = TextEditingController(text: "");
          TextEditingController sessionpriceController = TextEditingController(text: "0");
          // TextEditingController sessionurlController = TextEditingController(text: "");
          String selectedState = "All";
          try {
            Session sessionnow = Session(
              price: sessions.elementAt(index)['price'],
              stage: widget.chapterStage,
              isBuyable: sessions.elementAt(index)['buyable'],
              name: sessions.elementAt(index)['name'],
              videos: [],
              docs: [],
              mark: "",
              quiz: Quiz(
                quizTimer: sessions.elementAt(index)['quiztimer'],
                onSession: sessions.elementAt(index)['onSession'],
                sessionName: sessions.elementAt(index)['name'],
                questions: [],
                stage: widget.chapterStage,
                successMark: sessions.elementAt(index)['quizSuccessMark'],
                fullMark: sessions.elementAt(index)['quizFullMark']
              ),
              url: sessions.elementAt(index)['image'],
              homework: Homework(
                sessionName: sessions.elementAt(index)['name'],
                questions: [],
                stage: widget.chapterStage,
                successMark: sessions.elementAt(index)['hwSuccessMark'],
                fullMark: sessions.elementAt(index)['hwFullMark'],
                mark: ""
              )
            );
            return StatefulBuilder(
              builder: (context,setState){
                return TextButton(
                  onPressed: () async {
                    Navigator.push(context, MaterialPageRoute(builder: (context)=>AdminSessionScreen(session: sessionnow,chpname: widget.chapterName,chpstage: widget.chapterStage,state: sessions.elementAt(index)['state'],)));
                  },
                  child: SizedBox(
                    width: 300,
                    height: 400,
                    child: Card(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      color: Colors.white,
                      child: Padding(
                        padding: const EdgeInsets.all(25),
                        child: Column(
                          children: [
                            sessionnow.url!="https://balanceacademyfiles.b-cdn.net/"?SizedBox(
                              height: 200,
                              child: Image.network(
                                sessionnow.url,
                                fit: BoxFit.cover,
                              ),
                            ):const SizedBox(height: 200,),
                            Spacer(),
                            AutoSizeText(
                              sessionnow.name,
                              maxLines: 3,
                              style: Styles().style(20, Colors.black, false),
                            ),
                            AutoSizeText(
                              "Center/Online :"+sessions.elementAt(index)['state'],
                              style: Styles().style(20, Colors.black, true),
                            ),
                            AutoSizeText(
                              sessions.elementAt(index)['buyable']=="true"?"Buyable":"Not buyable",
                              style: Styles().style(20, Colors.black, true),
                            ),
                            TextButton(
                              onPressed:()async{
                                http.Response deleteResponse = await http.post(
                                  Uri.parse("${Variables().url}/delete_session.php"),
                                  body:{
                                    "session_id":sessions.elementAt(index)['id']
                                  }
                                );
                                if(deleteResponse.statusCode == 202){
                                  setState((){
                                    sessions.clear();
                                  });
                                  await async();
                                  setState((){});
                                }else{
                                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text("An error happines")));
                                }
                              },
                              child:AutoSizeText(
                                "Delete",
                                style: Styles().style(20, Colors.red, true),
                              )
                            )
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              },
            );       
          } catch (e) {
            return TextButton(
              onPressed: () async {
                showDialog(context: context, builder: (context)=>Dialog(
                  child: StatefulBuilder(builder: (context,setState2)=>Column(
                    children: [
                      Text(
                        "Add Session in ${widget.chapterName}",
                        style: Styles().style(30, Colors.black, true),
                      ),
                      const SizedBox(height: 10,),
                      TextField(
                        controller: sessionnameController,
                        decoration: InputDecoration(
                          labelText: "Session Name",
                          border: OutlineInputBorder(),
                        ),
                      ),
                      const SizedBox(height: 10,),
                      // TextField(
                      //   controller: sessionurlController,
                      //   decoration: InputDecoration(
                      //     labelText: "Session URL",
                      //     border: OutlineInputBorder(),
                      //   ),
                      // ),
                      TextButton.icon(
                        style: Styles().buttonStyle(Variables().mainColor, Variables().secondColor, 20),
                        onPressed: ()async{
                          setState(() {
                          });
                          String fileUrl = await uploadFile();
                          if (fileUrl == "Error") {
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: AutoSizeText("Error in uploading")));
                          } else if(fileUrl=="no file"){
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: AutoSizeText("No Files Selected")));
                          }else{
                            setState(() {
                              filenameuploaded = fileUrl.replaceAll("https://balanceacademyfiles.b-cdn.net/", "");
                            });
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: AutoSizeText("${fileUrl.replaceAll("https://balanceacademyfiles.b-cdn.net/", "")} Uploaded")));
                            // http.Response storeUpload = await http.post(
                            //   Uri.parse(
                            //     "${Variables().url}upload.php"
                            //   ),
                            //   body: {
                            //     "name" : Variables().getStudent().name,
                            //     "url" : fileUrl,
                            //     "chpname": widget.chpname,
                            //     "sessionname" : widget.session.name,
                            //     "stage" : Variables().getStudent().stage,
                            //     "state" : "quiz",
                            //     "filename" : fileUrl.replaceAll("https://balanceacademyfiles.b-cdn.net/", ""),
                            //     "questionid" : "",
                            //     "question" : questions[currentIndex].question
                            //   }
                            // );
                          }
                          setState(() {
                            filenameuploaded = fileUrl.replaceAll("https://balanceacademyfiles.b-cdn.net/", "");
                          });
                        },
                        icon: Icon(
                          Icons.upload,
                          size: 19,
                          color: Colors.white,
                        ),
                        label: AutoSizeText(
                          filenameuploaded==""?"Upload":filenameuploaded,
                          style: Styles().style(25, Colors.white, false),
                        )
                      ),
                      const SizedBox(height: 10,),
                      TextField(
                        controller: sessionpriceController,
                        decoration: InputDecoration(
                          labelText: "Session Price",
                          border: OutlineInputBorder(),
                        ),
                      ),
                      const SizedBox(height: 10,),
                      DropdownButton(
                        value: selectedState,
                        items: [
                          DropdownMenuItem(value: "All", child: Text("All")),
                          DropdownMenuItem(value: "Center", child: Text("Center")),
                          DropdownMenuItem(value: "Online", child: Text("Online")),
                        ],
                        onChanged: (value){
                          setState2((){
                            selectedState = value as String;
                          });
                        }
                      ),
                      const SizedBox(height: 10,),
                      TextButton(
                        style: Styles().buttonStyle(Colors.black, Colors.grey, 18,bordersidecolor: Colors.black),
                        onPressed: ()async{
                          http.Response response = await http.post(
                            Uri.parse("${Variables().url}add_session.php"),
                            body: {
                              "sessionname" : sessionnameController.text,
                              "chpstage" : widget.chapterStage,
                              "chpname" : widget.chapterName,
                              "price" : sessionpriceController.text,
                              "state" : selectedState,
                              "url" : "https://balanceacademyfiles.b-cdn.net/$filenameuploaded",
                              "onSession": sessions.isEmpty?"":sessions.elementAt(index-1)['name']
                            }
                          );
                          if (response.statusCode == 202) {
                            Navigator.pop(context);
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: Colors.green,content: AutoSizeText("Done",style: Styles().style(25, Colors.white, true),)));
                            Session sessionnow = Session(
                              price: sessionpriceController.text,
                              stage: widget.chapterStage,
                              isBuyable: "true",
                              name: sessionnameController.text,
                              videos: [],
                              docs: [],
                              mark: "",
                              quiz: Quiz(
                                quizTimer: "0",
                                onSession: sessions.elementAt(index-1)['name'],
                                sessionName: sessionnameController.text,
                                questions: [],
                                stage: widget.chapterStage,
                                successMark: "0",
                                fullMark: "0"
                              ),
                              url: "https://balanceacademyfiles.b-cdn.net/$filenameuploaded",
                              homework: Homework(
                                sessionName: sessionnameController.text,
                                questions: [],
                                stage: widget.chapterStage,
                                successMark: "0",
                                fullMark: "0",
                                mark: ""
                              )
                            );
                            Navigator.push(context, MaterialPageRoute(builder: (context)=>AdminSessionScreen(session: sessionnow,chpname: widget.chapterName,chpstage: widget.chapterStage,state: selectedState,)));
                          } else {
                            Navigator.pop(context);
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: Colors.red,content: AutoSizeText("Error with code: ${response.statusCode}",style: Styles().style(25, Colors.white, true),)));
                          }
                        },
                        child: AutoSizeText(
                          "Add Session",
                          style: Styles().style(20, Colors.white, true),
                        )
                      )
                    ]
                  )),
                ));
              },
              child: SizedBox(
                width: 300,
                height: 400,
                child: Card(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  color: Colors.white,
                  child: Padding(
                    padding: const EdgeInsets.all(25),
                    child: Text(
                      "Add Session",
                      style: Styles().style(25, Colors.black, true),
                    )
                  ),
                ),
              ),
            );
          }
        }
      ),
    );
  }
}