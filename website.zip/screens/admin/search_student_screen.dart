import 'dart:convert';

import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:quadroedu/classes/styles.dart';
import 'package:quadroedu/classes/variables.dart';
class SearchStudentScreen extends StatefulWidget {
  const SearchStudentScreen({super.key});

  @override
  State<SearchStudentScreen> createState() => _SearchStudentScreenState();
}
List searchResults = [];

class _SearchStudentScreenState extends State<SearchStudentScreen> {
  search(String query)async{
    http.Response response = await http.post(
      Uri.parse(
        "${Variables().url}search.php"
      ),
      body: {
        "query": query
      }
    );
    if (response.statusCode == 202) {
      setState(() {
        searchResults = jsonDecode(response.body);
      });
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: AutoSizeText("Search"),
        elevation: 20,
        bottomOpacity: 0.7,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(
              width: MediaQuery.of(context).size.width-100,
              child: TextField(
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'Search',
                  suffixIcon: IconButton(
                    onPressed: (){
                      setState((){
                        searchResults.clear();
                      });
                    },
                    icon: Icon(Icons.clear),
                  )
                ),
                onChanged: (value)async{
                  await search(value);
                },
              ),
            ),
            const SizedBox(height: 10,),
            Divider(
              thickness: 2,
              color: Colors.blue,
            ),
            const SizedBox(height: 10,),
            ListView.builder(
              shrinkWrap: true,
              itemCount: searchResults.length,
              itemBuilder: (context,index){
                Map chapters =searchResults[index]['chapters'];
                String selectedchp = chapters.keys.elementAt(0);
                String selectedchp2 = chapters.keys.elementAt(0);
                String selectedsession = "";
                String selectedsession2 = "";
                getSessions(List sessions){
                  return sessions.map((element)=>DropdownMenuItem(value:element,child: Text(element))).toList()..add(DropdownMenuItem(value:"",child: Text("Select")));
                }
                // TextEditingController sessionnameController = TextEditingController();
                // TextEditingController chapternameController = TextEditingController();
                // TextEditingController sessionname2Controller = TextEditingController();
                // TextEditingController chaptername2Controller = TextEditingController();
                return StatefulBuilder(
                  builder: (context, setState2) {
                    return Card(
                      child: Padding(
                        padding: const EdgeInsets.all(20),
                        child: Column(
                          children: [
                            Icon(
                              Icons.person,
                              color: Colors.blue,
                              size: 30,
                            ),
                            Text(
                              "ID: "+searchResults[index]['id'],
                              style: Styles().style(25,Colors.indigo,true),
                            ),
                            Text(
                              "Name: "+searchResults[index]['name'],
                              style: Styles().style(25,Colors.indigo,true),
                            ),
                            Text(
                              "Stage: "+searchResults[index]['stage'],
                              style: Styles().style(25,Colors.indigo,true),
                            ),
                            Text(
                              "Phone: "+searchResults[index]['phone'],
                              style: Styles().style(25,Colors.indigo,true),
                            ),
                            Text(
                              "Parent: "+searchResults[index]['parentphone'],
                              style: Styles().style(25,Colors.indigo,true),
                            ),
                            Text(
                              "State: "+searchResults[index]['state'],
                              style: Styles().style(25,Colors.indigo,true),
                            ),
                            Text(
                              "Center: "+searchResults[index]['center'],
                              style: Styles().style(25,Colors.indigo,true),
                            ),
                            Text(
                              "Wallet: "+searchResults[index]['balance'],
                              style: Styles().style(25,Colors.indigo,true),
                            ),
                            Text(
                              "Password: "+searchResults[index]['password'],
                              style: Styles().style(25,Colors.indigo,true),
                            ),
                            Wrap(
                              runSpacing: 10,
                              alignment: WrapAlignment.center,
                              children: [
                                TextButton(
                                  style: Styles().buttonStyle(Colors.blue, Colors.blue[900], 18),
                                  onPressed: ()async{
                                    http.Response response = await http.post(
                                      Uri.parse("${Variables().url}revoke.php"),
                                      body: {
                                        "phone":searchResults[index]['phone'],
                                        "type":"device"
                                      }
                                    );
                                    if (response.statusCode==202) {
                                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: Colors.green,content: AutoSizeText("Done",style: Styles().style(25, Colors.white, true))));
                                    } else {
                                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: Colors.red,content: AutoSizeText("Error With code: ${response.statusCode}",style: Styles().style(25, Colors.white, true))));
                                    }
                                  },
                                  child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: AutoSizeText(
                                      "Revoke Device",
                                      style: Styles().style(25, Colors.white, true),
                                    ),
                                  )
                                ),
                                TextButton(
                                  style: Styles().buttonStyle(Colors.blue, Colors.blue[900], 18),
                                  onPressed: ()async{
                                    http.Response response = await http.post(
                                      Uri.parse("${Variables().url}revoke.php"),
                                      body: {
                                        "phone":searchResults[index]['phone'],
                                        "type":"password"
                                      }
                                    );
                                    if (response.statusCode==202) {
                                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: Colors.green,content: AutoSizeText("Done",style: Styles().style(25, Colors.white, true))));
                                    } else {
                                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: Colors.red,content: AutoSizeText("Error With code: ${response.statusCode}",style: Styles().style(25, Colors.white, true))));
                                    }
                                  },
                                  child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: AutoSizeText(
                                      "Revoke Password",
                                      style: Styles().style(25, Colors.white, true),
                                    ),
                                  )
                                ),
                                TextField(
                                  controller: TextEditingController(text: searchResults[index]['balance']),
                                  style: Styles().style(25, Colors.indigo, true),
                                  decoration: InputDecoration(
                                    border: OutlineInputBorder(),
                                    labelText: "Charge",
                                  ),
                                  onSubmitted: (value)async{
                                    http.Response response = await http.post(
                                      Uri.parse(
                                        "${Variables().url}charge.php"
                                      ),
                                      body:{
                                        "value":value,
                                        "phone":searchResults[index]['phone']
                                      }
                                    );
                                    if (response.statusCode==202) {
                                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: Colors.green,content: AutoSizeText("Done",style: Styles().style(25, Colors.white, true))));
                                    } else {
                                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: Colors.red,content: AutoSizeText("Error With code: ${response.statusCode}",style: Styles().style(25, Colors.white, true))));
                                    }
                                  },
                                ),
                                Card(
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10),
                                    side: BorderSide(
                                      color: Colors.blue,
                                      width: 2
                                    )
                                  ),
                                  child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Column(
                                      children: [
                                        DropdownButton(
                                          value: selectedchp,
                                          items: chapters.keys.map((element)=>DropdownMenuItem(value:element,child: Text(element))).toList()..add(DropdownMenuItem(value:"",child: Text("Select"))),
                                          onChanged: (value){
                                            setState2(() {
                                              selectedsession="";
                                              selectedchp = value as String;
                                            });
                                          }
                                        ),
                                        DropdownButton(
                                          value: selectedsession,
                                          items: getSessions(chapters[selectedchp]),
                                          onChanged: (value){
                                            setState2(() {
                                              selectedsession = value as String;
                                            });
                                          }
                                        ),
                                        TextButton(
                                          style: Styles().buttonStyle(Colors.blue, Colors.blue[900], 18),
                                          onPressed: ()async{
                                            http.Response response = await http.post(
                                              Uri.parse("${Variables().url}revoke.php"),
                                              body: {
                                                "phone":searchResults[index]['phone'],
                                                "type":"views",
                                                "sessionname":selectedsession,
                                                "chaptername":selectedchp,
                                                "chpstage":searchResults[index]['stage'],
                                              }
                                            );
                                            if (response.statusCode==202) {
                                              ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: Colors.green,content: AutoSizeText("Done",style: Styles().style(25, Colors.white, true))));
                                            } else {
                                              ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: Colors.red,content: AutoSizeText("Error With code: ${response.statusCode}",style: Styles().style(25, Colors.white, true))));
                                            }
                                          },
                                          child: Padding(
                                            padding: const EdgeInsets.all(8.0),
                                            child: AutoSizeText(
                                              "Revoke Views",
                                              style: Styles().style(25, Colors.white, true),
                                            ),
                                          )
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Card(
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10),
                                    side: BorderSide(
                                      color: Colors.blue,
                                      width: 2
                                    )
                                  ),
                                  child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Column(
                                      children: [
                                        DropdownButton(
                                          value: selectedchp2,
                                          items: chapters.keys.map((element)=>DropdownMenuItem(value:element,child: Text(element))).toList()..add(DropdownMenuItem(value:"",child: Text("Select"))),
                                          onChanged: (value){
                                            setState2(() {
                                              selectedsession2="";
                                              selectedchp2 = value as String;
                                            });
                                          }
                                        ),
                                        DropdownButton(
                                          value: selectedsession2,
                                          items: getSessions(chapters[selectedchp2])..add(DropdownMenuItem(value: "All",child:Text("All"))),
                                          onChanged: (value){
                                            setState2(() {
                                              selectedsession2 = value as String;
                                            });
                                          }
                                        ),
                                        // TextField(
                                        //   controller: sessionname2Controller,
                                        //   style: Styles().style(25, Colors.indigo, true),
                                        //   decoration: InputDecoration(
                                        //     border: OutlineInputBorder(),
                                        //     labelText: "Session Name",
                                        //   ),
                                        // ),
                                        // TextField(
                                        //   controller: chaptername2Controller,
                                        //   style: Styles().style(25, Colors.indigo, true),
                                        //   decoration: InputDecoration(
                                        //     border: OutlineInputBorder(),
                                        //     labelText: "Chapter Name",
                                        //   ),
                                        // ),
                                        TextButton(
                                          style: Styles().buttonStyle(Colors.blue, Colors.blue[900], 18),
                                          onPressed: ()async{
                                            DateTime now = DateTime.now();
                                            var formatter = DateFormat("dd-MM-yyyy");
                                            var formatter2 = DateFormat("h:m:s");
                                            String formattedDate = formatter.format(now);
                                            String formattedTime = formatter2.format(now);
                                            http.Response response = await http.post(
                                              Uri.parse("${Variables().url}attend.php"),
                                              body: {
                                                "phone":searchResults[index]['phone'],
                                                "sessionname":selectedsession2,
                                                "chaptername":selectedchp2,
                                                "chpstage":searchResults[index]['stage'],
                                                "center":searchResults[index]['center'],
                                                "date":formattedDate,
                                                "time":formattedTime
                                              }
                                            );
                                            if (response.statusCode==202) {
                                              ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: Colors.green,content: AutoSizeText("Done",style: Styles().style(25, Colors.white, true))));
                                            } else {
                                              ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: Colors.red,content: AutoSizeText("Error With code: ${response.statusCode}",style: Styles().style(25, Colors.white, true))));
                                            }
                                          },
                                          child: Padding(
                                            padding: const EdgeInsets.all(8.0),
                                            child: AutoSizeText(
                                              "Attend To Session",
                                              style: Styles().style(25, Colors.white, true),
                                            ),
                                          )
                                        ),
                                        TextButton(
                                          style: Styles().buttonStyle(Colors.red, Colors.red[900], 18),
                                          onPressed: ()async{
                                            DateTime now = DateTime.now();
                                            var formatter = DateFormat("dd-MM-yyyy");
                                            var formatter2 = DateFormat("h:m:s");
                                            String formattedDate = formatter.format(now);
                                            String formattedTime = formatter2.format(now);
                                            http.Response response = await http.post(
                                              Uri.parse("${Variables().url}remove.php"),
                                              body: {
                                                "phone":searchResults[index]['phone'],
                                                "sessionname":selectedsession2,
                                                "chaptername":selectedchp2,
                                                "chpstage":searchResults[index]['stage'],
                                              }
                                            );
                                            if (response.statusCode==202) {
                                              ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: Colors.green,content: AutoSizeText("Done",style: Styles().style(25, Colors.white, true))));
                                            } else {
                                              ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: Colors.red,content: AutoSizeText("Error With code: ${response.statusCode}",style: Styles().style(25, Colors.white, true))));
                                            }
                                          },
                                          child: Padding(
                                            padding: const EdgeInsets.all(8.0),
                                            child: AutoSizeText(
                                              "Remove From Session",
                                              style: Styles().style(25, Colors.white, true),
                                            ),
                                          )
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            )
                          ]
                        ),
                      )
                    );
                  }
                );
              }
            )
          ],
        ),
      ),
    );
  }
}