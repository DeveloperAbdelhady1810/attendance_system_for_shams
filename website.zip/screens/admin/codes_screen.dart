import 'dart:convert';
import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:quadroedu/classes/styles.dart';
import 'package:quadroedu/classes/variables.dart';
class CodesScreen extends StatefulWidget {
  const CodesScreen({super.key});

  @override
  State<CodesScreen> createState() => _CodesScreenState();
}
List searchResults = [];
class _CodesScreenState extends State<CodesScreen> {
  search(String query)async{
    http.Response response = await http.post(
      Uri.parse(
        "${Variables().url}search_codes.php"
      ),
      body: {
        "query": query
      }
    );
    if (response.statusCode == 202) {
      setState(() {
        searchResults = jsonDecode(response.body);
      });
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: AutoSizeText("Search"),
        elevation: 20,
        bottomOpacity: 0.7,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(
              width: MediaQuery.of(context).size.width-100,
              child: TextField(
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'Search',
                  suffixIcon: IconButton(
                    onPressed: (){
                      setState((){
                        searchResults.clear();
                      });
                    },
                    icon: Icon(Icons.clear),
                  )
                ),
                onChanged: (value)async{
                  await search(value);
                },
              ),
            ),
            const SizedBox(height: 10,),
            Divider(
              thickness: 2,
              color: Colors.blue,
            ),
            const SizedBox(height: 10,),
            ListView.builder(
              shrinkWrap: true,
              itemCount: searchResults.length,
              itemBuilder: (context,index){
                return StatefulBuilder(
                  builder: (context, setState2) {
                    return Card(
                      child: Padding(
                        padding: const EdgeInsets.all(20),
                        child: Column(
                          children: [
                            Align(
                              alignment: Alignment.center,
                              child: AutoSizeText(
                                searchResults[index]['code'],
                                style: Styles().style(30,Colors.blue,true),
                              ),
                            ),
                            const SizedBox(height: 10,),
                            Align(
                              alignment: Alignment.topLeft,
                              child: AutoSizeText(
                                "Price: ",
                                style: Styles().style(20,Colors.black54,true),
                              )
                            ),
                            const SizedBox(height: 7,),
                            Align(
                              alignment: Alignment.topRight,
                              child: AutoSizeText(
                                searchResults[index]['price'],
                                style: Styles().style(20,Colors.black54,true),
                              )
                            ),
                            const SizedBox(height: 5,),
                            Align(
                              alignment: Alignment.topLeft,
                              child: AutoSizeText(
                                "Bought: ",
                                style: Styles().style(20,Colors.black54,true),
                              )
                            ),
                            const SizedBox(height: 7,),
                            Align(
                              alignment: Alignment.topRight,
                              child: AutoSizeText(
                                searchResults[index]['bought'].toString(),
                                style: Styles().style(20,Colors.black54,true),
                              )
                            ),
                            searchResults[index]['bought'].toString() == "true"?const SizedBox(height: 5,):const SizedBox(height: 0,),
                            searchResults[index]['bought'].toString() == "true"?Align(
                              alignment: Alignment.topLeft,
                              child: AutoSizeText(
                                "Phone: ",
                                style: Styles().style(20,Colors.black54,true),
                              )
                            ):const SizedBox(height: 0,),
                            searchResults[index]['bought'].toString() == "true"?const SizedBox(height: 7,):const SizedBox(height: 0,),
                            searchResults[index]['bought'].toString() == "true"?Align(
                              alignment: Alignment.topRight,
                              child: AutoSizeText(
                                searchResults[index]['phone'].toString(),
                                style: Styles().style(20,Colors.black54,true),
                              )
                            ):const SizedBox(height: 0,),
                            searchResults[index]['bought'].toString() == "true"?const SizedBox(height: 5,):const SizedBox(height: 0,),
                            searchResults[index]['bought'].toString() == "true"?Align(
                              alignment: Alignment.topLeft,
                              child: AutoSizeText(
                                "Date: ",
                                style: Styles().style(20,Colors.black54,true),
                              )
                            ):const SizedBox(height: 0,),
                            searchResults[index]['bought'].toString() == "true"?const SizedBox(height: 7,):const SizedBox(height: 0,),
                            searchResults[index]['bought'].toString() == "true"?Align(
                              alignment: Alignment.topRight,
                              child: AutoSizeText(
                                searchResults[index]['date'].toString(),
                                style: Styles().style(20,Colors.black54,true),
                              )
                            ):const SizedBox(height: 0,),
                            searchResults[index]['bought'].toString() == "true"?const SizedBox(height: 5,):const SizedBox(height: 0,),
                            searchResults[index]['bought'].toString() == "true"?Align(
                              alignment: Alignment.topLeft,
                              child: AutoSizeText(
                                "Time: ",
                                style: Styles().style(20,Colors.black54,true),
                              )
                            ):const SizedBox(height: 0,),
                            searchResults[index]['bought'].toString() == "true"?const SizedBox(height: 7,):const SizedBox(height: 0,),
                            searchResults[index]['bought'].toString() == "true"?Align(
                              alignment: Alignment.topRight,
                              child: AutoSizeText(
                                searchResults[index]['time'].toString(),
                                style: Styles().style(20,Colors.black54,true),
                              )
                            ):const SizedBox(height: 0,),
                            TextButton(
                              style:Styles().buttonStyle(searchResults[index]['bought'].toString() == "true"?Colors.blue:Colors.red, searchResults[index]['bought'].toString() == "true"?Colors.blue[900]:Colors.red[900], 18),
                              onPressed: () async {
                                http.Response response = await http.post(
                                  Uri.parse(
                                    "${Variables().url}manage_activation.php",
                                  ),
                                  body: {
                                    "code":searchResults[index]['code'],
                                    "phone":Variables().settings.get("Assistant")['phone'],
                                    "type":searchResults[index]['bought'].toString() == "true"?"Activate":"Deactivate",
                                  }
                                );
                                if(response.statusCode == 202){
                                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: Colors.green,content:Text("Done",style:Styles().style(25, Colors.white, true))));
                                }else{
                                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: Colors.red,content:Text("Error with code: ${response.statusCode}",style:Styles().style(25, Colors.white, true))));
                                }
                              },
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: AutoSizeText(
                                  searchResults[index]['bought'].toString() == "true"?"Activate":"Deactivate",
                                  style: Styles().style(25,Colors.white,true),
                                ),
                              ),
                            )
                          ],
                        ),
                      )
                    );
                  }
                );
              }
            )
          ],
        ),
      ),
    );
  }
}