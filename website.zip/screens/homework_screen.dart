import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:quadroedu/adapters/question.dart';
import 'package:quadroedu/adapters/session.dart';
import 'package:quadroedu/classes/styles.dart';
import 'package:quadroedu/classes/variables.dart';
import 'package:http/http.dart' as http;
import 'package:auto_size_text/auto_size_text.dart';
class HomeworkScreen extends StatefulWidget {
  const HomeworkScreen({super.key, required this.session, required this.chpname});
  final Session session;
  final String chpname;
  @override
  State<HomeworkScreen> createState() => _HomeworkScreenState();
}
List questions = [];
Map answers = {};
Map marks = {};
int currentIndex = 0;
bool _isA = false;
bool _isB = false;
bool _isC = false;
bool _isD = false;
String filenameuploaded = "";
bool uploading = false;
class _HomeworkScreenState extends State<HomeworkScreen> {
  submitHw()async{
    http.Response response = await http.post(
      Uri.parse(
        "${Variables().url}submit_mark.php",
      ),
      body:{
        "chpname":widget.chpname,
        "chpstage":widget.session.stage,
        "sessionname":widget.session.name,
        "phone":Variables().getStudent().phone,
        "state":"hw",
        "mark": marks.isNotEmpty? marks.values.toList().reduce((a, b) => a + b).toString():"0",
      }
    );
    if(response.statusCode == 202){
      Navigator.pop(context);
    }else{
      print("${response.statusCode} Failed");
    }

  }
  addAnswer(String answer,Question question, value)async{
    http.Response response = await http.post(
      Uri.parse(
        "${Variables().url}add_answer.php",
      ),
      body: {
        "answer": answer,
        "questionid": question.id,
        "question":question.question,
        "sessionname":question.sessionname,
        "chpstage":widget.session.stage,
        "chpname":question.chpname,
        "rightAnswer":question.rightLetter,
        "wrong1":question.wrong1,
        "wrong2":question.wrong2,
        "wrong3":question.wrong3,
        "state":"hw",
        "phone":Variables().getStudent().phone,
        "imageurl":question.imageUrl,
        "mark":question.mark
      }
    );
    if (response.statusCode==202) {
      // success
      if (answer=="A") {
        setState(() {
          answers.addAll({currentIndex:"A"});
          _isB = false;
          _isC = false;
          _isD = false;
          _isA = true;
        });
      } else if(answer=="B"){
        setState(() {
          answers.addAll({currentIndex:"B"});
          _isA = false;
          _isC = false;
          _isD = false;
          _isB = true;
        });
      } else if(answer=="C"){
        setState(() {
          answers.addAll({currentIndex:"C"});
          _isA = false;
          _isB = false;
          _isD = false;
          _isC = true;
        });
      } else if(answer=="D"){
        setState(() {
          answers.addAll({currentIndex:"D"});
          _isA = false;
          _isB = false;
          _isC = false;
          _isD = true;
        });
      }
      if(question.rightLetter==answer){
        setState(() {
          marks.addAll({
            question.id:double.parse(question.mark),
          });
        });
      }else{
        setState(() {
          marks.addAll({
            question.id:0,
          });
        });
      }
      // print(marks);
    } else {
      // 303, 302 (Failed)
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: AutoSizeText("Error Code: ${response.statusCode}")));
    }
  }
  
  Future<String> uploadFile() async {
    final file = await FilePicker.platform.pickFiles();
    if (file != null) {
      final bytes = file.files[0].bytes;
      final url = 'https://storage.bunnycdn.com/balanceacademyfiles/${file.files[0].name}';
      final headers = {
        'AccessKey': '8a9a18a0-019f-4f1b-98f7a8a608d1-5981-4eb1',
        'Content-Type': 'application/octet-stream',
      };
      final response = await http.put(Uri.parse(url), headers: headers, body: bytes);
      if (response.statusCode == 201) {
        return "https://balanceacademyfiles.b-cdn.net/${file.files[0].name}";
      } else {
        print('Error uploading file: ${response.statusCode}');
        return "Error";
      }
    }else{
      return "no file";
    }
  }
  @override
  void initState() {
    super.initState();
    questions.addAll(widget.session.homework.questions);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(children: [
        Center(
          child: AutoSizeText(
            'Homewrok on ${widget.session.name}',
            style: Styles().style(30, Colors.black, true),
          ),
        ),
        Divider(
          thickness: 2,
          height: 2,
          color: Variables().mainColor,
        ),
        Card(
          elevation: 10,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
            side: BorderSide(color: Variables().mainColor, width: 2),
          ),
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: questions[currentIndex].isMCQ
            ?
            Column(
              children: [
                Image.network(
                  width: MediaQuery.of(context).size.width * 0.6,
                  height: MediaQuery.of(context).size.height * 0.3,
                  questions[currentIndex].imageUrl,
                  fit: BoxFit.cover,
                ),
                const SizedBox(height: 20),
                Row(
                  children: [
                    Checkbox(
                      value: _isA,
                      onChanged: (value) async{
                        await addAnswer("A",questions[currentIndex],value);
                      },
                    ),
                    const AutoSizeText("A"),
                    const SizedBox(width: 20),
                    Checkbox(
                      value: _isB,
                      onChanged: (value) async{
                        await addAnswer("B",questions[currentIndex],value);
                      },
                    ),
                    const AutoSizeText("B"),
                    const SizedBox(width: 20),
                    Checkbox(
                      value: _isC,
                      onChanged: (value) async{
                        await addAnswer("C",questions[currentIndex],value);
                      },
                    ),
                    const AutoSizeText("C"),
                    const SizedBox(width: 20),
                    Checkbox(
                      value: _isD,
                      onChanged: (value) async{
                        await addAnswer("D",questions[currentIndex],value);
                      },
                    ),
                    const AutoSizeText("D"),
                  ],
                ),
                AutoSizeText(
                  questions[currentIndex].question,
                  style: Styles().style(25, Colors.black, false),
                ),
                const SizedBox(height: 20),
              ],
            )
            :
            Column(
              children: [
                Image.network(
                  width: 200,
                  questions[currentIndex].imageUrl,
                  fit: BoxFit.cover,
                ),
                const SizedBox(height: 20),
                AutoSizeText(
                  questions[currentIndex].question,
                  style: Styles().style(25, Colors.black, false),
                ),
                const SizedBox(height: 20),
                TextButton.icon(
                  style: Styles().buttonStyle(Variables().mainColor, Variables().secondColor, 20),
                  onPressed: ()async{
                    setState(() {
                      uploading = true;
                    });
                    String fileUrl = await uploadFile();
                    if (fileUrl == "Error") {
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: AutoSizeText("Error in uploading")));
                    } else if(fileUrl=="no file"){
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: AutoSizeText("No Files Selected")));
                    }else{
                      setState(() {
                        filenameuploaded = fileUrl.replaceAll("https://balanceacademyfiles.b-cdn.net/", "");
                      });
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: AutoSizeText("${fileUrl.replaceAll("https://balanceacademyfiles.b-cdn.net/", "")} Uploaded")));
                      http.Response storeUpload = await http.post(
                        Uri.parse(
                          "${Variables().url}upload.php"
                        ),
                        body: {
                          "name" : Variables().getStudent().name,
                          "url" : fileUrl,
                          "chpname": widget.chpname,
                          "sessionname" : widget.session.name,
                          "stage" : Variables().getStudent().stage,
                          "state" : "hw",
                          "filename" : fileUrl.replaceAll("https://balanceacademyfiles.b-cdn.net/", ""),
                          "questionnumber" : "",
                          "question" : questions[currentIndex].question
                        }
                      );
                    }
                    setState(() {
                      filenameuploaded = fileUrl.replaceAll("https://balanceacademyfiles.b-cdn.net/", "");
                      uploading = false;
                    });
                  },
                  icon: Icon(
                    Icons.upload,
                    size: 19,
                    color: Colors.white,
                  ),
                  label: AutoSizeText(
                    filenameuploaded==""?"Upload":filenameuploaded,
                    style: Styles().style(25, Colors.white, false),
                  )
                )
              ],
            )
          ),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            currentIndex>0?TextButton.icon(
              onPressed: () {
                setState(() {
                  currentIndex--;
                });
              },
              icon: Icon(
                Icons.arrow_back_ios_new,
                color: Variables().mainColor,
                size: 30,
              ),
              label: AutoSizeText(
                'Save & Back',
                style: Styles().style(25, Variables().mainColor, false),
              ),
            ):const SizedBox(),
            TextButton.icon(
              onPressed: () async{
                if (currentIndex<questions.length-1) {
                  setState(() {
                    currentIndex++;
                  });
                } else {
                  await submitHw();
                }
              },
              icon: Icon(
                Icons.arrow_forward_ios,
                color: Variables().mainColor,
                size: 30,
              ),
              label: AutoSizeText(
                currentIndex<questions.length-1?'Save & Next':'Save & Submit',
                style: Styles().style(25, Variables().mainColor, false),
              ),
            )
          ],
        ),
        Wrap(
          children: questions
              .map((e) => Card(
                    color:currentIndex==questions.indexOf(e)?Variables().mainColor: Colors.grey.withValues(alpha: 0.5),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                      side: BorderSide(
                        color:Colors.grey.withValues(alpha: 0.5),
                        width: 1,
                      ),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: TextButton(
                        onPressed: () {
                          setState(() {
                            currentIndex = questions.indexOf(e);
                          });
                        },
                        child: AutoSizeText(
                          (questions.indexOf(e) + 1).toString(),
                          style: Styles().style(20,currentIndex==questions.indexOf(e)?Colors.white: Colors.black, false),
                        ),
                      ),
                    ),
                  ))
              .toList(),
        )
      ]),
    );
  }
}
