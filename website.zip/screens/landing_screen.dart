import 'dart:convert';
import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:quadroedu/classes/styles.dart';
import 'package:quadroedu/classes/variables.dart';
import 'package:quadroedu/screens/chapters_screen.dart';
import 'package:quadroedu/widgtes/contactinfo.dart';
import 'package:http/http.dart' as http;
import 'dart:js' as js;

class LandingScreen extends StatefulWidget {
  const LandingScreen({super.key});

  @override
  State<LandingScreen> createState() => _LandingScreenState();
}

TextEditingController emailController = TextEditingController();
TextEditingController passwordController = TextEditingController();
TextEditingController nameController = TextEditingController();
TextEditingController phoneController = TextEditingController();
TextEditingController parentPhoneController = TextEditingController();
bool loadingLogin = false;
bool createAccount = false;
bool isSignedIn = Variables().settings.get("Credits") != null ? true : false;
String selectedState = "Center";
String selectedStage = "First Secondry";
String selectedScientific = "true";
String selectedCenter = "The First El Haram";
class _LandingScreenState extends State<LandingScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            Align(
              alignment: Alignment.centerLeft,
              child: Card(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                  side: BorderSide(
                    color: Colors.black,
                    width: 2,
                  ),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          AutoSizeText(
                            "Welcome to ATMMATHS",
                            style: Styles().style(30, Variables().mainColor, true),
                          ),
                        ],
                      ),
                      Align(
                        alignment: Alignment.topRight,
                        child: Wrap(
                          // mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            !isSignedIn
                            ?TextButton(
                              style: Styles().buttonStyle(Variables().mainColor,Variables().secondColor, 18,bordersidecolor: Colors.blue),
                              onPressed: (){
                                showDialog(context: context, builder: (context)=>Dialog(
                                  child: StatefulBuilder(
                                    builder: (context,setState2) => SizedBox(
                                      width: 300,
                                      child: Card(
                                        elevation: 20,
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(20),
                                          side: BorderSide(
                                            color: Colors.black,
                                            width: 2,
                                          ),
                                        ),
                                        child: Padding(
                                          padding: const EdgeInsets.all(20),
                                          child: 
                                          !isSignedIn
                                            ? Column(
                                                children: [
                                                  AutoSizeText(
                                                    "Login",
                                                    style:Styles().style(20, Colors.blue, true),
                                                  ),
                                                  const SizedBox(
                                                    height: 10,
                                                  ),
                                                  TextField(
                                                    decoration: InputDecoration(
                                                      labelText: "Phone / ID",
                                                      border: OutlineInputBorder(),
                                                      prefixIcon: Icon(Icons.email),
                                                    ),
                                                    controller: emailController,
                                                  ),
                                                  const SizedBox(
                                                    height: 10,
                                                  ),
                                                  TextField(
                                                    decoration: InputDecoration(
                                                      labelText: "Password",
                                                      border: OutlineInputBorder(),
                                                      prefixIcon: Icon(Icons.password),
                                                    ),
                                                    controller: passwordController,
                                                  ),
                                                  const SizedBox(
                                                    height: 10,
                                                  ),
                                                  TextButton(
                                                    style: Styles().buttonStyle(Variables().mainColor,Variables().secondColor, 18,bordersidecolor: Colors.blue),
                                                    onPressed: () async {
                                                      if(loadingLogin == true){}else{
                                                        setState2(() {
                                                          loadingLogin = true;
                                                        });
                                                        http.Response loginResponse = await http.post(
                                                          Uri.parse("${Variables().url}login.php"),
                                                          body: {
                                                            "token": emailController.text,
                                                            "password":passwordController.text,
                                                            "mac":await Variables().getUserAgent()
                                                          }
                                                        );
                                                        if (loginResponse.statusCode == 202) {
                                                          String responseText = loginResponse.body.toString();
                                                          Map responseData = jsonDecode(responseText);
                                                          await Variables().loginStudent(responseData);
                                                          Navigator.pop(context);
                                                          ScaffoldMessenger.of(context).showSnackBar(
                                                            SnackBar(
                                                              backgroundColor: Colors.green,
                                                              content: Row(
                                                                mainAxisAlignment:MainAxisAlignment.spaceBetween,
                                                                children: [
                                                                  Icon(
                                                                    Icons.check,
                                                                    color: Colors.white,
                                                                    size: 30
                                                                  ),
                                                                  AutoSizeText(
                                                                    "Welcome Back ${responseData['name']}",
                                                                    style: Styles().style(25,Colors.white,true),
                                                                  ),
                                                                  const SizedBox()
                                                                ]
                                                              )
                                                            )
                                                          );
                                                          setState(() {
                                                            isSignedIn = true;
                                                          });
                                                          if(passwordController.text==""){
                                                            showDialog(context: context, builder: (context)=>Dialog(
                                                              child: Padding(
                                                                padding: const EdgeInsets.all(18),
                                                                child:Column(
                                                                  children:[
                                                                    AutoSizeText(
                                                                      "Create Password",
                                                                      style:Styles().style(25,Variables().mainColor,true)
                                                                    ),
                                                                    const SizedBox(height: 15,),
                                                                    TextField(
                                                                      decoration: InputDecoration(
                                                                        labelText: "Password",
                                                                        border: OutlineInputBorder(),
                                                                        prefixIcon: Icon(Icons.password),
                                                                      ),
                                                                      controller: passwordController,
                                                                    ),
                                                                    const SizedBox(height: 15),
                                                                    TextButton(
                                                                      style: Styles().buttonStyle(Variables().mainColor, Variables().secondColor, 18),
                                                                      onPressed: ()async{
                                                                        http.Response response = await http.post(
                                                                          Uri.parse(
                                                                            "${Variables().url}set_password.php"
                                                                          ),
                                                                          body:{
                                                                            "phone":Variables().getStudent().phone,
                                                                            "password":passwordController.text
                                                                          }
                                                                        );
                                                                        if(response.statusCode==202){
                                                                          Navigator.pop(context);
                                                                          Navigator.push(context,MaterialPageRoute(builder: (context)=>ChaptersScreen()));
                                                                        }else{
                                                                          Navigator.pop(context);
                                                                          Navigator.push(context,MaterialPageRoute(builder: (context)=>ChaptersScreen()));
                                                                        }
                                                                      },
                                                                      child: AutoSizeText(
                                                                        "Save Password",
                                                                        style: Styles().style(25, Colors.white, true),
                                                                      ),
                                                                    )
                                                                  ]
                                                                )
                                                              )
                                                            ));
                                                          }
                                                        } else if(loginResponse.statusCode == 303){
                                                          Navigator.pop(context);
                                                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                                            backgroundColor: Colors.red,
                                                            content: Row(
                                                              mainAxisAlignment:MainAxisAlignment.spaceBetween,
                                                              children: [
                                                                Icon(Icons.clear,color: Colors.white,size: 30),
                                                                AutoSizeText(
                                                                  "Wrong Device",
                                                                  style: Styles().style(25,Colors.white,true),
                                                                ),
                                                                const SizedBox(),
                                                              ]
                                                            )
                                                          )
                                                        );
                                    
                                                        }else{
                                                          Navigator.pop(context);
                                                          ScaffoldMessenger.of(context).showSnackBar(
                                                            SnackBar(
                                                              backgroundColor: Colors.red,
                                                              content: Row(
                                                                mainAxisAlignment:MainAxisAlignment.spaceBetween,
                                                                children: [
                                                                  Icon(Icons.clear,color: Colors.white,size: 30),
                                                                  AutoSizeText(
                                                                    "Invalid Login",
                                                                    style: Styles().style(25,Colors.white,true),
                                                                  ),
                                                                  const SizedBox(),
                                                                ]
                                                              )
                                                            )
                                                          );
                                                        }
                                                        setState2(() {
                                                          loadingLogin = false;
                                                        });
                                                      }
                                                    },
                                                    child: Padding(
                                                      padding: const EdgeInsets.all(8.0),
                                                      child: !loadingLogin
                                                      ? AutoSizeText(
                                                          "Login",
                                                          style: Styles().style(25, Colors.white, false),
                                                        )
                                                      : CircularProgressIndicator(
                                                              color: Colors.white,
                                                            ),
                                                    )
                                                  ),
                                                  const SizedBox(height: 10,),
                                                ],
                                              )
                                            : Column(
                                                children: [
                                                  AutoSizeText(
                                                    "Welcome Back",
                                                    style: Styles().style(20, Colors.blue, true),
                                                  ),
                                                  TextButton(
                                                      style: Styles().buttonStyle(Variables().mainColor,
                                                          Variables().secondColor, 18,
                                                          bordersidecolor: Colors.blue),
                                                      child: Padding(
                                                        padding: const EdgeInsets.all(8.0),
                                                        child: AutoSizeText(
                                                          "Continue Learning",
                                                          style: Styles()
                                                              .style(25, Colors.white, false),
                                                        ),
                                                      ),
                                                      onPressed: () async {
                                                        Navigator.of(context).pop();
                                                        Navigator.push(
                                                            context,
                                                            MaterialPageRoute(
                                                                builder: (context) =>
                                                                    ChaptersScreen()));
                                                      })
                                                ],
                                              )
                                          )
                                        ),
                                    ),
                                  ),
                                ));
                              },
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: AutoSizeText(
                                  "Login",
                                  style: Styles().style(25, Colors.white, false),
                                ),
                              ),
                            ):
                            Column(
                              children: [
                                AutoSizeText(
                                  "Welcome Back",
                                  style: Styles().style(20, Colors.blue, true),
                                ),
                                TextButton(
                                    style: Styles().buttonStyle(Variables().mainColor,
                                        Variables().secondColor, 18,
                                        bordersidecolor: Colors.blue),
                                    child: Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: AutoSizeText(
                                        "Continue Learning",
                                        style: Styles()
                                            .style(25, Colors.white, false),
                                      ),
                                    ),
                                    onPressed: () async {
                                      Navigator.of(context).pop();
                                      Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                              builder: (context) =>
                                                  ChaptersScreen()));
                                    })
                              ],
                            ),
                            !isSignedIn
                            ?
                            TextButton(
                              style: Styles().buttonStyle(Colors.black,Colors.grey, 18,bordersidecolor: Colors.black),
                              onPressed: (){
                                showDialog(context:context,builder: (context)=>StatefulBuilder(
                                  builder: (context, setState2) {
                                    return Dialog(
                                      child: Padding(
                                        padding: const EdgeInsets.all(18.0),
                                        child: Column(
                                          children: [
                                            AutoSizeText(
                                              "Create Account",
                                              style:Styles().style(20, Colors.blue, true),
                                            ),
                                            const SizedBox(
                                              height: 10,
                                            ),
                                            TextField(
                                              decoration: InputDecoration(
                                                labelText: "Name",
                                                border: OutlineInputBorder(),
                                                prefixIcon: Icon(Icons.person),
                                              ),
                                              controller: nameController,
                                            ),
                                            const SizedBox(
                                              height: 10,
                                            ),
                                            TextField(
                                              decoration: InputDecoration(
                                                labelText: "Phone",
                                                border: OutlineInputBorder(),
                                                prefixIcon: Icon(Icons.phone),
                                              ),
                                              controller: phoneController,
                                            ),
                                            const SizedBox(
                                              height: 10,
                                            ),
                                            TextField(
                                              decoration: InputDecoration(
                                                labelText: "Parent Phone",
                                                border: OutlineInputBorder(),
                                                prefixIcon: Icon(Icons.phone),
                                              ),
                                              controller: parentPhoneController,
                                            ),
                                            const SizedBox(
                                              height: 10,
                                            ),
                                            
                                            DropdownButton(
                                              value: selectedStage,
                                              items: [
                                                DropdownMenuItem(
                                                  value: null,
                                                  child: AutoSizeText("Select Stage"),
                                                ),
                                                DropdownMenuItem(
                                                  value: "First Secondry",
                                                  child: AutoSizeText("First Secondry"),
                                                ),
                                                DropdownMenuItem(
                                                  value: "Second Secondry",
                                                  child: AutoSizeText("Second Secondry"),
                                                ),
                                                DropdownMenuItem(
                                                  value: "Third Secondry",
                                                  child: AutoSizeText("Third Secondry"),
                                                ),
                                              ],
                                              onChanged: (value){
                                                setState2(() {
                                                  selectedStage = value as String;
                                                }
                                              );
                                              }
                                            ),
                                            const SizedBox(height: 10,),
                                            selectedStage!="First Secondry"
                                            ? DropdownButton(
                                              value: selectedScientific,
                                              items: [
                                                DropdownMenuItem(
                                                  value: null,
                                                  child: AutoSizeText("اختر الشعبة"),
                                                ),
                                                DropdownMenuItem(
                                                  value: "true",
                                                  child: AutoSizeText("علمي"),
                                                ),
                                                DropdownMenuItem(
                                                  value: "false",
                                                  child: AutoSizeText("ادبي"),
                                                ),
                                              ],
                                              onChanged: (value){
                                                setState2(() {
                                                  selectedScientific = value as String;
                                                });
                                              }
                                            )
                                            :const SizedBox(),
                                            const SizedBox(height: 10,),
                                            DropdownButton(
                                              value: selectedState,
                                              items: [
                                                DropdownMenuItem(
                                                  value: null,
                                                  child: AutoSizeText("Select State"),
                                                ),
                                                DropdownMenuItem(
                                                  value: "Online",
                                                  child: AutoSizeText("Online"),
                                                ),
                                                DropdownMenuItem(
                                                  value: "Center",
                                                  child: AutoSizeText("Center"),
                                                )
                                              ],
                                              onChanged: (value){
                                                setState2(() {
                                                  selectedState = value as String;
                                                });
                                              }
                                            ),
                                            const SizedBox(height: 10,),
                                            selectedState == "Center"?
                                            DropdownButton(
                                              value: selectedCenter,
                                              items: [
                                                DropdownMenuItem(
                                                  value: null,
                                                  child: AutoSizeText("Select Center"),
                                                ),
                                                DropdownMenuItem(
                                                  value: "The First El Haram",
                                                  child: AutoSizeText("The First El Haram"),
                                                ),
                                                DropdownMenuItem(
                                                  value: "The Frist El Fardoos",
                                                  child: AutoSizeText("The Frist El Fardoos"),
                                                ),
                                                DropdownMenuItem(
                                                  value: "A-One El Haram",
                                                  child: AutoSizeText("A-One El Haram"),
                                                ),
                                                DropdownMenuItem(
                                                  value: "A-One Hadaye` El Ahram",
                                                  child: AutoSizeText("A-One Hadaye` El Ahram"),
                                                ),
                                                DropdownMenuItem(
                                                  value: "Trust El Haram",
                                                  child: AutoSizeText("Trust El Haram"),
                                                ),
                                                DropdownMenuItem(
                                                  value: "Teachers Hadaye` El Ahram",
                                                  child: AutoSizeText("Teachers Hadaye` El Ahram"),
                                                ),
                                              ],
                                              onChanged: (value){
                                                setState2(() {
                                                  selectedCenter = value as String ;
                                                });
                                              }
                                            ):const SizedBox(),
                                            const SizedBox(height: 10,),
                                            TextField(
                                              decoration: InputDecoration(
                                                labelText: "Password",
                                                border: OutlineInputBorder(),
                                                prefixIcon: Icon(Icons.password),
                                              ),
                                              controller: passwordController,
                                            ),
                                            const SizedBox(
                                              height: 10,
                                            ),
                                            TextButton(
                                              style: Styles().buttonStyle(Variables().mainColor,Variables().secondColor, 18,bordersidecolor: Colors.blue),
                                              onPressed: () async {
                                                String? mac_address = await Variables().getUserAgent();
                                                // print("${ip}register.php?firstname=${firstName.text}&lastname=${lastName.text}&email=${email.text}&phone=${phone.text}&stage=${stage.toString().replaceAll(' ','Ahmed')}&gender=$gender&parrentemail=${parrentEmail.text}&parrentphone=${parrentPhone.text}&mode=1&mac=${(mac_address).toString().replaceAll(" ", "Ahmed")}");
                                                http.Response response = await http.post(
                                                  Uri.parse("${Variables().url}register.php"),
                                                  body: {
                                                    "name":nameController.text,
                                                    "phone": phoneController.text,
                                                    "parentphone":parentPhoneController.text,
                                                    "stage":selectedStage,
                                                    "mac":mac_address,
                                                    "password":passwordController.text,
                                                    "center":selectedState=="Center"? selectedCenter:"Online",
                                                    "state":selectedState,
                                                    "isscientific":selectedScientific,
                                                  }
                                                );
                                                if (response.statusCode == 202) {
                                                  // print('Request was successful. Response body: ${response.body}');
                                                  Navigator.pop(context);
                                                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: Colors.green,content: AutoSizeText("Success",style: Styles().style(25, Colors.white, true),)));
                                                } else if(response.statusCode==303){
                                                  // print('Request was failed. Response body: ${response.body}');
                                                  Navigator.pop(context);
                                                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: Colors.red,content: AutoSizeText("Failed, you have an account with id:${response.body}",style: Styles().style(25, Colors.white, true),)));
                                                }else{
                                                  // print('Request failed with status code: ${response.statusCode}, reason phrase: ${response.reasonPhrase}');
                                                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: Colors.red,content: AutoSizeText("Failed With code: ${response.statusCode}",style: Styles().style(25, Colors.white, true),)));
                                                }
                                              },
                                              child: Padding(
                                                padding: const EdgeInsets.all(8.0),
                                                child: !loadingLogin
                                                ? AutoSizeText(
                                                    "Create Account",
                                                    style: Styles().style(25,Colors.white,false),
                                                  )
                                                : CircularProgressIndicator(color: Colors.white,),
                                              )
                                            ),
                                            const SizedBox(height: 10,),
                                            
                                          ],
                                        ),
                                      ),
                                    );
                                  }
                                ));
                              },
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: AutoSizeText(
                                  "Create Account",
                                  style: Styles().style(20, Colors.white, true),
                                ),
                              )
                            )
                            :const SizedBox(),
                            TextButton(
                              style: Styles().buttonStyle(Colors.blue,const Color.fromARGB(255, 2, 55, 99), 18,bordersidecolor: Colors.black),
                              onPressed:(){
                                js.context.callMethod("urlLauncher",["https://parent.atmmaths.com"]);
                              },
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: AutoSizeText(
                                  "Parent",
                                  style: Styles().style(20, Colors.white, true),
                                ),
                              )
                            )
                          ],
                        ),
                      ), 
                    ],
                  ),
                ),
              ),
            ),
            Container(
              width: MediaQuery.of(context).size.width,
              height: 500,
              decoration: BoxDecoration(
                image: DecorationImage(
                  fit: BoxFit.cover,
                  image: AssetImage('images/3.jpg'),
                ),
              ),
              child: Wrap(
                alignment: WrapAlignment.center,
                children: [
                  // const SizedBox(height: 350,),
                  
                ],
              ),
            ),
            const SizedBox(
              height: 100,
            ),
            Center(
              child: Wrap(
                alignment: WrapAlignment.center,
                children: [
                  Container(
                    width: 350,
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.white, width: 2),
                    ),
                    child: Column(
                      children: [
                        Image.asset(
                          "images/YouTube_play_button_icon_(2013–2017).png",
                          width: 100,
                        ),
                        AutoSizeText(
                          "Youtube Channel",
                          style: Styles().style(30, Colors.red, true),
                        ),
                        TextButton.icon(
                          style: Styles().buttonStyle(Colors.white,Colors.red,18,bordersidecolor: Colors.red),
                          icon: Icon(
                            Icons.play_circle_fill,
                            color: Colors.red,
                          ),
                          onPressed: (){
                            js.context.callMethod("urlLauncher",["https://www.youtube.com/@mr.abdul-aziztammam-1621"]);
                          },
                          label: AutoSizeText(
                            "Open",
                            style: Styles().style(25,Colors.red,true),
                          )
                        ),
                      ],
                    ),
                  ),
                  Container(
                    width: 350,
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.white, width: 2),
                    ),
                    child: Column(
                      children: [
                        Image.asset(
                          "images/facebook.png",
                          width: 100,
                        ),
                        AutoSizeText(
                          "Facebook",
                          style: Styles().style(30, Colors.blue, true),
                        ),
                        TextButton.icon(
                          style: Styles().buttonStyle(Colors.white,Colors.blue,18,bordersidecolor: Colors.blue),
                          onPressed: (){
                            js.context.callMethod("urlLauncher",["https://www.facebook.com/mrabdulaziztammam.maths"]);
                          },
                          label: AutoSizeText(
                            "Open",
                            style: Styles().style(25,Colors.blue,true),
                          )
                        ),
                      ],
                    ),
                  ),
                ]
              ),
            ),
            const SizedBox(
              height: 100,
            ),
            SizedBox(
              width: MediaQuery.of(context).size.width,
              child: Wrap(
                alignment: WrapAlignment.center,
                runSpacing: 10,
                spacing: 10,
                children: [
                  // SizedBox(
                  //   width: 300,
                  //   height: 500,
                  //   child: Card(
                  //     shape: RoundedRectangleBorder(
                  //       borderRadius: BorderRadius.circular(10),
                  //     ),
                  //     child: Padding(
                  //       padding: const EdgeInsets.all(0),
                  //         child: Container(
                  //           decoration: BoxDecoration(
                  //             image: DecorationImage(
                  //               image: AssetImage("images/sec1.jpg"),
                  //               fit: BoxFit.cover,
                  //               opacity: 0.6
                  //             ),
                  //           ),
                  //         )
                  //       ),
                  //     ),
                  // ),
                  Container(
                    width: 300,
                    color: Colors.grey.withOpacity(0.4),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        /// Top Circular Image with Text
                        ClipOval(
                          child: Container(
                            width: 300, // Adjust size as needed
                            height: 300, // Ensure it's a circle
                            decoration: BoxDecoration(
                              color: Colors.blue.withOpacity(0.8), // Blue overlay effect
                            ),
                            child: Stack(
                              alignment: Alignment.center,
                              children: [
                                Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      "Secondary",
                                      style: TextStyle(
                                        fontSize: 34,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.white,
                                      ),
                                    ),
                                    Text(
                                      "One",
                                      style: TextStyle(
                                        fontSize: 30,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.white,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(height: 20),
                        /// Description Text
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 20.0),
                          child: Text(
                            "FHD videos, Monthly exams, online Quizzes, personal assistant and high standard of thinking Question",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 16,
                              color: Colors.black,
                              height: 1.4,
                            ),
                          ),
                        ),
                        const SizedBox(height: 20),
                        /// Read More Button
                        OutlinedButton(
                          onPressed: () {
                            // Action when button is pressed
                          },
                          style: OutlinedButton.styleFrom(
                            side: BorderSide(color: Colors.blue, width: 2),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(30),
                            ),
                            padding: EdgeInsets.symmetric(horizontal: 30, vertical: 12),
                          ),
                          child: Text(
                            "Read More",
                            style: TextStyle(
                              fontSize: 18,
                              color: Colors.blue,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    width: 300,
                    color: Colors.grey.withOpacity(0.4),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        /// Top Circular Image with Text
                        ClipOval(
                          child: Container(
                            width: 300, // Adjust size as needed
                            height: 300, // Ensure it's a circle
                            decoration: BoxDecoration(
                              color: Colors.indigo.withOpacity(0.8), // Blue overlay effect
                            ),
                            child: Stack(
                              alignment: Alignment.center,
                              children: [
                                Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      "Secondary",
                                      style: TextStyle(
                                        fontSize: 34,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.white,
                                      ),
                                    ),
                                    Text(
                                      "Two",
                                      style: TextStyle(
                                        fontSize: 30,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.white,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(height: 20),
                        /// Description Text
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 20.0),
                          child: Text(
                            "FHD videos, Monthly exams, online Quizzes, personal assistant and high standard of thinking Question",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 16,
                              color: Colors.black,
                              height: 1.4,
                            ),
                          ),
                        ),
                        const SizedBox(height: 20),
                        /// Read More Button
                        OutlinedButton(
                          onPressed: () {
                            // Action when button is pressed
                          },
                          style: OutlinedButton.styleFrom(
                            side: BorderSide(color: Colors.indigo, width: 2),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(30),
                            ),
                            padding: EdgeInsets.symmetric(horizontal: 30, vertical: 12),
                          ),
                          child: Text(
                            "Read More",
                            style: TextStyle(
                              fontSize: 18,
                              color: Colors.indigo,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    width: 300,
                    color: Colors.grey.withOpacity(0.4),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        /// Top Circular Image with Text
                        ClipOval(
                          child: Container(
                            width: 300, // Adjust size as needed
                            height: 300, // Ensure it's a circle
                            decoration: BoxDecoration(
                              color: Colors.black.withOpacity(0.8), // Blue overlay effect
                            ),
                            child: Stack(
                              alignment: Alignment.center,
                              children: [
                                Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      "Secondary",
                                      style: TextStyle(
                                        fontSize: 34,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.white,
                                      ),
                                    ),
                                    Text(
                                      "Three",
                                      style: TextStyle(
                                        fontSize: 30,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.white,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(height: 20),
                        /// Description Text
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 20.0),
                          child: Text(
                            "FHD videos, Monthly exams, online Quizzes, personal assistant and high standard of thinking Question",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 16,
                              color: Colors.black,
                              height: 1.4,
                            ),
                          ),
                        ),
                        const SizedBox(height: 20),
                        /// Read More Button
                        OutlinedButton(
                          onPressed: () {
                            // Action when button is pressed
                          },
                          style: OutlinedButton.styleFrom(
                            side: BorderSide(color: Colors.black, width: 2),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(30),
                            ),
                            padding: EdgeInsets.symmetric(horizontal: 30, vertical: 12),
                          ),
                          child: Text(
                            "Read More",
                            style: TextStyle(
                              fontSize: 18,
                              color: Colors.black,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ]
              )
            ),
            SizedBox(
              width: MediaQuery.of(context).size.width,
              child: Wrap(
                alignment: WrapAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Image.asset(
                      "images/ABDULAZIZ TAMMAM.png",
                      // width: MediaQuery.of(context).size.width*0.4,
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(18.0),
                    child: AutoSizeText(
                      """About Our System  

- High-Quality Videos: Clear, high-resolution videos for an easy and enjoyable learning experience.  
- Online Quizzes: Test yourself and improve your understanding.  
- Live Classes: Stay connected and learn in real time.  
- Personal Assistant: Get help whenever you need it.  
- high standards of thinking questions: Boost your creativity with challenging questions.   
- Monthly Exams: Track your progress and improve over time.""",
                      style: Styles().style(22, Colors.black, true),
                    ),
                  )
                ],
              ),
            ),
            Container(
              decoration: BoxDecoration(
                // image: DecorationImage(
                //   fit: BoxFit.cover,
                //   image: AssetImage("images/footer.jpg"),
                // ),
                color: Variables().secondColor
              ),
              height: 200,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  AutoSizeText(
                    'Get in Touch',
                    style: TextStyle(
                      fontSize: 24,
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 20),
                  Align(
                    alignment: Alignment.center,
                    child: SizedBox(
                      width: MediaQuery.of(context).size.width,
                      child: Wrap(
                        runAlignment: WrapAlignment.center,
                        alignment: WrapAlignment.center,
                        crossAxisAlignment: WrapCrossAlignment.center,
                        // mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          ContactInfo(
                            icon: Icons.phone,
                            text: 'Call us: +201099655862',
                          ),
                          SizedBox(width: 20),
                          ContactInfo(
                            icon: Icons.email,
                            text: 'Email us: support@atmmaths.com',
                          ),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(height: 20),
                  AutoSizeText(
                    'Copyright 2023 Quadro Company. All rights reserved.',
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.white,
                    ),
                  ),
                ],
              ),
            ),
          ],
        )
      )
    );
  }
}