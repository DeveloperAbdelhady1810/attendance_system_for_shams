import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:quadroedu/adapters/quiz.dart';
import 'package:quadroedu/widgtes/quiz_card.dart';
class MarksScreen extends StatefulWidget {
  const MarksScreen({super.key});
  @override
  State<MarksScreen> createState() => _MarksScreenState();
}
class _MarksScreenState extends State<MarksScreen> {
  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width - 205;
    final crossAxisCount = screenWidth ~/ 300;
    return Expanded(
      child: GridView.builder(
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: crossAxisCount > 0 ? crossAxisCount : 1,
          childAspectRatio: 1,
          crossAxisSpacing: 10,
          mainAxisSpacing: 10,
        ),
        itemCount: 6,
        itemBuilder: (context, index) {
          return QuizCard(
            mark:"9",
            quiz: Quiz(onSession: "Session ${index+1}", sessionName: "Session ${index+1}", questions: [], stage: "First Secondry", successMark: "10", fullMark: "20", quizTimer: "30")
          );
        }
      ),
    );
  }
}