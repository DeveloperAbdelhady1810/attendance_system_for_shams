import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class CallusScreen extends StatefulWidget {
  const CallusScreen({super.key});

  @override
  State<CallusScreen> createState() => _CallusScreenState();
}

class _CallusScreenState extends State<CallusScreen> {
  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.all(10)
      ),
    );
  }
}