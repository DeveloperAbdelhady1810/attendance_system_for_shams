import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:quadroedu/adapters/session.dart';
import 'package:quadroedu/adapters/student.dart';
import 'package:quadroedu/classes/styles.dart';
import 'package:quadroedu/classes/variables.dart';
import 'package:quadroedu/screens/session_screen.dart';
import 'package:auto_size_text/auto_size_text.dart';
bool loading = false;
class SessionCard extends StatelessWidget {
  SessionCard({super.key,required this.session, required this.chpname,required this.isbought});
  bool isbought;
  final Session session;
  final String chpname;
  @override
  Widget build(BuildContext context) {
    return StatefulBuilder(
      builder: (context,setState){
        return TextButton(
          onPressed: () async {
            if(isbought){
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => SessionScreen(
                    session: session,
                    chpname: chpname,
                  ),
                ),
              );
            }else{
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: AutoSizeText("Buy it first")));
            }
          },
          child: SizedBox(
            width: 300,
            // height: 400,
            child: Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
              color: isbought?Colors.green:Colors.white,
              child: Padding(
                padding: const EdgeInsets.all(25),
                child: Column(
                  children: [
                    SizedBox(
                      height: 200,
                      child: Image.network(
                        session.url,
                        fit: BoxFit.cover,
                      ),
                    ),
                    Spacer(),
                    AutoSizeText(
                      session.name,
                      style: Styles().style(20, !isbought?Colors.black:Colors.white, false),
                      maxLines: 3,
                    ),
                    isbought?const SizedBox()
                    :
                    TextButton(
                      style: Styles().buttonStyle(Colors.black, Colors.grey, 18),
                      onPressed: ()async{
                        if (loading) {
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: Colors.red,content: Text("Loading, Please Wait.....",style: Styles().style(25, Colors.white, true),),));
                        } else {
                          showDialog(context: context, builder: (context)=>Dialog(
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Align(
                                  alignment: Alignment.center,
                                  child: Text(
                                    "Confirm Buying ${session.name} For ${session.price} EGP?"
                                  ),
                                ),
                                TextButton(
                                  style: Styles().buttonStyle(Colors.green, Colors.green.shade900, 18,bordersidecolor: Colors.green),
                                  onPressed: ()async{
                                    setState(() {
                                      loading = true;
                                    });
                                    if (double.parse(Variables().getStudent().balance)>=double.parse(session.price)) {
                                      Student student = Variables().getStudent();
                                      DateTime now = DateTime.now();
                                      var formatter = DateFormat("dd-MM-yyyy");
                                      var formatter2 = DateFormat("h:m:s");
                                      String formattedDate = formatter.format(now);
                                      String formattedTime = formatter2.format(now);
                                      int responseofbuying = await Variables().buySession(student,{"chpname":chpname,"chpstage":session.stage,"sessionname":session.name,"phone":student.phone,"date":formattedDate,"time":formattedTime});
                                      if (responseofbuying == 202) {
                                        student.balance = (double.parse(Variables().getStudent().balance) - double.parse(session.price)).toString();
                                        int responsestatuscode = await Variables().updateBalance(student);
                                        if (responsestatuscode == 202) {
                                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: AutoSizeText("Success")));
                                          student.sessions!.add(session.name+chpname);
                                          await Variables().settings.put("Credits",student);
                                          setState((){
                                            isbought = true; 
                                          });
                                        }
                                      } else {
                                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: AutoSizeText("Cannot buy session")));
                                      }
                                    } else {
                                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: AutoSizeText("No balance")));
                                    }
                                    setState(() {
                                      loading = false;
                                    });
                                  },
                                  child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Text(
                                      "Yes, Confirm",
                                      style: Styles().style(25, Colors.white, true),
                                    ),
                                  )
                                ),
                                TextButton(
                                  style: Styles().buttonStyle(Colors.red, Colors.red.shade900, 18,bordersidecolor: Colors.red),
                                  onPressed: (){
                                    Navigator.pop(context);
                                  },
                                  child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Text(
                                      "Cancel",
                                      style: Styles().style(25, Colors.white, true),
                                    ),
                                  )
                                )
                              ]
                            ),
                          ));
                        }
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: !loading?AutoSizeText(
                          "Buy",
                          style:Styles().style(22, Colors.white, true)
                        ):CircularProgressIndicator(color: Colors.white,),
                      )
                    ),
                    isbought?const SizedBox()
                    : AutoSizeText(
                      "${session.price} EGP",
                      style: Styles().style(20, Colors.black, true),
                    )
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
