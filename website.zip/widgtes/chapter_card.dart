import 'package:flutter/material.dart';
import 'package:quadroedu/classes/styles.dart';
import 'package:quadroedu/screens/chapter_screen.dart';
import 'package:auto_size_text/auto_size_text.dart';
class ChapterCard extends StatelessWidget {
  const ChapterCard({
    super.key, required this.chpName, required this.stage, required this.chpurl,
  });
  final String chpName;
  final String stage;
  final String chpurl;
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 300,
      height: 400,
      child: TextButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => ChapterScreen(chapterName: chpName,chapterStage: stage,)),
          );
        },
        child: Card(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
          child: Padding(
            padding: const EdgeInsets.all(15),
            child: Column(
              children: [
                SizedBox(
                  // height: 200,
                  // width: 200,
                  child: Image.network(
                    chpurl,
                    fit: BoxFit.cover,
                  ),
                ),
                Spacer(),
                AutoSizeText(
                  chpName,
                  style: Styles().style(17, Colors.black, false),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
