import 'package:flutter/material.dart';
import 'package:quadroedu/adapters/quiz.dart';
import 'package:quadroedu/classes/styles.dart';
import 'package:auto_size_text/auto_size_text.dart';
class QuizCard extends StatelessWidget {
  const QuizCard({super.key, required this.quiz, required this.mark});
  final Quiz quiz;
  final String mark;
  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 20,
      color: double.parse(mark)>=double.parse(quiz.successMark)?Colors.green:Colors.red,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
      ),
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            AutoSizeText(
              'Quiz on ${quiz.onSession}',
              style: Styles().style(25, Colors.white, true),
            ),
            const SizedBox(height: 10,),
            const Divider(
              color: Colors.white,
              height: 2,
              thickness: 2,
            ),
            const SizedBox(height: 10,),
            AutoSizeText(
              'Mark: $mark/${quiz.fullMark}',
              style: Styles().style(20, Colors.white, true),
            ),

          ]
        )
      ),
    );
  }
}