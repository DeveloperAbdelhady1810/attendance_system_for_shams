import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:quadroedu/adapters/student.dart';
import 'package:quadroedu/classes/variables.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:quadroedu/screens/admin/admin_login_screen.dart';
import 'package:quadroedu/screens/admin/admin_screen.dart';
import 'package:quadroedu/screens/new/landing_page.dart';
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Hive.initFlutter();
  // if (kIsWeb) {
  //   WebView.platform = WebWebViewPlatform();
  // }
  Hive.registerAdapter(StudentAdapter());
  await Hive.openBox("settings");
  if (Variables().settings.get("Credits")!=null) {
    http.Response loginResponse = await http.post(
      Uri.parse("${Variables().url}login.php"),
      body: {
        "token": Variables().getStudent().phone,
        "password":Variables().getStudent().password,
        "mac":await Variables().getUserAgent()
      }
    );
    if (loginResponse.statusCode == 202) {
      await Variables().settings.delete("Credits");
      // String responseText = loginResponse.body.toString();
      // Map responseData = jsonDecode(responseText);
      // await Variables().loginStudent(responseData);
    }else if(loginResponse.statusCode == 303){
      String responseText = loginResponse.body.toString();
      Map responseData = jsonDecode(responseText);
      await Variables().loginStudent(responseData);
    }
  }
  runApp(const MyApp());
}
class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Balance Academy',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
        fontFamily: "Poppins"
      ),
      // home: Variables().settings.get("Assistant")!=null? const AdminScreen():AdminLoginScreen(),
      home: LandingPage(),
    );
  }
}